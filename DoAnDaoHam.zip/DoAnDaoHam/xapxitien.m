function fd1 = xapxitien(fx,x0,x1,y1,h,Oh)
        if strcmp(Oh,'O(h)') %Kiểm tra loại sai số O(h)    
            if strcmp(fx,'') %Nếu không nhập hàm số thì dùng công thức x y   
                i = find(x1==x0); %Tìm và gán giá trị i nếu x1=x0
                fd1 = (y1(i+1) - y1(i))/h; %Công thức x y xấp xỉ tiến sai số O(h)
            else %Nếu nhập hàm số thì dùng công thức trực tiếp                 
                fx = str2func(['@(x)' char(fx)]);%Hàm chuyển string thành fuction
                fd1 = (fx(x0+h)-fx(x0))/h; %Công thức đạo hàm bậc 1 tiến sai số O(h)
            end
        elseif strcmp(Oh,'O(h^2)') %Kiểm tra loại sai số O(h^2) 
            if strcmp(fx,'') %Nếu không nhập hàm số thì dùng công thức x y   
                i = find(x1==x0); %Tìm và gán giá trị i nếu x1=x0
                fd1 = (-y1(i+2)+4*y1(i+1)-3*y1(i))/(2*h); %Công thức x y xấp xỉ tiến sai số O(h^2)
            else  %Nếu nhập hàm số thì dùng công thức trực tiếp 
                fx = str2func(['@(x)' char(fx)]);%Hàm chuyển string thành fuction
                fd1 = (-fx(x0+2*h)+4*fx(x0+h)-3*fx(x0))/(2*h); %Công thức đạo hàm bậc 1 tiến sai số O(h^2)
            end
        end
    
end