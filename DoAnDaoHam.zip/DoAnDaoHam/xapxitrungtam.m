function fd1 = xapxitrungtam(fx,x0,x1,y1,h,Oh) 
    if strcmp(Oh,'O(h)')  %Kiểm tra loại sai số O(h)   
        if strcmp(fx,'')  %Nếu không nhập hàm số thì dùng công thức x y 
            i = find(x1==x0); %Tìm và gán giá trị i nếu x1=x0
            fd1 = (y1(i+1)-y1(i-1))/(2*h); %Công thức x y xấp xỉ trung tâm sai số O(h)
        else %Nếu nhập hàm số thì dùng công thức trực tiếp
        fx = str2func(['@(x)' char(fx)]);   %Hàm chuyển string thành fuction 
        fd1 = (fx(x0+h)-fx(x0-h))/(2*h); %Công thức đạo hàm bậc 1 trung tâm sai số O(h)
        end
    elseif strcmp(Oh,'O(h^2)') %Kiểm tra loại sai số O(h^2)    
        if strcmp(fx,'')  %Nếu không nhập hàm số thì dùng công thức x y   
            i = find(x1==x0); %Tìm và gán giá trị i nếu x1=x0
            fd1 = (-y1(i+2) + 8.*y1(i+1) - 8.*y1(i-1) + y1(i-2))./(12*h); %Công thức x y xấp xỉ trung tâm sai số O(h^2)
        else
        fx = str2func(['@(x)' char(fx)]); %Hàm chuyển string thành fuction
        fd1 = (-fx(x0+2*h)+8.*fx(x0+h)-8.*fx(x0-h)+fx(x0-2*h))./(12*h); %Công thức đạo hàm bậc 1 trung tâm sai số O(h^2)
        end
    end
end