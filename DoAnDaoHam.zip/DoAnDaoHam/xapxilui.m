function fd1 = xapxilui(fx,x0,x1,y1,h,Oh)
    if strcmp(Oh,'O(h)') %Kiểm tra loại sai số O(h) 
        if strcmp(fx,'') %Nếu không nhập hàm số thì dùng công thức x y
            i = find(x1==x0); %Tìm và gán giá trị i nếu x1=x0
            fd1 = (y1(i)-y1(i-1))/h; %Công thức x y xấp xỉ lùi sai số O(h)
        else     %Nếu nhập hàm số thì dùng công thức trực tiếp 
        fx = str2func(['@(x)' char(fx)]); %Hàm chuyển string thành fuction
        fd1 = (fx(x0)-fx(x0-h))/h; %Công thức đạo hàm cấp 1 lùi sai số O(h)
        end
    elseif strcmp(Oh,'O(h^2)') %Kiểm tra loại sai số O(h^2) 
        if strcmp(fx,'') %Nếu không nhập hàm số thì dùng công thức x y
            i = find(x1==x0); %Tìm và gán giá trị i nếu x1=x0
            fd1 = (3.*y1(i)-4.*y1(i-1)+y1(i-2))./(2*h); %Công thức x y xấp xỉ lùi sai số O(h^2)
        else  %Nếu nhập hàm số thì dùng công thức trực tiếp    
        fx = str2func(['@(x)' char(fx)]); %Hàm chuyển string thành fuction
        fd1 = (3.*fx(x0)-4.*fx(x0-h)+fx(x0-2*h))./(2*h); %Công thức đạo hàm cấp 1 lùi sai số O(h^2)
        end
    end
end