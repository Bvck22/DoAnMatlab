% e4prob803
% Solution of Problem 8.03
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
nt = 512; 
T = 1; 
dt = T/nt;
df = 1/T;
fprintf('Frequency increment = %4.2f Hz \n',df)
fmax = (nt/2)*df;
fprintf('Nyquist frequency = %4.2f Hz \n',fmax)
f1 = 30;
f2 = 400;
t = 0:dt:(nt-1)*dt; 
y = sin(2*pi*f1*t)+2*sin(2*pi*f2*t);
Y = fft(y);

figure(1)
plot(0:511,imag(Y))
axis([0 511 -600 600])
xlabel('index k'); 
ylabel('imag(DFT)')
grid

fss = 0:df:(nt/2-1)*df;
Yss = zeros(1,nt/2); 
Yss(1:nt/2) = (2/nt)*Y(1:nt/2);

figure(2);
bar(fss,abs(Yss)); 
axis([0 fmax-df 0 2.5])
xlabel('frequency Hz'); 
ylabel('abs(DFT)')
grid

 
