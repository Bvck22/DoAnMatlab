% e4prob506
% Solution of Problem 5.6
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
f1 = @(t,x) 3*x./t;
[v1 w1] = rombergx(f1,[1 20]',8,1);
fprintf('Part (a): x = 20, solution = %6.2f \n',v1)
xf = 20;
e1 = xf^3;
fprintf('Part (a): x = 20, exact soln = %6.2f \n',e1)
display('Table:')
w1

f2 = @(t,x) 2*x.*t;
[v2 w2] = rombergx(f2,[0 2]',8,2);
fprintf('Part (b): x = 2, solution = %6.4f \n',v2)
xf = 2;
e2 = 2*exp(xf.^2);
fprintf('Part (b): x = 2, exact soln = %6.4f \n',e2)
display('Table:')
w2