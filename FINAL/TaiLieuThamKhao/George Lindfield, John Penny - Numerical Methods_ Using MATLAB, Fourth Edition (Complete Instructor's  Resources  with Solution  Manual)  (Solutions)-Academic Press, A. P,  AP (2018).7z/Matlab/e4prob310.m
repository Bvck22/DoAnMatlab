% e4prob310
% Solution of Problem 3.10
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
f2 = @(x) [exp(x(1)/10)-x(2) 2*log(x(2))-cos(x(1))-2]';
jf2 = @(x) [exp(x(1)/10)/10 -1; sin(x(1)) 2./x(2)];
[sol,iter] = newtonmv([1,1]',f2,jf2,2,1e-4);
fprintf('Using  Newton method, x = [%7.4f %7.4f] after %2.0f iterations \n',sol(1), sol(2), iter)

[sol,iter] = broyden([1,1]',f2,2,1e-4);
fprintf('Using Broyden method, x = [%7.4f %7.4f] after %2.0f iterations \n',sol(1), sol(2), iter)

% An alternative approach
f = @(x) x/5-cos(x)-2;
df = @(x) 1/5+sin(x);
[x, it] = fnewton(f,df,1,1e-4);
sol = [x; exp(x/10)];
fprintf('Using Newton method to solve x/5-cos(x)-2, x = [%7.4f %7.4f] after %2.0f iterations \n',sol(1), sol(2), it)

xp = -20:0.1:20;
y1 = exp(xp/10);
y2 = exp(1+0.5*cos(xp));

plot(xp,y1,xp,y2)
legend('exp(x/10)','exp(1+0.5*cos(x))')
xlabel('x')
ylabel('f(x)')
grid
axis([0 20 1 6])