% e4prob716
% Solution of Problem 7.16
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

x = [0.5 1.0 1.0 2.0 2.5 2.0 3.0 3.5 4.0];
y = [2.0 4.0 5.0 2.0 4.0 5.0 2.0 4.0 5.0];
z = [-0.19 -0.32 -1.00 3.71 4.49 2.48 6.31 7.71 8.51];

Xd = [x; y; z];
[EV Rsquared b SE t VIF Corr res] = mregg2(Xd,1);
fprintf('MODEL 1\n')
fprintf('Error variance = %7.4f     R_squared = %7.4f \n\n',EV,Rsquared)
fprintf('                  Coeff     SE     t_ratio     VIF \n')
fprintf('Constant   :     %7.4f %7.4f %8.2f \n',b(1),SE(1),t(1))
fprintf('Coeff  x   :     %7.4f %7.4f %8.2f %8.2f\n',b(2),SE(2),t(2),VIF(2))
fprintf('Coeff  y   :     %7.4f %7.4f %8.2f %8.2f\n',b(3),SE(3),t(3),VIF(3))
fprintf('\n')
fprintf('Correlation matrix \n')
disp(Corr)
fprintf('\n        z         Residual   St Residual   Cook dist\n')
for i = 1:length(Xd)
    fprintf('%12.4f %12.4f %12.4f %12.4f\n',res(i,1), ...
                                   res(i,2), res(i,3), res(i,4))
end

Xd = [x; y; x.*y; z];
[EV Rsquared b SE t VIF Corr res] = mregg2(Xd,1);
fprintf('\n')
fprintf('MODEL 2\n')
fprintf('Error variance = %7.4f     R_squared = %7.4f \n\n',EV,Rsquared)
fprintf('                  Coeff     SE     t_ratio     VIF \n')
fprintf('Constant   :     %7.4f %7.4f %8.2f \n',b(1),SE(1),t(1))
fprintf('Coeff x    :     %7.4f %7.4f %8.2f %8.2f\n',b(2),SE(2),t(2),VIF(2))
fprintf('Coeff y    :     %7.4f %7.4f %8.2f %8.2f\n',b(3),SE(3),t(3),VIF(3))
fprintf('Coeff xy   :     %7.4f %7.4f %8.2f %8.2f\n\n',b(4),SE(4),t(4),VIF(4))
fprintf('\n')
fprintf('Correlation matrix \n')
disp(Corr)
fprintf('\n        z         Residual   St Residual   Cook dist\n')
for i = 1:length(Xd)
    fprintf('%12.4f %12.4f %12.4f %12.4f\n',res(i,1), ...
                                   res(i,2), res(i,3), res(i,4))
end

