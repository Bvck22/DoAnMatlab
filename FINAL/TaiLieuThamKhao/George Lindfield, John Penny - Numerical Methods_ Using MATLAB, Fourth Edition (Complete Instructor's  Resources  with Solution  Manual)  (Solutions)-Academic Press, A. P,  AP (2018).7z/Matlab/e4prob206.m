% e4prob206
% Solution of Problem 2.6
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [ 2.0 -3.0  2.0;
      1.9 -3.0  2.2;
      2.1 -2.9  2.0;
      6.1  2.1 -3.0;
     -3.0  5.0  2.1];
 
 b = [1.01 1.01 0.98 4.94 4.10].';
 
 x1 = A\b;
 
 x2 = pinv(A)*b;
 
 [Q,R] = qr(A);
 y = Q'*b;
 x3 = R\y;
 
 fprintf('   using backslash     using pinv        using lu\n')
 for k = 1:3
     fprintf('%16.8f %16.8f %16.8f\n',x1(k), x2(k), x3(k))
 end
     