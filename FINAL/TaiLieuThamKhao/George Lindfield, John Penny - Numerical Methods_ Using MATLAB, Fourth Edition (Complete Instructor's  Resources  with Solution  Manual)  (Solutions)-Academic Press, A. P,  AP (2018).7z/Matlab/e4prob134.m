% e4prob134
% Solution of Problem 1.34
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
fimplicit3(@ (x,y,z) x.^3+y.^3 +z.^3+ 6* x .*y .*z,[-4  4])
xlabel('x value'), ylabel('y value'), zlabel('z value')
title('Plot of (x^3+y^3+z^3)+6xyz=0')