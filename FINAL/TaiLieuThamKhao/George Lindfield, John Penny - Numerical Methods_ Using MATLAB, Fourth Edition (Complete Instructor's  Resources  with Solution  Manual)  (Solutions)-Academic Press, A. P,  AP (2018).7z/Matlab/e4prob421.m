% e4prob421
% Solution of Problem 4.21
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

ex = [0.493107418 0.946083070 1.605412977];
c = 1;
for z = [0.5 1 2]
    si = fgauss(@(x) sin(x)./x,0,z,16);
    fprintf('Si(%3.1f) = %8.6f (Exact = %8.6f)\n',z,si,ex(c))
    c = c+1;
end

figure(1)
x = 0:0.02:2;
plot(x,sin(x)./x)
xlabel('x')
ylabel('y=f(x)')
grid