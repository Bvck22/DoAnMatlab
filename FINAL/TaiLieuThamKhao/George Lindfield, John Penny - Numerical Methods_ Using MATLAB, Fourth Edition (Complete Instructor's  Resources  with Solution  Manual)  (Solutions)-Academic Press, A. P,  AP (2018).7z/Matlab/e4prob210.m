% e4sprob210
% Solution of Problem 2.10
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

for n = [20 50]
    for m = 1:n
        for j = 1:n
            if m==j
                C(m,j) = m*(n-m+1);
            elseif j>m
                C(m,j) = C(m,j-1)-m;
            else
                C(m,j) = C(j,m);
            end
        end
    end
    b = 1:n;
    E = C/(n+1);
    cnd = cond(E);
    exact = 4*n^2/pi^2;
    fprintf('n = %3.0f: estimated condition number = %12.6f\n',n,cnd)
    fprintf('n = %3.0f:     exact condition number = %12.6f\n',n,exact)   
end