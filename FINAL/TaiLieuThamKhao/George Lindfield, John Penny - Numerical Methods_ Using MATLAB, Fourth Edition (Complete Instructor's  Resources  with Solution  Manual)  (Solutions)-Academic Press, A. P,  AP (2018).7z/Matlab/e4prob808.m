% e4prob808
% Solution of Problem 8.08
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

close all
clear all

y1 = @(t) 0.2*cos(2*pi*20*t)+0.35*sin(2*pi*50*t)+0.3*sin(2*pi*70*t);

T = 2; n = 512;
dt = T/n; t_rng = dt:dt:T; dt_plt = dt/25;
t_plt = dt_plt:dt_plt:T/4;
figure(1), plot(t_plt, y1(t_plt))
grid
xlabel('time s')
ylabel('y_1(t)')
title('Part a: Sampled time series')

ds = 2/T;
s_cal = [0:(n/2-1)]*ds;  s_sal = [0:n/2]*ds; s_pwr = s_sal;
s_max = n/2;

wal_y1 = dwht(y1(t_rng),1);
[CAL1, SAL1, PWR1] = walshps(wal_y1);

figure(2)
subplot(2,1,1)
plot(s_cal,CAL1)
grid
xlabel('Sequency z/s')
ylabel('CAL(y_1)')
axis([0 s_max -80 80])
title('Part a: CAL spectrum')

subplot(2,1,2)
plot(s_sal,SAL1)
grid
xlabel('Sequency z/s')
ylabel('SAL(y_1)')
axis([0 s_max -80 80])
title('Part a: SAL spectrum')

figure(3)
subplot(2,1,1)
plot(s_pwr,PWR1)
grid
xlabel('Sequency z/s')
ylabel('Power(y_1)')
axis([0 s_max 0 6000])
title('Part a: Walsh power spectrum')

df = 1/T; f_max = df*n/2; f_rng = [0:n/2-1]*df;
fou_y1 = fft(y1(t_rng));
fou_pwr2 = fou_y1.*conj(fou_y1);

subplot(2,1,2)
plot(f_rng,fou_pwr2(1:n/2))
grid
xlabel('Frequency Hz')
ylabel('Amplitude')
axis([0 f_max 0 9000])
title('Part a: Fourier power spectrum')

P1 = sum(y1(t_rng).^2);
P2 = sum(PWR1)/n;
P3 = sum(fou_pwr2)/n;

fprintf('Power from data y1 = %7.4f\n', P1)
fprintf('Power from Walsh transform = %7.4f\n', P2)
fprintf('Power from Fourier transform = %7.4f\n', P3)

y2 = @(t) 0.2*sign(cos(2*pi*20*t))+0.35*sign(sin(2*pi*50*t))+0.3*sign(sin(2*pi*70*t));

figure(4), plot(t_plt, y2(t_plt))
grid
xlabel('time s')
ylabel('y_2(t)')
title('Part b: Sampled time series')

wal_y2 = dwht(y2(t_rng),1);
[CAL2, SAL2, PWR2] = walshps(wal_y2);

figure(5), 
subplot(2,1,1)
plot(s_cal,CAL2)
grid
xlabel('Sequency z/s')
ylabel('CAL(y_2)')
axis([0 s_max -80 80])
title('Part b: CAL spectrum')

subplot(2,1,2)
plot(s_sal,SAL2)
grid
xlabel('Sequency z/s')
ylabel('SAL(y_2)')
axis([0 s_max -80 80])
title('Part b: SAL spectrum')

figure(6), 
subplot(2,1,1)
plot(s_pwr,PWR2)
grid
xlabel('Sequency z/s')
ylabel('Power(y_2)')
axis([0 s_max 0 12000])
title('Part b: Walsh power spectrum')

fou_y2 = fft(y2(t_rng));
fou_pwr2 = fou_y2.*conj(fou_y2);
subplot(2,1,2)
plot(f_rng,fou_pwr2(1:n/2))
grid
xlabel('Frequency Hz')
ylabel('Amplitude')
axis([0 f_max 0 15000])
title('Part b: Fourier power spectrum')

P1 = sum(y2(t_rng).^2); length(y2(t_rng))
P2 = sum(PWR2)/n; length(PWR2)
P3 = sum(fou_pwr2)/n; length(fou_pwr2)
n
fprintf('Power from data y2 = %7.4f\n', P1)
fprintf('Power from Walsh transform = %7.4f\n', P2)
fprintf('Power from Fourier transform = %7.4f\n', P3)