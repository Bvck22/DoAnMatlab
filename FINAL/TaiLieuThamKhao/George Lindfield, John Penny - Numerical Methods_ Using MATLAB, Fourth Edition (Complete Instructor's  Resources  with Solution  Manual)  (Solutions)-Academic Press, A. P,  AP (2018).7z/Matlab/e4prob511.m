% e4prob511
% Solution of Problem 5.11
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
r1 = 1;
r2 = 0.3;
c = 0.001;
b1 = 1.8;
b2 = 0.5;
f = @(t,y) [y(1)*(r1-c*y(1)-b1*y(2));
              y(2)*(r2-b2*y(2)./y(1))];
          
[t,y] = ode45(f,[0 40],[15 15]');

figure(1)
plot(t,y(:,1),t,y(:,2))
xlabel('Time')
ylabel('N1, N2')
axis([0 40 0 5])
legend('N1', 'N2')

fprintf('At t = 40, Species 1 = %6.4f \n',y(end,1))
fprintf('At t = 40, Species 2 = %6.4f \n',y(end,2))
