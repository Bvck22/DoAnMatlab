% e4prob427
% Solution of Problem 4.27
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f = @(x) cos(x)./(1+x.^2);
val = gaherm(f,16);
fprintf('   Estimate of integral = %6.5f\n',val)
fprintf('Exact value of integral = %6.5f\n',pi/exp(1))