% e4prob703
% Solution of Problem 7.3
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

x = -1:0.2:1;
y = sin(pi*x/2).^2;
co = polyfit(x,y,2);
fprintf('Constant : %8.4f\n',co(3))
fprintf('Coeff   x: %8.4f\n',co(2))
fprintf('Coeff x^2: %8.4f\n',co(1))
co1 = polyfit(x,y,4);
fprintf('\n')
fprintf('Constant : %8.4f\n',co1(5))
fprintf('Coeff   x: %8.4f\n',co1(4))
fprintf('Coeff x^2: %8.4f\n',co1(3))
fprintf('Coeff x^3: %8.4f\n',co1(2))
fprintf('Coeff x^4: %8.4f\n',co1(1))
xp = -1:0.01:1;
y1 = polyval(co,xp);
y2 = polyval(co1,xp);
ys = spline(x,y,xp);

figure(1),plot(x,y,'ko')
hold on
plot(xp,y1,'b')
plot(xp,y2,'r')
xlabel('x-axis')
ylabel('y-axis')
legend('data value','quadratic', 'quartic')
title( 'Quadratic and quartic best fits')
hold off

figure(2),plot(x,y,'ko')
hold on
plot(xp,ys,'r')
xlabel('x-axis')
ylabel('y-axis')
title('spline plot')
hold off

