% e4prob711
% Solution of Problem 7.11
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
E = [-3.5 -10.5 -14 -14.25 -9 -4 1 3.5 3 -0.25 -3.5 -6.25 -5.5 ...
           -1.75 4 10.5 15 16.25 12.75 6.5];       
t0 = 0:0.05:0.95;

m = 300;
factor = m/length(E);
t  = 1:factor:m;
ti = 1:m;
Ei = interpft(E,m);

figure(1), plot(t,E,'o',ti,Ei,'-')
xlabel('points')
ylabel('E')
axis([0 300 -20 20])
title('Plot of (mean-real) Sun time, showing Fourier interpolated values')
grid


 
disp('Select max and min on graph (4)')
[n,Es] = ginput(4);
fprintf('1st selection: month = %8.4f, Es = %8.4f\n',n(1)*12/m,Es(1))
fprintf('2nd selection: month = %8.4f, Es = %8.4f\n',n(2)*12/m,Es(2))
fprintf('3rd selection: month = %8.4f, Es = %8.4f\n',n(3)*12/m,Es(3))
fprintf('4th selection: month = %8.4f, Es = %8.4f\n',n(4)*12/m,Es(4))

figure(2), plot(t0,E,'o',ti/m,Ei,'-')
xlabel('year')
ylabel('E')
title('(mean-real) Sun time v year, showing Fourier interpolated values')
axis([0 1 -20 20])
grid


Eii = interp1(t0,E,ti/m,'pchip');
figure(3), plot(t0,E,'o',ti/m,Eii,'-')
xlabel('year')
ylabel('E')
title('(mean-real) Sun time v year, showing cubic interpolated values')
axis([0 1 -20 20])
grid
