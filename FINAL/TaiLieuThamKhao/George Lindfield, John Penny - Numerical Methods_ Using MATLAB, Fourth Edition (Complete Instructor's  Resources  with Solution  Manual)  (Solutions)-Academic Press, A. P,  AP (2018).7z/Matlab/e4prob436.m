% e4prob436
% Solution of Problem 4.36
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
P00 = @(x) 1;
P01 = @(x) x;
P02 = @(x) (3*x.^2-1)/2;
P03 = @(x) (5*x.^3-3*x)/2;

P11 = @(x) x*x;
P12 = @(x) x*(3*x.^2-1)/2;
P13 = @(x) x*(5*x.^3-3*x)/2;

P22 = @(x) (3*x.^2-1).*(3*x.^2-1)/4;
P23 = @(x) (3*x.^2-1).*(5*x.^3-3*x)/4;

P33 = @(x) (5*x.^3-3*x).*(5*x.^3-3*x)/4;

format short
Int00 = fgauss(P00,-1,1,16);
Int01 = fgauss(P01,-1,1,16);
Int02 = fgauss(P02,-1,1,16);
Int03 = fgauss(P03,-1,1,16);

Int11 = fgauss(P11,-1,1,16);
Int12 = fgauss(P12,-1,1,16);
Int13 = fgauss(P13,-1,1,16);

Int22 = fgauss(P22,-1,1,16);
Int23 = fgauss(P23,-1,1,16);

Int33 = fgauss(P33,-1,1,16);

for n = 0:3
  I_exact(n+1) = 2/(2*n+1);
end
format short e
I_exact

A = [Int00 Int01 Int02 Int03;
     Int01 Int11 Int12 Int13;
     Int02 Int12 Int22 Int23;
     Int03 Int13 Int23 Int33]
 
 format short
 
 
