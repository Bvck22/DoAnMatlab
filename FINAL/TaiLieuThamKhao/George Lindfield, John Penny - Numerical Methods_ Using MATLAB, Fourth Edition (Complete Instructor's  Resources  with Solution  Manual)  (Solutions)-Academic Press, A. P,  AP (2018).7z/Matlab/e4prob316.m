% e4prob316
% Solution of Problem 3.16
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

M = 4.527594e-3;
e = 0.96727464;
func1 = @(x) x-e*sin(x)-M;

E = jarrett(func1,0.9,1.1,0.00005);
fprintf('Solution of Problem 3.7 using Illinois method, E = %7.4f\n',E)

Ep = -1:0.001:1;
figure(1), plot(Ep,func1(Ep))
title('Problem 3.7: E - e sin(E) = M')
xlabel('E')
ylabel('f(E)')
axis([-1 1 -0.1 0.1])
grid

func2 = @(x) x.^1.4-sqrt(x)+1./x-100;
x0 = jarrett(func2,45,50,1e-4);
fprintf('Solution of Problem 3.2 using Illinois method, x = %6.4f\n',x0)

xp = 1:0.2:50;
figure(2), plot(xp,func2(xp))
title('Problem 3.2: x^{1.4}- sqrt(x)+1/x = 100')
xlabel('x')
ylabel('f(x)')
axis([0 50 -100 100])
grid

