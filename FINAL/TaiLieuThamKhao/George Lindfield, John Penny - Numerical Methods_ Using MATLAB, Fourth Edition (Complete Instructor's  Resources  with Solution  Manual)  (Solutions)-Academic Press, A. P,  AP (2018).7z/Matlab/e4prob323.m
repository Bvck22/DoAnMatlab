% e4prob323
% Solution of Problem 3.23
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018
clear all
close all

p = 3; q = 4;

disp('by numerical analysis')
s = roots([1 0 3*p -2*q])

disp('by formulae')
r1 = nthroot(q+sqrt(q^2+p^3),3);
r2 = nthroot(q-sqrt(q^2+p^3),3);

w1 = (-1+j*sqrt(3))/2;
w2 = (-1-j*sqrt(3))/2;

x1 = r1+r2
x2 = w1*r1+w2*r2
x3 = w2*r1+w1*r2
