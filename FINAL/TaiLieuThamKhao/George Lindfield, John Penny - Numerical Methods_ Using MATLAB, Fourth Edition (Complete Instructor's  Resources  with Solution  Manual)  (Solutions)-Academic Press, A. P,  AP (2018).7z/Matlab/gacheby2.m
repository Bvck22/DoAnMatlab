function s = gacheby2(func,n)
% Integration of sqrt(1-x^2)*f(x) between -1 and 1
% func is f(x), n is the number of points.
%
% Required for Problem 4.11
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

k = 1:n;
x1 = cos(k*pi/(n+1));
f1 = feval(func,x1)*sin(k*pi/(n+1)).^2.';
s = (pi/(n+1))*f1;
end

