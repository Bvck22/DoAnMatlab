% e4prob411
% Solution of Problem 4.11
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f0 = @(x) exp(x);
f = @(x) exp(x)./sqrt(1-x.^2);
g = @(x) exp(x).*sqrt(1-x.^2);

fprintf('Part (a)\n')
ca = gacheby1(f0,10);
ga = fgauss(f,-1,1,16);
% Note that Simpson rule fails.
fprintf('By Gauss-Chebyshev: estimate = %8.5f\n',ca)
fprintf('By Gauss: estimate = %8.5f\n',ga)
fprintf('Simpsons rule fails\n\n')

fprintf('Part (b)\n')
cb = gacheby2(f0,10);
gb = fgauss(g,-1,1,16);
sb = simp1(g,-1,1,512);
fprintf('By Gauss-Chebyshev: estimate = %8.5f\n',cb)
fprintf('By Gauss: estimate = %8.5f\n',gb)
fprintf('By Simpson: estimate = %8.5f\n',sb)

xp = -1:0.001:1;
figure(1), plot(xp, f(xp))
xlabel('x')
ylabel('exp(x)/sqrt(1-x^2)')
title('Part (a)')
figure(2), plot(xp, g(xp))
xlabel('x')
ylabel('exp(x)*sqrt(1-x^2)')
title('Part (b)')



