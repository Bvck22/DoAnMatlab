function pd = f905df(x)

% This MATLAB function is to accompany 'Numerical Methods using MATLAB e4' 
% by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

pd=zeros(size(x));
pd(1)=0.5*(4*x(1).^3-32*x(1)+5);
pd(2)=0.5*(4*x(2).^3-32*x(2)+5);
pd(3)=2*(x(3)-1);
pd(4)=2*(x(4)-1);
pd(5)=2*(x(5)-1);