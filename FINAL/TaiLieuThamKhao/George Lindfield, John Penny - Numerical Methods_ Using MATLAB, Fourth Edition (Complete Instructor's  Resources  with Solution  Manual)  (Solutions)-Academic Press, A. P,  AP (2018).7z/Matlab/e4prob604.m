% e4prob604
% Solution of Problem 6.4
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x = 0:0.2:2; 
c = x;
d = 2*ones(1,length(x));
e = -x;
f1 = exp(x);
fd_y = twopoint(x,c,d,e,f1,1,1,0.5,3.694528);
exact_y = exp(x)/2;
disp('      x     Estimated   Exact')
[x.' fd_y exact_y']

[max_err idx] = max((fd_y-exact_y')./exact_y');
max_percent = max_err*100;
disp(['Max percentage error = ' num2str(max_percent) ...
        ' at x = ' num2str(x(idx))])

figure(1)

plot(x,fd_y,'ko',x,exact_y,'r')
xlabel('x'), ylabel('y')
title('Solution of x d^2y/dx^2+2dy/dx-ex = e^x')
legend('FD approx', 'exact')
axis([0 2 0 4])
grid