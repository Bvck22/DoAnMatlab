% e4prob806
% Solution of Problem 8.06
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

close all
clear all

y = @(t) 3*sin(8*pi*t).*(t<3)+4*sin(14*pi*t).*(t>=3 & t<=6)...
    + 6*sin(10*pi*t).*(t>6);

dt = 0.01;
t = dt:dt:10.24; 
n = length(t);
figure(1), plot(t,y(t))
axis([0 10.24  -8 8]) 
xlabel('time, t [s]'), ylabel('Signal, y(t)')
grid

y_bar = fhilb(y(t));

amp = abs(y_bar);
figure(2), plot(t,amp)
axis([0 10.24 1 7]) 
xlabel('time [s]'), ylabel('Signal amplitude')
grid

d_theta = zeros(size(t));
thetas = angle(y_bar);
theta = unwrap(thetas);
d_theta(1) = (theta(1)-theta(2))/dt;
for k = 2:n-1
    d_theta(k) = (theta(k+1)-theta(k-1))/(2*dt);
end
d_theta(n) = (theta(n-1)-theta(n))/dt;
figure(3), plot(t,d_theta/2/pi)
axis([0 10.24 0 8]) 
xlabel('time [s]'), ylabel('Signal frequency [Hz]')
grid

