% e4prob426
% Solution of Problem 4.26
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f = @(x) sin(x)./(1+x.^2);
val = gaherm(f,16);
fprintf('Value of integral = %10.9f\n',val)