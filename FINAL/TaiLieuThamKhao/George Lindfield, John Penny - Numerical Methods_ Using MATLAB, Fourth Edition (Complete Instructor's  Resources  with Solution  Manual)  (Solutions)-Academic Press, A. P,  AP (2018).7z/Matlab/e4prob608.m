% e4prob608
% Solution of Problem 6.8
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
nx = 15; ny = 15; 
hx = 0.5/15; hy = hx;
x = 0:hx:0.5; y = 0:hy:0.5;
by0 = sin(pi*y.^2);
byn = sin(pi*(y.^2+0.25));
bx0 = sin(pi*x.^2);
bxn = sin(pi*(x.^2+0.25));
[xx,yy] = meshgrid(x,y);
F = 4*pi*cos(pi*(xx.^2+yy.^2)); 
G = 4*pi*(xx.^2+yy.^2);
Ve = ellipgen(nx,hx,ny,hy,G,F,bx0,bxn,by0,byn);
Ve = flipud(Ve);

figure(1)
surf(x,y,Ve)
xlabel('x direction')
ylabel('y direction')
zlabel('V')
axis([0 0.5 0 0.5 0 1])
title('Finite difference approximation')

figure(2)
[x,y] = meshgrid(0:0.01:0.5,0:0.01:0.5);
V = sin(pi*(x.^2+y.^2));
surf(x,y,V)
xlabel('x direction')
ylabel('y direction')
zlabel('V')
axis([0 0.5 0 0.5 0 1])
title('Exact solution')

% Generate a mesh of size as FD mesh
[x,y] = meshgrid(0:hx:0.5,0:hy:0.5);
Vr = sin(pi*(x.^2+y.^2));

figure(3)
surf(x,y,(Vr-Ve))
xlabel('x direction')
ylabel('y direction')
zlabel('V')
axis([0 0.5 0 0.5 -0.1 0.1])
title('Error')

max_error = max(max(Vr-Ve))





