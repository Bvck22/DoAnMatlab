% e4prob708
% Solution of Problem 7.8
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
lp = primes(103);
p = lp(1:end-1);
P_cap = lp(2:end);
prset = [ ];
prd = 1;
for k = 1:length(P_cap)
    prd = prd*(1+1/p(k));
    prset(k) = prd;
end
C = polyfit(log(P_cap), prset,1);
fprintf('Product (p<P) = %6.4f + %6.4f *log(P) \n', C(2), C(1))
x = 3:0.5:103;
y = C(2)+C(1)*log(x);
figure(1)
plot(x,y,P_cap,prset,'o')  
xlabel('Prime P')
ylabel('Product of (1+1/p), p<P')
axis([0 110 0 7])
legend('Fit to data','Prime numbers P')
return



