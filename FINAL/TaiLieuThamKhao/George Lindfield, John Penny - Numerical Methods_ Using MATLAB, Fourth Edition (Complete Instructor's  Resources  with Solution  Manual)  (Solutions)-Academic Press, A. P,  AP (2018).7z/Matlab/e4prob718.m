% e4prob718
% Solution of Problem 7.18
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

mach_no = [1 2 3 4 5];
p_ratio = [1 4.5 10.333 18.5 29];
mn = 4.4;
p = interp1(mach_no,p_ratio,mn,'linear');
fprintf('\n Linear interpolation: pressure = %5.2f',p)
p = interp1(mach_no,p_ratio,mn,'spline');
fprintf('\n Aitken interpolation: pressure = %5.2f',p)
p = aitken(mach_no,p_ratio,mn);
fprintf('\n Spline fit: pressure = %5.2f\n',p)

