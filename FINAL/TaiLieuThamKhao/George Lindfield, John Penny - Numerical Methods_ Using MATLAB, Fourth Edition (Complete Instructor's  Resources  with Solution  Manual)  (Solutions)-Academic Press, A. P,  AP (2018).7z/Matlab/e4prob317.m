% e4prob317
% Solution of Problem 3.17
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

a = 100.12;
tol = 0.000005;

x = 1000;
d = 1;
iter = 0;
while abs(d)>tol
    iter = iter+1;
    x1 = (x+a/x)/2;
    d = x1-x;
    x = x1;
    sol(iter) = x;
end
fprintf('Using 2nd order method, x = %6.4f after %2.0f iterations \n', sol(end), iter)

x1 = 1000;
d1 = 1;
iter = 0;
while abs(d1)>tol
    iter = iter+1;
    x2 = (x1+a/x1)/2-(x1-a/x1).^2/(8*x1);
    d1 = x2-x1;
    x1 = x2;
    sol(iter) = x1;
end
fprintf('Using 3rd order method, x = %6.4f after %2.0f iterations \n', sol(end), iter)

xp = 5:0.1:15;
y = xp.^2-a;
plot(xp,y)
axis([5 15 -60 60])
grid
xlabel('x')
ylabel('f(x)')