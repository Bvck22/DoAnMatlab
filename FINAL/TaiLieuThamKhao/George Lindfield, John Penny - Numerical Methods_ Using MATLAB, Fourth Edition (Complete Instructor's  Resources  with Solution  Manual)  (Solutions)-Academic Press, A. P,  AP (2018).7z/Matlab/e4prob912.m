% e4prob912
% Solution of Problem 9.12
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
[xx,yy] = meshgrid(-4:0.1:4,-4:0.1:4);
pp = xx.^2+yy.^2;
zz = (1-xx).^2.*exp(-pp)-pp.*exp(-pp)-exp(-(xx+1).^2-yy.^2); 

figure(1)
surf(xx,yy,zz)
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')
title('mexhat plot')

figure(2)
contour(xx,yy,zz,50)
xlabel('x-axis')
ylabel('y-axis')
title('contour plot')
grid

disp('Select 3 values of min and max from contour plot Figure 2.')
optp = ginput(3);
x = optp(:,1);
y = optp(:,2);
p = x.^2+y.^2;
z = (1-x).^2.*exp(-p)-p.*exp(-p)-exp(-(x+1).^2-y.^2);
[zx,idx] = max(z);
[zn idn] = min(z);
fprintf('graphical estimate. max(z) = %5.2f at x = %5.2f y = %5.2f \n',zx,x(idx),y(idx))
fprintf('graphical estimate. min(z) = %5.2f at x = %5.2f y = %5.2f \n',zn,x(idn),y(idn))

figure(3)
y = -0.8:0.005:0; d = 0.94436; x = [d-0.025 d d+0.025];
[xx,yy] = meshgrid(x,y);
pp = xx.^2+yy.^2;
zz = (1-xx).^2.*exp(-pp)-pp.*exp(-pp)-exp(-(xx+1).^2-yy.^2); 
plot(y, zz)
grid, xlabel('y'), ylabel('z')
axis([-0.7 0 -0.39 -0.37])
legend('x = 0.9194','x = 0.9444','x = 0.9694') 

fopt = @(x) (1-x(1)).^2.*exp(-(x(1).^2+x(2).^2))...
         -(x(1).^2+x(2).^2).*exp(-(x(1).^2+x(2).^2))...
              -exp(-(x(1)+1).^2-x(2).^2);
          
gopt = @(x) -((1-x(1)).^2.*exp(-(x(1).^2+x(2).^2))...
         -(x(1).^2+x(2).^2).*exp(-(x(1).^2+x(2).^2))...
              -exp(-(x(1)+1).^2-x(2).^2));
     
[x,fval] = fminsearch(fopt,[0 0]);
fprintf('\nminimum = %10.6f at [%8.5f %8.5f]\n',fval,x)

[x,gval] = fminsearch(gopt,[0 0]);
fprintf('maximum = %10.6f at [%8.5f %8.5f]\n',-gval,x)
