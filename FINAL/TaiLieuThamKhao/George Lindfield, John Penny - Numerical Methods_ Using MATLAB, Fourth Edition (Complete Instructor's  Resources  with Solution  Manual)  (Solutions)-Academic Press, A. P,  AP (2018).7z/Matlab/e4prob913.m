% e4prob913
% Solution of Problem 9.13
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
[xx,yy] = meshgrid(-4:0.1:4,-4:0.1:4);
pp = xx.^2+yy.^2;
zz = (1-xx).^2.*exp(-pp)-pp.*exp(-pp)-exp(-(xx+1).^2-yy.^2); 

figure(1)
surf(xx,yy,zz)
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')
title('mexhat plot')

figure(2)
contour(xx,yy,zz,20)
xlabel('x-axis')
ylabel('y-axis')
title('contour plot')
grid

% Negative of mex hat function
fopt = @(x) -((1-x(1)).^2.*exp(-(x(1).^2+x(2).^2))...
         -(x(1).^2+x(2).^2).*exp(-(x(1).^2+x(2).^2))...
              -exp(-(x(1)+1).^2-x(2).^2));
          
r1 = -4*[1 1]'; r2 = 4*[1 1]';
[fval0,xval0] = diffevo(fopt, 2, r1, r2, 0.85, 0.5, 50, 1000);
for k = 2:20
    [fval,xval] = diffevo(fopt, 2, r1, r2, 0.85, 0.5, 50, 1000);
    if fval < fval0
        fval0 = fval;
        xval0 = xval;
    end
end

fprintf('Mexhat function: Best estimate of max(f) = %6.4f at x = [%6.4f %6.4f]\n\n',-fval0,xval0(1),xval0(2))

% Mex hat function
gopt = @(x) ((1-x(1)).^2.*exp(-(x(1).^2+x(2).^2))...
         -(x(1).^2+x(2).^2).*exp(-(x(1).^2+x(2).^2))...
              -exp(-(x(1)+1).^2-x(2).^2));
                    
[fval0,xval0] = diffevo(gopt, 2, r1, r2, 0.85, 0.5, 50, 1000);
for k = 2:20
    [fval,xval] = diffevo(gopt, 2, r1, r2, 0.85, 0.5, 50, 1000);
    if fval < fval0
        fval0 = fval;
        xval0 = xval;
    end
end    
fprintf('Mexhat function: Best estimate of min(f) = %6.4f at x = [%6.4f %6.4f]\n\n',fval0,xval0(1),xval0(2))

