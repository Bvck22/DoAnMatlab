% e4prob802
% Solution of Problem 8.02
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

nt = 512; 
T = 1; 
dt = T/nt;
df = 1/T;
fprintf('Frequency increment = %4.2f Hz \n',df)
fmax = (nt/2)*df;

f0 = 30;
t = 0:dt:(nt-1)*dt; 
f = 0:df:(nt/2-1)*df;

y = 32*sin(2*pi*f0*t).^5;
Y = (2/nt)*fft(y);
figure(1)
bar(f,imag(Y(1:nt/2)))
axis([0 300 -25 15])
xlabel('Frequency Hz')
ylabel('imag(DFT)')
title('Imaginary part of DFT v frequency')
grid
fprintf('Coeff  of  sin(2*pi*f*t) = %6.2f \n',-imag(Y(31)))
fprintf('Coeff of sin(2*pi*3*f*t) = %6.2f \n',-imag(Y(91)))
fprintf('Coeff of sin(2*pi*5*f*t) = %6.2f \n\n',-imag(Y(151)))

y = 32*sin(2*pi*f0*t).^6;
Y = (2/nt)*fft(y);
figure(2)
bar(f,real(Y(1:nt/2)))
axis([0 300 -20 25])
xlabel('Frequency Hz')
ylabel('real(DFT)')
title('Real part of DFT v frequency')
grid
fprintf('Coefficient  of constant = %6.2f \n', real(Y(1))/2)
fprintf('Coeff of cos(2*pi*2*f*t) = %6.2f \n',real(Y(61)))
fprintf('Coeff of cos(2*pi*4*f*t) = %6.2f \n',real(Y(121)))
fprintf('Coeff of cos(2*pi*6*f*t) = %6.2f \n',real(Y(181)))

 

