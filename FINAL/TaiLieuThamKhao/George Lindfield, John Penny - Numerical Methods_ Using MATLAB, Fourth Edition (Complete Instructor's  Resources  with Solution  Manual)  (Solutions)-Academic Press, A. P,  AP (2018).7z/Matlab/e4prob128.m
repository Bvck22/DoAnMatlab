% e4prob128
% Solution of Problem 1.28
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

close all
clear all
% Using user defined functions
x = 0:0.1:2;
figure(1)
subplot(1,2,1), plot(x,e4prob128fa(x))
xlabel('x')
ylabel('y')
title('Using user defined function')
subplot(1,2,2), plot(x,e4prob128fb(x))
xlabel('x')
ylabel('y')
title('Using user defined function')

[x,y] = meshgrid(x,x);
figure(2)
surf(x,y,e4prob128fc(x,y))
xlabel('x')
ylabel('y')
zlabel('z')
title('Using user defined function')

clear all
% Using anonymous functions
y0 = @(x) x.^2.*cos(1+x.^2);
y1 = @(x) (1+exp(x))./(cos(x)+sin(x));
z = @(x,y) cos(x.^2+y.^2);

x = 0:0.1:2;
figure(3)
subplot(1,2,1), plot(x,y0(x))
xlabel('x')
ylabel('y')
title('Using anonymous function')
subplot(1,2,2), plot(x,y1(x))
xlabel('x')
ylabel('y')
title('Using anonymous function')

[x,y] = meshgrid(x,x);
figure(4)
surf(x,y,z(x,y))
xlabel('x')
ylabel('y')
zlabel('z')
title('Using anonymous function')

