% e4prob405
% Solution of Problem 4.5
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f = @(x,y) exp(x.^2+y.^3);
x = 2; 
y = 1;
h = 0.005;
[pdiffx,pdiffy] = pdiff(f,x,y,h);
exactx = 2*x*exp(x^2+y^3);
exacty = 3*y^2*exp(x^2+y^3);
    
fprintf('Approx first derivative wrt x = %11.6f\n',pdiffx)
fprintf('Exact  first derivative wrt x = %11.6f\n',exactx)
fprintf('Approx first derivative wrt y = %11.6f\n',pdiffy)
fprintf('Exact  first derivative wrt y = %11.6f\n',exacty)
    
    
