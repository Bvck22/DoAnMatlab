% e4prob105
% Solution of Problem 1.5
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
A = input('Enter a 3 x 3 matrix')
B = input('Enter another 3 x 3 matrix')

% A = [1 2 3;4 5 6;1 1 1];
% B = [2 2 1;0 0 1;0 1 0];

disp('Difference of two matrices')
C = A-B
disp('Sum of two matrices')
D = A+B
disp('Product of two matrices')
P = A*B