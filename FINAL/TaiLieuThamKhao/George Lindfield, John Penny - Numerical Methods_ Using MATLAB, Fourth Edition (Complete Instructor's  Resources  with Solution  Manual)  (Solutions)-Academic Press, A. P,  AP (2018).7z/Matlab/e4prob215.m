% e4prob215
% Solution of Problem 2.15
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

n = 10;

% Exact
c = -n*(n+1)*(2*n-5)/6;
b = -(n+1);
r1 = (-b+sqrt(b^2-4*c))/2;
r2 = (-b-sqrt(b^2-4*c))/2;
lame1 = [r2  1 1 1 1 1 1 1  1 r1]';
lame2 = [r1 r2 1 1 1 1 1 1 1 1]';

a1 = [1:n].';
A = [eye(n-1);1:n-1];
A = [A,a1];

disp('Eigenvalues of A')
lam = eig(A);
disp(lam)

fprintf('norm(eigenvalue-exact) = %12.6e\n\n',norm(lam-lame1))

disp('Roots of polynomial of A')
v = poly(A);
lamr = roots(v);
disp(lamr)

fprintf('norm(poly_rts-exact) = %12.6e\n',norm(lamr-lame2))

