% e4prob315
% Solution of Problem 3.15
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

num_solution = roots([1 0 0 -0.5-sqrt(3)/2*i])
k = [1:3]'; 
exact_solution = cos((pi/3+2*pi*k)/3)+i*sin((pi/3+2*pi*k)/3)