function appinv = invapprox(A,k)
% appinv = invapprox(A,k)
%
% Required for Problem 2.19
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

ev = eig(A);
evm = max(ev);
if abs(evm) > 1
    disp('Method fails')
    appinv = eye(size(A));
else
    appinv = eye(size(A));
    for m = 1:k
        appinv = appinv+A^m;
    end
end
