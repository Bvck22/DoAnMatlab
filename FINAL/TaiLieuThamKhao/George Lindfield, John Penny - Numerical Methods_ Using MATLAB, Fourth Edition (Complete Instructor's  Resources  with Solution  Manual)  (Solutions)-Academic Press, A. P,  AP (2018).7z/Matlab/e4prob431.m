% e4prob431
% Solution of Problem 4.31
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

s = 2; m = 1; n = 3;

f = @(x,y,z) (1-cos(s*x).*cos(m*y).*cos(n*z))./(3-cos(x)-cos(y)-cos(z));

R = (1/pi^3)*integral3(f,0.0001,pi,0.0001,pi,0.0001,pi);

fprintf('Total resistance  (using integral3) = %10.8f\n',R) 
Ixyz = triplequad(@(x,y,z) (1-cos(2*x).*cos(y).*cos(3*z))./...
         (3-cos(x)-cos(y)-cos(z)),0.0001,pi,0.0001,pi,0.0001,pi);
R = Ixyz/pi^3;
fprintf('Total resistance (using triplequad) = %10.8f\n',R)