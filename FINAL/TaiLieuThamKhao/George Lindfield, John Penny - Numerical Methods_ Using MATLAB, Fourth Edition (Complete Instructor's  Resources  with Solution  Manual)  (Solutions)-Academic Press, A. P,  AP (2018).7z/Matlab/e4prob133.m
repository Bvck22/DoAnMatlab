% e4prob133
% Solution of Problem 1.33
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

fimplicit3(@ (x,y,z) sin(x.^2 +y.^2+z.^2.^2)-x.^2 .*y.^2 .*z.^2,[-4 4])
xlabel('x value'), ylabel('y value'), zlabel('z value')
title('Plot of sin(x^2+y^2+z^2)-x^2y^2z^2=0')