% e4prob903
% Solution of Problem 9.3
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [1 2 1 1 0;1 1 0 0 0;1 1 1 0 -1];
b = [30; 10; 8];
c = [2 -4 4 0 0];
c = -c;  % Change sign for max value
[usol,ind,object] = barnes(A,b,c,0.0001);

object = -object; % Change sign for max value

u0 = zeros(length(c),1);
for k = 1:length(usol)
    u0(ind(k)) = usol(k);
end

for k = 1:length(c)
    fprintf('u(%1.0f)   = %8.4f \n',k,u0(k))
end
fprintf('\nmax(z) = %8.4f \n\n', object)









