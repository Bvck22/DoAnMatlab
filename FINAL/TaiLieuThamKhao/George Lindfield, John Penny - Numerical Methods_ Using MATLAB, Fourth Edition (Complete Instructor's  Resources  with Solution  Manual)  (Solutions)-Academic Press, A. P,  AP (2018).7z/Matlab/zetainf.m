function r = zetainf(s,acc)
% r is the sum of the Reimann zeta(s) function. The summation terminates
% when the next term in the series is less than acc.

% Solution of Problem 1.23
%
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

sum = 0;
n = 1;
term = 1+acc;
while abs(term)>acc
    term = 1/n.^s;
    sum = sum+term;
    n = n+1;
end
r = sum;