% e4prob713
% Solution of Problem 7.13
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

x = 2:0.2:3;
Tau = [1.000 1.1018 1.2422 1.4296 1.6765 2];

x1 = interp1(Tau,x,1.3,'pchip');
y1 = gamma(x1);
fprintf('Using cubic  interpolation: x = %6.4f, gamma(x) = %8.6f\n',x1,y1)
x2 = aitken(Tau,x,1.3);
y2 = gamma(x2);
fprintf('Using aitken interpolation: x = %6.4f, gamma(x) = %8.6f\n',x2,y2)

% Check




