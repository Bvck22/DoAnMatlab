% e4prob509
% Solution of Problem 5.9
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
f = @(t,y) -5*y;

ttvals = 0:0.03:6;

i = 0;
for h = [0.1 0.2 0.25 0.4]
    i = i+1;
    [tvals, yvals] = abm(f,[0 6],50,h);
    fprintf('At t = 6, solution = %9.5f \n',yvals(end))
    figure(i), plot(tvals,yvals,'o-',ttvals,50*exp(-5*ttvals))
    xlabel('t')
    ylabel('y = f(t)')
    legend('estimate', 'exact')
    title(['Solution using ABM method with h = ' num2str(h)])
    axis([0 6 -100 150])
end