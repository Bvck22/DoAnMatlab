% e4prob603
% Solution of Problem 6.3
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

close all
clear all

% Part (a)
% Shooting method

% First trail

% Stage 1 - solve ode for several initial values s

s = [-5:0.2:5];
ncase = length(s);
b = zeros(1,ncase);

f = @(x,y) [62*y(1)-120*y(2); y(1)];
option = odeset('RelTol',0.0005);
for i = 1:ncase
    [x,y] = ode45(f,[0 1],[s(i) 0]',option); 
    b(1,i) = y(end,2);
end

figure(1)
plot(s,b,'o-')
axis([-5 5 -1e25 1e25])
title('At x = 0')
xlabel('trial gradient')
ylabel('intercept')
grid

% Second trial

% Stage 1 - solve ode for several initial values s

s = 1e-22*[-0.5:0.1:0.5];
ncase = length(s);
b = zeros(1,ncase);

option = odeset('RelTol',0.0005);
for i = 1:ncase
    [x,y] = ode45(f,[0 1],[s(i) 0]',option); 
    b(1,i) = y(end,2);
end

figure(2)
plot(s,b,'o-')
axis([-5e-23 5e-23 -5 5])
title('At x = 0')
xlabel('trial gradient')
ylabel('intercept')
grid

% Stage 2 - interpolation
s0 = aitken(b,s,2);

% Stage 3 - solve ode using computed initial gradient
[x1,y] = ode45(f,[0 1],[s0 0]',option);

ye_sh = 1.751302152539304e-26*(exp(60*x1)-exp(2*x1)).';
figure(3)
plot(x1,y(:,2),'ko-',x1,ye_sh,'r')
axis([0  1 -0.5 2])
legend('shooting using interpolated initial grad','exact')
title('Solution of d^2y/dx^2-62dy/dx+120y = 0')
ylabel('y')
xlabel('x')
grid

exact_grad0 = 1.751302152539304e-26*58;
[x5,y5] = ode45(f,[0 1],[exact_grad0 0]',option);
figure(4)
plot(x5,y5(:,2),'ko-',x1,ye_sh,'r')
axis([0  1 -0.5 2])
legend('shooting using exact initial gradient','exact')
title('Solution of d^2y/dx^2-62dy/dx+120y = 0')
ylabel('y')
xlabel('x')
grid

% FD10 
x2 = 0:0.02:1; 
c = ones(1,length(x2));
d = -62*ones(1,length(x2));
e = 120*ones(1,length(x2));
f1 = zeros(1,length(x2));
twopoint_y2 = twopoint(x2,c,d,e,f1,1,1,0,2);

ye_fd = 1.751302152539304e-26*(exp(60*x2)-exp(2*x2)).';

figure(5)
plot(x1,y(:,2),'ko-',x2,twopoint_y2,'r*-',x2,ye_fd,'b')
axis([0  1 -0.5 2])
xlabel('x'), ylabel('y')
legend('shooting using interpolated initial gradient','FD','exact')
title('Solution of d^2y/dx^2-62dy/dx+120y = 0')
grid

exact_grad1 = 1.751302152539304e-26*(60*exp(60)-2*exp(2));

% -------------------------------------------------------------
% Part (b)
% Shooting method

% Stage 1 - solve ode for several initial values s
% clear all
s = 0:-25:-150;
ncase = length(s);
b = zeros(1,ncase);
g = @(p,y) [-62*y(1)-120*y(2); y(1)];
option = odeset('RelTol',0.0005);
for i = 1:ncase
    [p,y] = ode45(g,[0 1],[s(i) 2]',option); 
    b(1,i) = y(end,2);
end

% Stage 2 - interpolation
s1 = aitken(b,s,0);
figure(6)
plot(s,b,'o-')
title('At p = 0 (x = 1)')
xlabel('trial gradient')
ylabel('intercept')
grid

fprintf('At x = 0, interpolated dy/dx = %12.10e \n', s0)
fprintf('At x = 0, exact dy/dx    = %12.10e \n', exact_grad0)
fprintf('Ratio of interpolated to exact gradient = %8.4f \n\n', s0/exact_grad0)
fprintf('At p = 0, (x = 1) interpolated dy/dp = %13.6e \n', s1)
fprintf('At p = 0, (x = 1) exact dy/dx    = %13.6e \n', exact_grad1)    

% Stage 3 - solve ode using correct initial gradient
[p1,y] = ode45(g,[0 1],[s1 2]',option);
% end_grad = y(end,1)

% FD10 
p2 = 0:0.02:1; 
c = ones(1,length(p2));
d = 62*ones(1,length(p2));
e = 120*ones(1,length(p2));
f1 = zeros(1,length(p2));
twopoint_y2 = twopoint(p2,c,d,e,f1,1,1,2,0);

% Exact
ye = 2*exp(-60*p1); 

figure(7)
plot(p1,y(:,2),'ko',p2,twopoint_y2,'r*',p1,ye,'b')
xlabel('p'), ylabel('y')
axis([0 1 -0.5 2])
legend('shooting','FD','exact')
title('Solution of d^2y/dp^2+62dy/dp+120y = 0')
grid

x1 = 1-p1;
x2 = 1-p2;

figure(8)
plot(x1,y(:,2),'ko',x2,twopoint_y2,'r*',x1,ye,'b')
xlabel('x'), ylabel('y')
axis([0 1 -0.5 2])
legend('shooting','FD','exact')
title('Solution of d^2y/dx^2-62dy/dx+120y = 0')
grid



