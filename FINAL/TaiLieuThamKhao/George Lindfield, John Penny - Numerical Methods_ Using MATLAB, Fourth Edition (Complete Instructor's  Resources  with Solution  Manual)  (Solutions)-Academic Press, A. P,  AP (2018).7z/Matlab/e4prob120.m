% e4prob120
% Solution of Problem 1.20
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
n = [ ]; 
n(1) = 1873;
c = 1; 
nc = n(1);
while nc>1
    if (n(c)/2)==floor(n(c)/2)
        n(c+1) = (n(c))/2;
    else
        n(c+1) = 3*n(c)+1;
    end
    nc = n(c+1);
    c = c+1;
    if c>1000
        break
    end
end
disp(['Number of steps = ' num2str(c-1)])
plot(n,'k-o')
xlabel('Steps')
ylabel('Function value')