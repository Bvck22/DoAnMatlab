% e4prob501
% Solution of Problem 5.1
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
f = @(t,y) -0.05*y;

[tvals, yvals] = feuler(f,[0 10],50,1);
fprintf('Euler h = 1, t(10) = %6.4f \n', yvals(end))
figure(1), plot(tvals,yvals,'o',tvals,50*exp(-0.05*tvals))
xlabel('t')
ylabel('f(t)')
legend('euler h = 1','exact')

[tvals, yvals] = feuler(f,[0 10],50,0.1);
fprintf('Euler h = 0.1, t(10) = %6.4f \n', yvals(end))
figure(2), plot(tvals,yvals,'o',tvals,50*exp(-0.05*tvals))
xlabel('t')
ylabel('f(t)')
legend('euler h = 0.1','exact')

[tvals, yvals] = feuler(f,[0 10],50,0.01);
fprintf('Euler h = 0.01, t(10) = %6.4f \n', yvals(end))
figure(3), plot(tvals,yvals,'o',tvals,50*exp(-0.05*tvals))
xlabel('t')
ylabel('f(t)')
legend('euler h = 0.01','exact')

[tvals, yvals] = eulertp(f,[0 10],50,1);
fprintf('Euler-trap h = 1, t(10) = %6.4f \n', yvals(end))
figure(4), plot(tvals,yvals,'o',tvals,50*exp(-0.05*tvals))
xlabel('t')
ylabel('f(t)')
legend('euler-trap h = 1','exact')

[tvals, yvals] = eulertp(f,[0 10],50,0.1);
fprintf('Euler-trap h = 0.1, t(10) = %8.6f \n', yvals(end))
figure(5), plot(tvals,yvals,'o',tvals,50*exp(-0.05*tvals))
xlabel('t')
ylabel('f(t)')
legend('euler-trap h = 0.1','exact')

[tvals,yvals] = rkgen(f,[0 10],50,1,1);
fprintf('Runge-Kutta h = 1, t(10) = %8.6f \n', yvals(end))
figure(6), plot(tvals,yvals,'o',tvals,50*exp(-0.05*tvals))
xlabel('t')
ylabel('f(t)')
legend('runge-kutta h = 1','exact')
fprintf('Exact, t(10) = %8.6f \n', 50*exp(-0.05*10))
