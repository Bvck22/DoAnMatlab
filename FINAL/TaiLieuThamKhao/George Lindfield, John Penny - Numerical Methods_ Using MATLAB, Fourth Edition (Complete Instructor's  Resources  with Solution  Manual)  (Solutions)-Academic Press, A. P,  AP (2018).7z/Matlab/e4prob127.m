% e4prob127
% Solution of Problem 1.27
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x = -4:0.001:4;
y = 1./(((x+2.5).^2).*((x-3.5).^2));
figure(1), plot(x,y)
xlabel('x value')
ylabel('y value')
figure(2), plot(x,y)
xlabel('x value')
ylabel('y value')
ylim([0,20])
xlim([-3,-2])
