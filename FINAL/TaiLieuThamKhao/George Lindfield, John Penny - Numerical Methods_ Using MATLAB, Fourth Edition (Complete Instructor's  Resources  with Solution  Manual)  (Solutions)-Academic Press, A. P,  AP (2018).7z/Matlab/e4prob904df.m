function f = e4prob904df(x)

% This MATLAB function is to accompany 'Numerical Methods using MATLAB e4' 
% by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

f = ones(2,1);
f(1)=  -400*x(1).*(x(2)-x(1).^2)-2*(1-x(1));
f(2) = 200*(x(2)-x(1).^2);
end

