function [pdx,pdy] = pdiff(f,x,y,h)
% [pdx,pdy] = pdiff(f,x,y,h)
% Estimates the partial differentiation of f(x,y) with respect to x and y
% using a finite difference approximation.
% h is the difference in the approximation of the derivative.
% Required for Problem 4.5
%
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

pdx = (feval(f,x+h,y)-feval(f,x-h,y))/(2*h);
pdy = (feval(f,x,y+h)-feval(f,x,y-h))/(2*h);