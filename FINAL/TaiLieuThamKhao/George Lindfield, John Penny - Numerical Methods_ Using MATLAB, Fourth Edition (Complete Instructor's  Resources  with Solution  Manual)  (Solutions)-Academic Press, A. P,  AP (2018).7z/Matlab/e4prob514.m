% e4prob514
% Solution of Problem 5.14
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
m = 1;
k = 4;
F = 1;
i = 0;
wn = sqrt(k/m);
damp = sqrt(m*k);
for c = damp*[0 0.3 1 2 4]   %{a b c d  e]
    i = i+1;
    f = @(t,y) [(F-c*y(1)-k*y(2))/m; y(1)];
    [t,y] = ode45(f,[0 8],[0 0]');
    figure(i), plot(t,y(:,2),'ko')
    grid
    xlabel('Time')
    ylabel('Response x(t)')
    title(['Response, c = ' num2str(c)])
    hold on
    zeta = c/(2*sqrt(m*k)); wd = wn*sqrt(1-zeta^2); 
    q = wn*sqrt(zeta^2-1); s1 =-zeta*wn+q; s2 = -zeta*wn-q;
    phi = atan(zeta/(sqrt(1-zeta^2)));
    t = 0:0.25:8;
    if i == 1 | i == 2 | i == 3
        x = (F/k)*(1-1/sqrt(1-zeta^2)*exp(-zeta*wn*t).*cos(wd*t-phi));
    end
    if i == 4
        x = (F/k)*(1-(1+wn*t).*exp(-wn*t));
    end
    if i == 5
        x = (F/k)*(1+1/(2*q)*(s2*exp(s1*t)-s1*exp(s2*t)));
    end
    plot(t,x,'r')
    legend('ode45','exact')
    hold off
end
