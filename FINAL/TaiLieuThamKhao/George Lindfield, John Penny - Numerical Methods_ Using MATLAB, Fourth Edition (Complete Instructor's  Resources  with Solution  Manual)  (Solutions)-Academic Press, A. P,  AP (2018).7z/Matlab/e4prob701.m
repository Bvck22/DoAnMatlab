% e4prob701
% Solution of Problem 7.1
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

alpha = 0:5:30;
E = [1.57079 1.56780 1.55888 1.54415 1.52379 1.49811 1.46746];

fprintf('\nFor alpha =  2 degree, tabulated E( 2) = 1.5703179\n')
fprintf('For alpha = 13 degree, tabulated E(13) = 1.5507320\n')
fprintf('For alpha = 27 degree, tabulated E(27) = 1.4864268\n\n')

i = 1;
for alpha0 = [2 13 27]
    v(i) = aitken(alpha,E,alpha0);
    fprintf('For alpha = %2.0f degree, estimate E(%2.0f)  = %9.7f\n',alpha0,alpha0,v(i))
    i = i+1;
end
plot(alpha,E,'ko')
xlabel('\alpha'), ylabel('E')
title('Tabulated values of E(\alpha)')

fprintf('\nFor alpha =  2 degree, error = %13.6e\n', v(1)-1.5703179)
fprintf('For alpha = 13 degree, error = %13.6e\n', v(2)-1.5507320')
fprintf('For alpha = 27 degree, error = %13.6e\n', v(3)-1.4864268')

