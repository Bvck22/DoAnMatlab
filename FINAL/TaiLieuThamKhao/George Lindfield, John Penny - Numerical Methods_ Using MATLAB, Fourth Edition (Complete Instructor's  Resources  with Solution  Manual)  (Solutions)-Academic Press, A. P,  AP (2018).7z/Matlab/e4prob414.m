% e4prob414
% Solution of Problem 4.14
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f = @(x) sin(x).*cos(100*x);
int0 = simp1(f,0,pi,64);
int1 = simp1(f,0,pi,1024);
int2 = romb(f,0,pi,8);
k = 100; exactval = 2./(1-k.*k);
fprintf('Using Simpson''s rule 64 points: I = %13.4e\n',int0)
fprintf('Using Simpson''s rule 1024  pts: I = %13.4e\n',int1)
fprintf('Using Romberg''s method:         I = %13.4e\n',int2)
fprintf('k = %1.0f,   exact value:         I = %13.4e\n',k,exactval)