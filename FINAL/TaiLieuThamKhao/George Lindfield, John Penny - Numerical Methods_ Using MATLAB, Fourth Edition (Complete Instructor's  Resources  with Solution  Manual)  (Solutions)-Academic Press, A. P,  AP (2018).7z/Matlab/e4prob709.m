% e4prob709
% Solution of Problem 7.9
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x = 0:0.1:1;
xx = 0:0.01:1;
y = gamma(1+x);
co = polyfit(x,y,5);
yy = polyval(co,xx);
figure(1)
plot(x,y,'ro',xx,yy,'k')
xlabel('x')
ylabel('\Gamma(1+x)')
title('5th degree polynomial fit to the Gamma function')

fprintf('         Constant  = %10.7f \n',co(6))
fprintf('Coefficient of x   = %10.7f \n',co(5))
fprintf('Coefficient of x^2 = %10.7f \n',co(4))
fprintf('Coefficient of x^3 = %10.7f \n',co(3))
fprintf('Coefficient of x^4 = %10.7f \n',co(2))
fprintf('Coefficient of x^5 = %10.7f \n\n',co(1))

as = [-0.1010678 0.4245549 -0.6998588 0.9512363 -0.5748666 1];
yy = polyval(as,xx);
figure(2)
plot(x,y,'ro',xx,yy,'k')
xlabel('x')
ylabel('\Gamma(1+x)')
title('Abramowitz and Stegun polynomial fit to the Gamma function')

v = [0.15 0.37 0.84];
y1 = polyval(as,v);
y2 = polyval(co,v);
y3 = gamma(1+v);
for k = 1:3
    fprintf('For x = %4.2f, difference Ab&St-Matlab = %10.7e \n',v(k),abs(y1(k)-y3(k)))
end
fprintf('\n')
for k = 1:3
    fprintf('For x = %4.2f, difference Polyfit-Matlab = %10.7e \n',v(k),abs(y2(k)-y3(k)))
end