% e4prob312
% Solution of Problem 3.12
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
f = @(x) [x(1).^3-3*x(1)*x(2).^2-0.5; 3*x(1).^2.*x(2)-x(2).^3-sqrt(3)/2];
jf = @(x) [3*x(1).^2-3*x(2).^2  -6*x(1)*x(2); 6*x(1)*x(2) 3*x(1).^2-3*x(2).^2];

[sol,iter] = newtonmv([1,2]',f,jf,2,1e-4);
fprintf('Using  Newton method, x = [%7.4f %7.4f] after %2.0f iterations \n',sol(1), sol(2), iter)

[sol,iter] = broyden([1,2]',f,2,1e-4);
fprintf('Using Broyden method, x = [%7.4f %7.4f] after %2.0f iterations \n',sol(1), sol(2), iter)