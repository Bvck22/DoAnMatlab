% e4prob212
% Solution of Problem 2.12
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [122  41  40  26  25;
      40 170  25  14  24;
      27  26 172   7   3;
      32  22   9 106   6;
      31  28  -2  -1 165];
  
  disp('Largest eigenvalue')
  largest_eig = eigit(A,5e-5);
  disp(largest_eig)
  
  disp('Nearest eigenvalue to 100')
  nearest_eig = eiginv(A,100,5e-5);
  disp(nearest_eig)
  
  disp('Smallest eigenvalue')
  smallest_eig = (eigit(inv(A),5e-5))^-1;
  disp(smallest_eig)
  
  disp('All eigenvalues')
  all_eig = sort(eig(A));
  disp(all_eig)