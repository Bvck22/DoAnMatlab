% e4prob217
% Solution of Problem 2.17
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

for n = [10 50]
    A = zeros(n);
    for i = 1:n
        A(i,:) = n:-1:1;
    end

    for i = 1:n
        for j = 1:i
            A(i,j) = n-i+1;
        end
    end
    
    lambda = eig(A);
    sum_lam = sum(lambda);
    tr = trace(A);
    prod_lam = prod(lambda);
    dt = det(A);
    fprintf('n = %2.0f eig_sum = %7.2f, trace = %7.2f: eig_prod = %4.2f, det = %4.2f.\n',n,sum_lam,tr,prod_lam,dt)
end
   