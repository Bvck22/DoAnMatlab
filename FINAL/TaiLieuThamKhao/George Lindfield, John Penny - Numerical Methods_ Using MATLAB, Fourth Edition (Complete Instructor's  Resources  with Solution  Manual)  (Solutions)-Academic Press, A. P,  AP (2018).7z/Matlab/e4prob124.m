% e4prob124
% Solution of Problem 1.24
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
% Demonsration of sumfac and sumfac2

for n = 4:2:16
    fprintf('n = %2.0f, sumfac = %12.10f, sumfac2 = %12.10f\n', n,sumfac(n),sumfac2(n))
end
