% e4prob502
% Solution of Problem 5.2
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
f = @(t,y) 2*t.*y;

ttvals = 0:0.05:2;

[tvals,yvals] = rkgen(f,[0 2],2,0.2,1);
fprintf('Classical Runge-Kutta h = 0.2, t(2) = %6.4f \n', yvals(end))
figure(1), plot(tvals,yvals,'o',ttvals,2*exp(ttvals.*ttvals))
xlabel('t')
ylabel('f(t)')
legend('classical runge-kutta h = 0.2','exact')

[tvals,yvals] = rkgen(f,[0 2],2,0.2,2);
fprintf('Butcher-Runge-Kutta h = 0.2, t(2) = %6.4f \n', yvals(end))
figure(2), plot(tvals,yvals,'o',ttvals,2*exp(ttvals.*ttvals))
xlabel('t')
ylabel('f(t)')
legend('butcher-runge-kutta h = 0.2','exact')

[tvals,yval] = rkgen(f,[0 2],2,0.2,3);
fprintf('Merson-Runge-Kutta h = 0.2, t(2) = %6.4f \n', yvals(end))
figure(3), plot(tvals,yvals,'o',ttvals,2*exp(ttvals.*ttvals))
xlabel('t')
ylabel('f(t)')
legend('merson-runge-kutta h = 0.2','exact')
fprintf('Exact, t(2) = %6.4f \n', 2*exp(2^2))