% e4prob904
% Solution of Problem 9.4
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

res = mincg('e4prob904f','e4prob904df','ftau904',[0.5 0.5]',0.005);

for k = 1:2
    fprintf('x(%1.0f) = %10.8f \n',k,res(k))
end
options = optimset('TolFun',10*eps);
x_min = fminsearch('e4prob904f',[0.5 0.5]',options)

[X,Y] = meshgrid(-3:0.1:3,-3:0.1:3);
Z = 100*(X.^2-Y).^2+(1-X).^2;
figure(1)
contour(X,Y,Z,50)
hold on
plot(res(1),res(2),'+k')
hold off
xlabel('x'), ylabel('y')
title('Rosenbrock function. (Minimum indicated by +)')
grid
Z(1,1)

figure(2)
surf(X,-Y,Z)
xlabel('x'), ylabel('y')
title('Rosenbrock function')
