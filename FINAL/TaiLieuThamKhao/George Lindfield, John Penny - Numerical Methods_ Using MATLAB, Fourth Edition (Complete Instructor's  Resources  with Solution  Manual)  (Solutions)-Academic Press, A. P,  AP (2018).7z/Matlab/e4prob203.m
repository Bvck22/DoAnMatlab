% e4prob203
% Solution of Problem 2.3
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

a = 0.2;
b = 0.1;
n = 5;
if a+2*b<1
    disp('a+2b<1 so condition met')
else
    disp('a+2b>=1 so condition NOT met')
end
A = diag(a*ones(1,n))+diag(b*ones(1,n-1),1) + diag(b*ones(n-1,1),-1);
S = inv(eye(n)-A);

for m = 10:10:40
    S1 = eye(n);
    for k = 1:m
        S1 = S1+A^k;
    end
    error = abs(max(max(S-S1)));
    fprintf('%3.0f terms in series, max error = %8.4e \n',m, error) 
end

a = 0.3;
b = 0.5;
n = 5;
if a+2*b<1
    disp('a+2b<1 so condition met')
else
    disp('a+2b>=1 so condition NOT met')
end
A = diag(a*ones(1,n))+diag(b*ones(1,n-1),1) + diag(b*ones(n-1,1),-1);
S = inv(eye(n)-A);

for m = 10:10:40
    S1 = eye(n);
    for k = 1:m
        S1 = S1+A^k;
    end
    error = abs(max(max(S-S1)));
    fprintf('%3.0f terms in series, max error = %8.4e \n',m, error) 
end