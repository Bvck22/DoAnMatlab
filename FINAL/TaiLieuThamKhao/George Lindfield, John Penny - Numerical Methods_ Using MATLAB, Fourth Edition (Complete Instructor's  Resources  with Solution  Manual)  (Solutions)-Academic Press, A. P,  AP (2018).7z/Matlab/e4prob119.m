% e4prob119
% Solution of Problem 1.19
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

close all
clear all

x = 0:0.1:2;
f = @(x) x.^2-cos(x)-x;

plot(x,f(x))
xlabel('x-axis')
ylabel('y-axis')
grid
disp('Select y = 0 on graph')
xv = ginput(1);
disp(['Approx root from graph = ' num2str(xv(1))])
xsol = fzero(f,xv(1));
disp(['Root from fzero function = ' num2str(xsol)])