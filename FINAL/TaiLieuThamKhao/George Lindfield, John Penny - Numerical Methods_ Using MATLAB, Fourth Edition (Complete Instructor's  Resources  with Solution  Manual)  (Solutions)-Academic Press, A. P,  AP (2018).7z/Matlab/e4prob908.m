% e4prob908
% Solution of Problem 9.8
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
f = @(x) (x(1).^2+x(2).^2);

[fval0,xval0] = diffevo(f, 2, [-2 -2]', [2 2]', 0.85, 0.5, 20, 100);
for k = 2:20
    [fval,xval] = diffevo(f, 2, [-2 -2]', [2 2]', 0.85, 0.5, 20, 100);
    if fval<fval0
        fval0 = fval;
        xval0 = xval;
    end
end

fprintf('Best estimate of min(f) = %6.4f at x = [%6.4f %6.4f]\n',fval0,[xval0])
[x,y] = meshgrid(-2:0.05:2,-2:0.05:2);
z = x.^2+y.^2;
figure(1), surf(x,y,z)
xlabel('x'), ylabel('y')
zlabel('f(x,y)')
title('f = x^2+y^2')