% e4prob916
% Solution of Problem 9.16
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
f = @(x) 100*(x(2)-x(1).^2).^2+(1-x(1)).^2;

[f0,x0] = asaq(f,[-1.2 1]',800,.9,-10,10,100);
for n = 2:10
    [fa,xa] = asaq(f,[-1.2 1]',800,.9,-10,10,100);
    if fa<f0
        f0 = fa;
        x0 = xa;
    end
end

fprintf('Best estimate of min(f) = %6.4f at x = [%6.4f %6.4f]\n',f0,x0(1),x0(2))

[X Y] = meshgrid(-2:0.1:2,-2:0.1:2);
Z = 100*(Y-X.^2).^2+(1-X).^2;
surf(X,Y,Z)
view([-131 18])
xlabel('x')
ylabel('y')
zlabel('f(x,y)')
title('z = 100*(y-x^2)^2+(1-x)^2')
