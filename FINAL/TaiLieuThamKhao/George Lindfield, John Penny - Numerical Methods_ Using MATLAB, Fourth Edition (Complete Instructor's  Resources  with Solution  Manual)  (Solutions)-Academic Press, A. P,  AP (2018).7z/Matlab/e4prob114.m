% e4prob114
% Solution of Problem 1.14
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
n = 6;
disp('Vector of data')
x = 1:n
for j = 1:n
    p(j) = 1;
    for i = 1:n
        if i~=j
            p(j) = p(j)*x(i);
        end
    end
end
disp('Vector of products p_k')
p

% Alternative apporach
p_alt = prod(x)./x
