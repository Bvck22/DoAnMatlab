% e4prob401
% Solution of Problem 4.1
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

for h = [0.1 0.01]
    res = diffgen(@(x) x.^2.*cos(x),1,1,h);
    fprintf('h = %4.2f, first  derivative = %9.6f\n',h,res)
    res = diffgen(@(x) x.^2.*cos(x),2,1,h);
    fprintf('h = %4.2f, second derivative = %9.6f\n',h,res)
end
fprintf('\nExact  first derivative = %9.6f\n',2*cos(1)-sin(1))
fprintf('Exact second derivative = %9.6f\n',cos(1)-4*sin(1))