% e4prob123
% Solution of Problem 1.23
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

% Demonstration of zetainf
acc = 1e-6

s_exact = [pi^2/6 1.202056903 pi^4/90 1.036927755 pi^6/945 ...
    1.008349277 pi^8/9450 1.002008393  pi^10/93555]; 

for s = 2:10
    fprintf('s = %2.0f, zeta(s) = %11.8f, s(exact) = %11.8f\n',s,zetainf(s,acc),s_exact(s-1))
end
      
