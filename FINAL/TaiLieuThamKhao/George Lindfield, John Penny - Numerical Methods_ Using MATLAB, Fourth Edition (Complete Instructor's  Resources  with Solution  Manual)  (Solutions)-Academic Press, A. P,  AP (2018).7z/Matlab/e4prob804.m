% e4prob804
% Solution of Problem 8.04
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

n = 256; 
T = 1; 
dt = T/n;
df = 1/T;
fprintf('Frequency increment = %4.2f Hz \n',df)
fmax = (n/2)*df;
fprintf('Nyquist frequency = %4.2f Hz \n',fmax)
t = 0:dt:(n-1)*dt;
f = 0:df:(n/2-1)*df;

YP = zeros(3,n/2);
cc = 0;
for f0 = [25 30.37 35.49]
    cc = cc+1;
    y = sin(2*pi*f0*t);
    Y = (2/n)*fft(y);
    YP(cc,:) = abs(Y(1:n/2));
end

figure(1)
plot(f,YP(1,:),f,YP(2,:),f,YP(3,:))
grid
xlabel('frequency Hz'); 
ylabel('abs(DFT)')
legend('f = 25 Hz','f = 30.37 Hz','f = 35.49 Hz')
axis([0 80 0 1])

w = 0.5*(1-cos(2*pi*t/T));
cc = 0;
for f0 = [25 30.37 35.49]
    cc = cc+1;
    y = sin(2*pi*f0*t);
    Y = (2/n)*fft(y.*w);
    YP(cc,:) = abs(Y(1:n/2));
end

figure(2)
plot(f,YP(1,:),f,YP(2,:),f,YP(3,:))
grid
xlabel('frequency Hz'); 
ylabel('weighted abs(DFT)')
legend('f = 25 Hz','f = 30.37 Hz','f = 35.49 Hz')
axis([0 80 0 1])
