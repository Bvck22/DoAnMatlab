% e4prob705
% Solution of Problem 7.5
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x = [-2 0 2 3 4 5];
y = [4 0 -4 -30 -40 -50];
co = polyfit( x,y,5);
fprintf('Constant : %8.4f\n',co(6))
fprintf('Coeff   x: %8.4f\n',co(5))
fprintf('Coeff x^2: %8.4f\n',co(4))
fprintf('Coeff x^3: %8.4f\n',co(3))
fprintf('Coeff x^4: %8.4f\n',co(2))
fprintf('Coeff x^5: %8.4f\n',co(1))
xx = -2:0.1:5;
y1 = polyval(co,xx);
ys = spline(x,y,xx);

plot(x,y,'ko')
hold on
plot(xx,y1,'r',xx,ys,'b')
hold off
xlabel('x-axis')
ylabel('y-axis')
legend('data value','fifth degree poly', 'spline fit')
title('spline and fifth degree polynomial and spline fit')
