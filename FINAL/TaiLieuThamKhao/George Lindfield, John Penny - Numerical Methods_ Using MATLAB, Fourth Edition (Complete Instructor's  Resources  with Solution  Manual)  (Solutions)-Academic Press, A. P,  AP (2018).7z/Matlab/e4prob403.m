% e4prob403
% Solution of Problem 4.3
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

f = @(x) x.^2.*cos(x);

x = 1;
for h = [0.1 0.01]
    df = (f(x+h)-f(x-h))/(2*h);
    d2f = (f(x+h)-2*f(x)+f(x-h))/(h*h);
    fprintf('h = %4.2f, first  derivative = %9.6f\n',h,df)
    fprintf('h = %4.2f, second derivative = %9.6f\n',h,d2f)
end
fprintf('\n')

clear all

f = @(x) cos(x.^6);

h = 0.001;
for x = 1:3
    df = (f(x+h)-f(x-h))/(2*h);
    fprintf('x =%2.0f, first derivative = %11.6f\n',x,df)
end