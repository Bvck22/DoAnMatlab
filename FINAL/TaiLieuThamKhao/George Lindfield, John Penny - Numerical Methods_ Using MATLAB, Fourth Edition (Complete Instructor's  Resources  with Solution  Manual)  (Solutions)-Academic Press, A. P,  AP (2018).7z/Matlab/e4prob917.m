% e4prob917
% Solution of Problem 9.17
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

% Part 1
v = -10:0.2:10;
i = 0;
for x0 = v
    i = i+1;
    j = 0;
    for y0 = v
        j = j+1;
        x = [x0 y0];      
        z(i,j) = ras(x);
    end
end
[x y] = meshgrid(v, v);
figure(1), surf(x,y,z)
title('Rastrigin function')
xlabel('x'), ylabel('y'), zlabel('f(x,y)')

for n = 4:2:12
    x0_min = -5.12*ones(n,1); x0_max = 5.12*ones(n,1);
    [fval0,xval0] = diffevo(@ras, n, x0_min, x0_max, 0.85, 0.5, 20, 100*n);
    for k = 2:10
        [fval,xval] = diffevo(@ras, n, x0_min, x0_max, 0.85, 0.5, 20, 100*n);
        if fval<fval0
            fval0 = fval;
            xval0 = xval;
        end
    end
    fprintf('Rastrigin function. n = %3.0f. Best est of min(f) = %8.6e \n',n,fval0)
    disp(xval0')
end
fprintf('\n')

% Part 2

[x,y] = meshgrid(-20:0.4:20,-20:0.4:20);
z = -cos(x).*cos(y).*exp(-((x-pi).^2+(y-pi).^2));
figure(2), surf(x,y,z)
xlabel('x'), ylabel('y'), zlabel('f(x,y)')
title('Easom function.')
axis([-20 20 -20 20 -1 1])

x1 = -20:0.4:20;
figure(3), plot(x1,-cos(x1).*cos(pi).*exp(-(x1-pi).^2));
xlabel('x value'), ylabel('Function'), title('Easom function with y = pi')

%%%% cos(x(1)).*exp(-((x(1)-pi).^2)).*cos(x(2)).*exp(-((x(2)-pi).^2));
f = @(x) -cos(x(1)).*cos(x(2)).*exp(-((x(1)-pi).^2+(x(2)-pi).^2));

df = @(x) [exp(-(x(1)-pi)^2-(x(2)-pi)^2)*cos(x(2))*sin(x(1))+exp(-(x(1)-pi)^2 ...
    -(x(2)-pi)^2)*cos(x(1))*cos(x(2))*(2*x(1)-2*pi);
     exp(-(x(1)-pi)^2-(x(2)-pi)^2)*cos(x(1))*sin(x(2))+exp(-(x(1)-pi)^2 ...
    -(x(2)-pi)^2)*cos(x(1))*cos(x(2))*(2*x(2)-2*pi)];

txt = 'Easom function. Search range %4.0f to %3.0f Best estimate of min(f) = %10.8f at x = [%10.8f %10.8f]\n';

for scale = [5 10 25 50 60 80 100 500 999]
    r1 = -scale*[1 1]'; r2 = scale*[1 1]';
      [fval0,xval0] = diffevo(f, 2, r1, r2, 0.85, 0.5, 30, 500);
    for p = 1:20
        [fval,xval] = diffevo(f, 2, r1, r2, 0.85, 0.5, 30, 500);
        if fval<fval0
            fval0 = fval; xval0 = xval;
        end
    end
    fprintf(txt,r1(1),r2(1),fval0,[xval0])
end


% ----------------------------------------------------
function f = ras(x)
n = length(x);
f = 10*n;
for i = 1:n
    f = f+(x(i).^2-10*cos(2*pi*x(i)));
end
end