% e4prob715
% Solution of Problem 7.15
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

n = 1:4;
fn = [1 4 10 20];
c0 = polyfit(n,fn,3);
fprintf('Using the given data:-\n')
fprintf('Constant     = %1.0f \n', c0(4))
fprintf('Coeff of x   = 1/%1.0f \n', 1/c0(3))
fprintf('coeff of x^2 = 1/%1.0f \n', 1/c0(2))
fprintf('coeff of x^3 = 1/%1.0f \n', 1/c0(1))
fn5 = polyval(c0,5);

fprintf('\nWhen n = 5, fn = %4.1f \n\n', fn5)

