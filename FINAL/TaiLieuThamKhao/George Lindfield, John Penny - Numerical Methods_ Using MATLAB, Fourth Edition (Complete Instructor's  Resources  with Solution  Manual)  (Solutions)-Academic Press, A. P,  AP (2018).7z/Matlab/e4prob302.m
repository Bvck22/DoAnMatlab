% e4prob302
% Solution of Problem 3.2
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

f = @(x) x.^1.4-sqrt(x)+1./x-100;
df = @(x) 1.4*x.^0.4-0.5./sqrt(x)-1./x.^2;
[root1, iterations] = fnewton(f,df,50,1e-4);
fprintf('Using Newton method, x = %6.4f after %2.0f iterations \n',root1,iterations)

figure(1)
%xp = 1:0.2:35;
xp = -2:0.005:2;
plot(xp,f(xp))
xlabel('x')
ylabel('f(x)')
grid