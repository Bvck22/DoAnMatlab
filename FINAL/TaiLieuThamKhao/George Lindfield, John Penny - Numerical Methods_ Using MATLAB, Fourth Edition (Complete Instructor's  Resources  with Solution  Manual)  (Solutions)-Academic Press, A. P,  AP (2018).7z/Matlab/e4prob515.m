% e4prob515
% Solution of Problem 5.15
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
k = 0.5;
f = @(t,y) [y(1)-0.001*y(1).^2-0.001*k*y(1).*y(2)-0.01*y(1).*y(3);
    y(2)-0.001*y(2).^2-0.0015*k*y(1).*y(2)-0.001*y(2).*y(3);
    -y(3)+0.005*y(1).*y(3)+0.0005*y(2).*y(3)];

[t,y] = ode45(f,[0 50],[1000 300  400]');
figure(1), plot(t,y)
grid
xlabel('Time')
ylabel('Species')
axis([0 50 0 1200])
legend('species_1', 'species_2', 'species_3')