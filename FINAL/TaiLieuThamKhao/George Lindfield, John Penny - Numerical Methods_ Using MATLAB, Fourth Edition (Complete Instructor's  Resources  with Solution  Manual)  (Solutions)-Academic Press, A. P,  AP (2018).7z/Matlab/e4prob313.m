% e4prob313
% Solution of Problem 3.13
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
ee = [0.1  0.01  0.001 0];
for k = 1:4
    e = ee(k);
    sol_rts = roots([1  -(13+e) 57+8*e  -(95+17*e)  50+10*e]);
    sol_b = bairstow([ -(13+e) 57+8*e  -(95+17*e)  50+10*e],4,1e-5);
    [sol_br, idx] = sort(sol_b(:,1),'descend');
    fprintf('\nepsilon     by roots     by bairstow \n')
    % [e*ones(4,1) sol_rts sol_br];
    for m = 1:4
        fprintf('%6.3f %12.4f %12.4f \n', e, sol_rts(m), sol_br(m,1))
    end
end