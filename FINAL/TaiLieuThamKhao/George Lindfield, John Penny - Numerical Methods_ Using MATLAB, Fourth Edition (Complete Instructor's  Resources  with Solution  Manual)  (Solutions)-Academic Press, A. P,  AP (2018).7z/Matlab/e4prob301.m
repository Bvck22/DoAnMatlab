% e4prob301
% Solution of Problem 3.1
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

a = 1; 
b = 2; 
c = 3;
f = @(x) x.^3-c*x.^2+b^2*x+a^3;
x_sol1 = fzero(f,1)
fprintf('Using fzero, x = %6.4f \n',x_sol1)
fprintf('\n')
x_sol2 = roots([1 -c b^2 a^3]);
for k = 1:3
    disp(['using roots, x = ' num2str(x_sol2(k))])
end

p = -0.5*(c-a^3/b^2);
q = b;
s = b^2-c*a^3/b^2;
Rad = sqrt(p^2+q^2-s);

figure(1)
theta = 0:pi/100:2.1*pi;
x = -2:0.01:4;
plot(x,a^3./(b*x))   % Plot parabola
hold on
xx = -p+Rad*sin(theta);
yy = -q+Rad*cos(theta);
plot(xx,yy,'r')
hold off
axis([-2 4 -4 2])
xlabel('x value')
ylabel('y value')
grid

disp(' ')
disp('Select the point of contact of the circle and parabola')
x_sol3 = ginput(1);
fprintf('From graph, x = %6.4f, y = %6.4f \n',x_sol3(1),x_sol3(2))



