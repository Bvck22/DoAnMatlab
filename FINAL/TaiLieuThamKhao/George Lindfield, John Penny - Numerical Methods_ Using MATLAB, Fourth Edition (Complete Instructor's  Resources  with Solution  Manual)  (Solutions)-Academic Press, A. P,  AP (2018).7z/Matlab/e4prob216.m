% e4prob216
% Solution of Problem 2.16
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [122  41  40  26  25;
      40 170  25  14  24;
      27  26 172   7   3;
      32  22   9 106   6;
      31  28  -2  -1 165];
  
disp('Eigenvalues of A')
p = eig(A);
lambda1 = sort(p);
disp(lambda1)

disp('Roots of polynomial of A')
v = poly(A);
lambda2 = sort(roots(v));
disp(lambda2)

fprintf('norm(eigenvalues-poly_rts) = %12.6e\n',norm(lambda1-lambda2))
