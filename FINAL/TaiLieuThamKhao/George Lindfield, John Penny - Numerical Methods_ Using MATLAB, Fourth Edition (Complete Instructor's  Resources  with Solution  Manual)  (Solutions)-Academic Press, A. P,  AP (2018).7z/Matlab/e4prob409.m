% e4prob409
% Solution of Problem 4.9
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

func = @(x) log(x)./(1+x.^2);
int = fgauss(func,0,1,16);
fprintf('Estimate = %9.6f\n',int)