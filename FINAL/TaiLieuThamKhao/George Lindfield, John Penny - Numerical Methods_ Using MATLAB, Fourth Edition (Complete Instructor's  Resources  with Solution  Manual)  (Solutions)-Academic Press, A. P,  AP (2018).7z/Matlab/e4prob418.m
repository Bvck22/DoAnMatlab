% e4prob418
% Solution of Problem 4.18
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f1 = @(x,y) x.^4.*y.^4;
q1 = simp2v(f1,-1,1,-pi,pi,64);
fprintf('Part (a): estimate = %10.5f\n',q1)

f2 = @(x,y) x.^10.*y.^10;
q2 = simp2v(f2,-1,1,-pi,pi,64);
fprintf('Part (b): estimate = %10.5f\n',q2)

[xx,yy] = meshgrid(-pi:pi/25:pi,-1:0.04:1);
z1 = f1(xx,yy);
figure(1), surf(xx,yy,z1)
xlabel('x')
ylabel('y')
zlabel('f(x,y)')
axis([-pi pi -1 1 0 100])

z2 = f2(xx,yy);
figure(2), surf(xx,yy,z2)
xlabel('x')
ylabel('y')
zlabel('f(x,y)')
axis([-pi pi -1 1 0 1e5])