% e4prob505
% Solution of Problem 5.5
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
k = 0.05;
f1 = @(t,y) [-k*y  k^2*y];

[tvals, yvals] = fhermite(f1,[0 10]',50,1);
fprintf('h = 1. At t = 10, y = %8.4f \n',yvals(end))
figure(1), plot(tvals,yvals,'ko-')
title('Soln of Prob 5.1')
xlabel('t')
ylabel('y = f(t)')

f2 = @(t,y) [2*t.*y  (4*t.^2+2).*y];

i = 1;
for h = [0.2 0.02]
    [tv,yv] = fhermite(f2,[0 2]',2,h);
    i = i+1;
    figure(i), plot(tv,yv,'ko-')
    xlabel('t')
    ylabel('y = f(t)')
    axis([0 2 0 140])
    title(['Soln of Prob 5.2. h = ' num2str(h)])
    fprintf('h = %5.3f. At t = 2, y = %8.4f \n',h,yv(end))
end
