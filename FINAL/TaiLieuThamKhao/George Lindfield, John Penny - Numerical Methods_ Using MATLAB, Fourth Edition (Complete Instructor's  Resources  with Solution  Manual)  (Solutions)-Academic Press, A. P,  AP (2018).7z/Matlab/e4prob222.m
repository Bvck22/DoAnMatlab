% e4prob222
% Solution of Problem 2.22
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfiled and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

x = [ ];
a = -4*eye(10);
for i = 1:10
    for j = 1:10
        if abs(i-j)==1
            a(i,j) = 2;
        elseif abs(i-j)>=2
            a(i,j) = 0;
        end
    end
end
b = 2:11;
iter = 0;  
x0 = zeros(1,10); x0 = 1:10;
d = 1;
while d>0.000005
    for i = 1:10
        s(i) = b(i);
        for j=1:10
            s(i) = s(i)-a(i,j)*x0(j);
        end
        x(i) = (s(i)+a(i,i)*x0(i))/a(i,i);
    end
    d = norm(x0-x);
    iter = iter+1;
    x0 = x;
end
solution = x.';
disp('Jacobi iteration: solution is ')
disp(solution)
disp(['number of iterations = ' num2str(iter)])
disp('  ')

iter = 0;  
x0 = zeros(1,10); x0 = 1:10;
d = 1;
while d>0.000005
    x = x0;
    for i = 1:10
        s(i) = b(i);
        for j = 1:10
            s(i) = s(i)-a(i,j)*x(j);
        end
        x(i)  =(s(i)+a(i,i)*x(i))/a(i,i);
    end
    d = norm(x0-x);
    iter = iter+1;
    x0 = x;
end
solution = x.';
disp('Gauss-Seidel Iteration: solution is ')
disp(solution)
disp(['number of iterations = ' num2str(iter)])
