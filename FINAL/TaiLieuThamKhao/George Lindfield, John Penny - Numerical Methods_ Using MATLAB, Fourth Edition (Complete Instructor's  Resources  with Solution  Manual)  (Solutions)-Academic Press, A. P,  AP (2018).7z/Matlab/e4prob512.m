% e4prob512
% Solution of Problem 5.12
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
k = 10;
v1 = 1;
v2 = 1;
c = k*(1/v1+1/v2);
f = @(t,y) [-c*y(1); y(1)];

[t,y] = ode45(f,[0 2],[10 0]');
plot(t,y(:,2),'ko',t,0.5*(1-exp(-c*t)),'r')
xlabel('Time')
ylabel('x = f(t)')
grid

fprintf('At t = 2,     x = %4.2f \n',y(end,2))
fprintf('At t = 2, dx/dt = %4.2f \n',y(end,1))
