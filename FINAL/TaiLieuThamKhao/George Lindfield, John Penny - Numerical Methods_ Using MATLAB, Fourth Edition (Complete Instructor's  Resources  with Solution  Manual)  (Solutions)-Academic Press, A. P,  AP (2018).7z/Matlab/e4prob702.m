% e4prob702
% Solution of Problem 7.2
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

x = 20:2:30;
f = x.^1.4-sqrt(x)+1./x-100;
v = aitken(f,x,0);
fprintf('x0 = %8.5f \n', v)

error = v.^1.4-sqrt(v)+1./v-100;
fprintf('error = %11.4e \n', error)

plot(x,f,'ko')
xlabel('x')
ylabel('f(x)')
title('f = x^{1.4}-sqrt(x)+1/x-100')
grid
