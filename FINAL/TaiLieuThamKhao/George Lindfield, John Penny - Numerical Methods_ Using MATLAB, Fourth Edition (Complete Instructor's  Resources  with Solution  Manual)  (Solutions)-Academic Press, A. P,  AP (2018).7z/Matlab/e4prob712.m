% e4prob712
% Solution of Problem 7.12
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

t = [0 1 2 3];
cost = [30.2 25.8 22.2 20.2];
cv3 = polyfit(t,cost,3);
cv2 = polyfit(t,cost,2);
cost_cubic = polyval(cv3,6);
cost_quadratic = polyval(cv2,6);
fprintf('Yr 6 cost:  original data (quadratic fit) = $ %6.4f \n',cost_quadratic)
fprintf('Yr 6 cost:  original data (cubic fit)     = $ %6.4f \n',cost_cubic)

tt = 0:0.1:6;
figure(1)
plot(t,cost,'o',tt, polyval(cv3,tt),'r',tt,polyval(cv2,tt),'k')
xlabel('Time yrs')
ylabel('Costs')
legend('data','cubic fit','quadratic fit')
title('Polynomial fit to original data')
grid


cost = [30.2 25.8 22.5 20.5];
cv3 = polyfit(t,cost,3);
cv2 = polyfit(t,cost,2);
cost_cubic = polyval(cv3,6);
cost_quadratic = polyval(cv2,6);
fprintf('Yr 6 cost: corrected data (quadratic fit) = $ %6.4f \n',cost_quadratic)
fprintf('Yr 6 cost: corrected data (cubic fit)     = $ %6.4f \n',cost_cubic)

figure(2)
plot(t,cost,'o',tt, polyval(cv3,tt),'r',tt,polyval(cv2,tt),'k')
xlabel('Time yrs')
ylabel('Costs')
legend('data','cubic fit','quadratic fit')
title('Polynomial fit to  corrected data')
grid




