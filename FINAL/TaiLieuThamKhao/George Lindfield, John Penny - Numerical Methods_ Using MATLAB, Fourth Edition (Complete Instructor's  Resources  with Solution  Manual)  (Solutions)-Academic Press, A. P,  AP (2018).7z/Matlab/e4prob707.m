% e4prob707
% Solution of Problem 7.7
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x = [0 0.005 0.0075 0.0125 0.025 0.05 0.1 0.2 0.3 0.4 0.5 ...
                   0.6 0.7 0.8 0.9 1];
yu = [0 0.0102 0.0134 0.0170 0.0250 0.0376 0.0563 ...
         0.0812 0.0962 0.1035 0.1033 0.0950 0.0802 0.0597 0.0340 0];
yl = [0 -0.0052 -0.0064 -0.0063 -0.0064 -0.0060 -0.0045 ...
        -0.0016 0.0010 0.0036 0.0070 0.0121 0.0170 0.0199 0.0178 0];
xx = 0:0.001:1;
p = spline(x,yu,xx);
p1 = spline(x,yl,xx);
plot(xx,p,'k',xx,p1,'k')
title('airfoil')
axis([0 1 -0.1 0.5])