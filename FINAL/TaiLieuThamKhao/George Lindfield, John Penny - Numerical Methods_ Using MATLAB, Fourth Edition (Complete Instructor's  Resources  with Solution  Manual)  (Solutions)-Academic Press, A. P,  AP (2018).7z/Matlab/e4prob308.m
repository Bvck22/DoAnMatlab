% e4prob308
% Solution of Problem 3.8
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfiled and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x0 = -1.5;
options = optimset('TolFun',1e-5);
root1 = fzero(@(x) x.^11,x0,options);
fprintf('Using fzero, initial values = %4.1f, x = %12.4e\n',x0, root1)

x0 = 1;
root2 = fzero(@(x) x.^11,x0,options);
fprintf('Using fzero, initial values = %4.1f, x = %12.4e\n',x0, root2)

figure(1)
xp = -1:0.01:1;
plot(xp, xp.^11)
xlabel('x')
ylabel('f(x)')
grid
axis([-1 1 -0.1 0.1])