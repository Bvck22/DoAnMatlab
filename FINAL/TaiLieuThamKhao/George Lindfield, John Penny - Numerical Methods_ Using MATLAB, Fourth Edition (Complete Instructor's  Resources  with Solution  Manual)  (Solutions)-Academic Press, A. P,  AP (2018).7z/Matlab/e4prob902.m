% e4prob902
% Solution of Problem 9.2
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [1 1 1 0 0;1 2 0 1 0;1 4 0 0 1];
b = [5; 7; 10];
c = [4 5 0 0 0]; 
c = -c; % Change sign for max value
[ysol,ind,object] = barnes(A,b,c,0.0001);

object = -object; % Change sign for max value

y0 = zeros(length(c),1);
for k = 1:length(ysol)
    y0(ind(k)) = ysol(k);
end

for k = 1:length(c)
    fprintf('y(%1.0f)   = %8.4f \n',k,y0(k))
end
fprintf('\nmax(z) = %8.4f \n\n', object)



