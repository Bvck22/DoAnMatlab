% e4prob412
% Solution of Problem 4.12
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

fc = @(x) cos(pi*x.^2/2);
C1 = simp1(fc,0,1,32);
fprintf('C(1): estimate = %10.7f\n',C1)

fs = @(x) sin(pi*x.^2/2);
S1 = simp1(fs,0,1,32);
fprintf('S(1): estimate = %10.7f\n',S1)

xp = 0:0.001:1;
figure(1), plot(xp, fc(xp))
xlabel('x')
ylabel('Cosine function')
title('Part (a)')
figure(2), plot(xp, fs(xp))
xlabel('x')
ylabel('Sin function')
title('Part (b)')