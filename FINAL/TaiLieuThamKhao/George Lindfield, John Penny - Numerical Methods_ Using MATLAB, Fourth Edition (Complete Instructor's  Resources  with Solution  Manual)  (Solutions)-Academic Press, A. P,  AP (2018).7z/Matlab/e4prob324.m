% e4prob324
% Solution of Problem 3.24
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018
clear all
close all

a = 1; b = 2; c = 3; d = 0;  % Note d = 0

c0 = a+b+c;
c1 = (3-2*a*c-2*b*c-2*a*b);
c2 = (3*a*b*c-2*b-2*c-2*a);
c3 = a*b+a*c+b*c;  %-a*b-a*c-b*c+a*b*c*d;

x = roots([c0 c1 c2 c3])

sol = (1+a*x)./(x-a)+(1+b*x)./(x-b)+(1+c*x)./(x-c)

x = -1:0.02:4;
sol = (1+a*x)./(x-a)+(1+b*x)./(x-b)+(1+c*x)./(x-c);

figure(1)
plot(x,sol)
axis([-1 4 -600 600])
xlabel('x'), ylabel('f(x)')
grid

figure(2)
plot(x,sol)
axis([-1 3 -10 10])
xlabel('x'), ylabel('f(x)')
grid


syms a b c x
p = (1+a*x)/(x-a)+(1+b*x)/(x-b)+(1+c*x)/(x-c);
p = collect(p,x)
p = simplify(p)
