% e4prob428
% Solution of Problem 4.28
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

for alpha = 2:3
    beta = alpha+1;
    f = @(x) x.^(alpha-1)./(1+x.^beta);
    val = galag(f,8);
    fprintf('alpha = %2.1f, beta = %2.1f \n',alpha,beta)
    fprintf('Estimate of integral    = %6.5f\n',val)
    fprintf('Exact value of integral = %6.5f\n',pi/(beta*sin(alpha*pi/beta)))
    fprintf('\n')
end