% e4prob205
% Solution of Problem 2.5
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

a = 0.4;
b = 0.25;
fprintf('     n    norm_full     norm_sparse \n')
for n = 10:10:30
    A = diag(a*ones(1,n))+diag(b*ones(1,n-1),1) + diag(b*ones(n-1,1),-1);
    B = sparse(A);
    lama = eig(A);
    lama = sort(lama);
    lamb = eig(B);
    lamb = sort(lamb);
    for k = 1:n
        lame(k) = a+2*b*cos(k*pi/(n+1));
    end
    lame = sort(lame);
    norm_full = norm(lama-lame.');
    norm_sparse = norm(lamb-lame.');
    fprintf('%6.0f %14.6e %14.6e \n',n,norm_full,norm_sparse)
end