% e4prob202
% Solution of Problem 2.2
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

for n = 3:6
    A = hilb(n);
    c = cond(A.'*A);
    fprintf('For n = %2.0f, cond number = %12.4e \n',n,c)
end
