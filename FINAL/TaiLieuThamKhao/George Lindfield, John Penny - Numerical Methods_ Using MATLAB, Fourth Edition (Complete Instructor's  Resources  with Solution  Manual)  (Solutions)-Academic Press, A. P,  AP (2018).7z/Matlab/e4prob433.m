% e4prob433
% Solution of Problem 4.33
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

a = 0.723; b = 1.524;

f = @(theta) sqrt(a^2+b^2-2*a*b*cos(theta));

int = integral(f,0,2*pi)
