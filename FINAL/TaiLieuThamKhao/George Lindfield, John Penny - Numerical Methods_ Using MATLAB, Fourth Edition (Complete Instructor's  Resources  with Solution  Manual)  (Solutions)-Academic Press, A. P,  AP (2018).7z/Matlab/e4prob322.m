% e4prob322
% Solution of Problem 3.22
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

close all
clear all

func = @(x) ((sinh(x)+sin(x))./(2*x)).^2-x.^4.*((sinh(x)-sin(x))./(2*x.^3)).^2;

% Some randomly chosen initial values
for x0 = [10 29.1 31.2 33.3 35.2 36.3 40.1 41.2 42.3]
    y = fzero(func,x0);
    fprintf('x0 = %8.4f. Root x = %8.4f, x/pi = %8.4f\n',x0,y,y/pi)
end

i = 0; v = pi*[0.1:0.1:10];
for x0 = v
    i = i+1;
    y0(i) = func(x0*pi);
end