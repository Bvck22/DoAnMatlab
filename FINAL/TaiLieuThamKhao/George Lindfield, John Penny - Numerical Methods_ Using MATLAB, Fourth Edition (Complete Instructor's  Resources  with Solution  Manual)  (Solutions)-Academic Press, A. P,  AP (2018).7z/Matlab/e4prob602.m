% e4prob602
% Solution of Problem 6.2
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
% Shooting method
% Stage 1 - solve ode for several initial values s

s = -3:0.5:2; 
ncase = length(s);
b = zeros(1,ncase);

f = @(y,x) [-x(1)+6*x(2); x(1)];
option = odeset('RelTol',0.0005);

for i = 1:ncase
    [x,y] = ode45(f,[0 1],[s(i) 1]',option);
    b(1,i)= y(end,2);
end

% Stage 2 - interpolation
s0 = aitken(b,s,2);
fprintf('Initial slope = %6.4f\n',s0)

% Stag3 3 - solve ode using correct initial gradient
[x1,y] = ode45(f,[0 1],[s0 1]',option);

disp('Shooting method')
disp('       x        y')
[x1 y(:,2)]

% FD method
x = 0:0.1:1; 
c = ones(1,length(x));
d = ones(1,length(x));
e = -6*ones(1,length(x));
f1 = zeros(1,length(x));
twopoint_y = twopoint(x,c,d,e,f1,1,1,1,2);
disp('Finite difference method')
disp('       x        y')
[x.' twopoint_y]

% Exact
exact_y = (0.2657*exp(2*x)+0.7343*exp(-3*x)).';
disp('Exact solution')
disp('       x        y')
[x.' exact_y]

figure(1)
plot(x1,y(:,2),'r',x.',twopoint_y,'ko',x.',exact_y,'b')
axis([0 1 0 2.5])
xlabel('x'), ylabel('y = f(x)')
title('Solution of d^2y/dx^2+dy/dx-6y = 0')
legend('shooting','FD','exact')
grid
