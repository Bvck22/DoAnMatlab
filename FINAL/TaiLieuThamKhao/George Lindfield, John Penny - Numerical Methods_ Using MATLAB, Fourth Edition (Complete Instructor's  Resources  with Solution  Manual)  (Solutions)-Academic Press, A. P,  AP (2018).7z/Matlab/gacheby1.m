function s = gacheby1(func,n)
% Integration of f(x)/sqrt(1-x^2) between -1 and 1
% func is f(x), n is the number of points.
%
% Required for Problem 4.11
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

k = 1:n;
x = cos((2*k-1)*pi/(2*n));
f = feval(func,x);
s = (pi/n)*sum(f);
end

