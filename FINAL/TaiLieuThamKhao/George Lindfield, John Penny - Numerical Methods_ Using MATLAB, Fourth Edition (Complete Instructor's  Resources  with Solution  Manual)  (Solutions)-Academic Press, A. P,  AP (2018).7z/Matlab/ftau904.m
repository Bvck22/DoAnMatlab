function ftauv = ftau904(tau)

% This MATLAB function is to accompany 'Numerical Methods using MATLAB' 
% by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.
% Required for Problem 9.4
global p1 d1
q1 = p1+tau*d1;
ftauv = feval('e4prob904f',q1);
end

