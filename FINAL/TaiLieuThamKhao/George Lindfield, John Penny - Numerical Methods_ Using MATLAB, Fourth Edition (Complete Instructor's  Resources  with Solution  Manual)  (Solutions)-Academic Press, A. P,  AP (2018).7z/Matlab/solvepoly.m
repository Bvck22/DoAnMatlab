function  sol = solvepoly(x0,acc)
% Poly solver
% THIS FUNCTION CONTAINS ERRORS (INTENTIONALLY)!

% Solution of Problem 1.29
%
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

d = 1+acc;
while abs(d)>acc
    x1 = (2*x0^2-1))/xo^2;
    d = x1-x0;
    x0 = x1/x2
end
sol = x0;