% e4prob423
% Solution of Problem 4.23
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

% Probability of engine failure
clear all
close all

p = [ ];
a = 3.5; 
b = 8200;
i = 1;
for T = 200:100:4000
    P(i) = quad(@(x) a*b^a./((x+b).^(a+1)),0.001,T);
    i = i+1;
end

figure(1)
plot(200:100:4000,P)
xlabel('Time in hours')
ylabel('Probability of failure')
title('Plot of probaility of failure against time')
grid