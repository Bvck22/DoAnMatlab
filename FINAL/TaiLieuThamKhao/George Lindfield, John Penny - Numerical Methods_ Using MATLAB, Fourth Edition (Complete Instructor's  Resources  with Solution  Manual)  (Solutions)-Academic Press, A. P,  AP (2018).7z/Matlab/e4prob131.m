% e4prob131
% Solution of Problem 1.31
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

for n = 2:2:16
    fprintf('n = %2.0f, factorial(n) = %14.0f\n',n, e4prob131f(n))
end