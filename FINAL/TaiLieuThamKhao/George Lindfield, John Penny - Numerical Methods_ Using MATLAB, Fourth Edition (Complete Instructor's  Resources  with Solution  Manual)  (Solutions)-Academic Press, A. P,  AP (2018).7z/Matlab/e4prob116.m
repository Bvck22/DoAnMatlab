% e4prob116
% Solution of Problem 1.16
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
d = input('Enter single value for elements on main diagonal, d ');
c = input('Enter single value for elements on upper/lower diags, c ');
n = input('Enter size of square matrix, n ');
M = [ ];

% Set up matrix
M = c*eye(n);
for i = 1:n-1
    for j = 2:n
        if i==j-1
            M(i,j) = d;
        end
    end
end
for i = 2:n
    for j = 1:n-1
        if i-1==j
            M(i,j) = d;
        end
    end
end

disp('----------------')
disp('Generated matrix')
M

M1 = zeros(n,n);
disp('Generated matrix using diag function')
M1 = diag(c*ones(n,1))+diag(d*ones(n-1,1),1)+diag(d*ones(n-1,1),-1)
      