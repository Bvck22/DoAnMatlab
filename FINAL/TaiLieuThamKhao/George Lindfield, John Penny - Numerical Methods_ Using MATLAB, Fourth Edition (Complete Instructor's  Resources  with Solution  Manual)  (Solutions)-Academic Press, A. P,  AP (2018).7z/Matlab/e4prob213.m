% e4prob213
% Solution of Problem 2.12
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [1 2 2;5 6 -2;1 -1 0];
B = [2 0 1;4 -5 1;1  0 0];
C = [A B;B A];

eigC = eig(C);
disp('Eigenvalues of C')
disp(eigC)

eig_sum = eig(A+B);
eig_diff = eig(A-B);

disp('Eigenvalues of A+B')
disp(eig_sum)

disp('Eigenvalues of A-B')
disp(eig_diff)

