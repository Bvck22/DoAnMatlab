% e4prob432
% Solution of Problem 4.32
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

c = -1.035;  gamma = -2.290;

f1 = @(y) 1./sqrt((y.^2+gamma).^2./c^2-1);

f2 = @(y) ((y.^2+gamma)./c)./sqrt((y.^2+gamma).^2./c^2-1);
int1 = integral(f1,0,sqrt(c-gamma))

int2 = integral(f2,0,sqrt(c-gamma))