function fv = f905f(x)

% This MATLAB function is to accompany 'Numerical Methods using MATLAB e4' 
% by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

fv = 0.5*(x(1).^4-16*x(1).^2+5*x(1)) +...
0.5*(x(2).^4-16*x(2).^2+5*x(2))+(x(3)-1).^2 +(x(4)-1).^2 +(x(5)-1).^2;