% e4prob103
% Solution of Problem 1.3
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
% A is not specified in the question. Here is a simple matrix!
A = [1 2 3 4;5 6 7 8;9 0 -9 -8;-7 -6 -5 -4]

sum_row1 = sum(A(1,:).')
sum_col2 = sum(A(:,2))

