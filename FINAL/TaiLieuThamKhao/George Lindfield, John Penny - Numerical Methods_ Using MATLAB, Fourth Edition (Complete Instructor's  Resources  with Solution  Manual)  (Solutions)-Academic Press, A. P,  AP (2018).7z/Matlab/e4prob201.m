% e4sprob201
% Solution of Problem 2.1
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = hilb(5);
IA = inv(A);
fprintf('Computed inverse of A\n')
disp(IA)
fprintf('\n')
IA1 = invhilb(5);
fprintf('Exact inverse of A\n')
disp(IA1)
fprintf('\n')
B1 = inv(A.'*A);
fprintf('Evaluation of inv(A.''*A) = \n')
disp(B1)
fprintf('n = 5, norm(IA1-IA) = %10.6e\n\n',norm(IA1-IA))

clear all
fprintf('\n       n     cond(A)      cond(P)    norm(P-R)    norm(Q-R) \n')
for n = 3:6
    A = hilb(n);
    P = inv(A.'*A);
    Q = inv(A)*inv(A).';
    R = invhilb(n)*invhilb(n).';
    fprintf('%8.0f %12.4e %12.4e %12.4e %12.4e \n',n, cond(A), cond(P), norm(P-R), norm(Q-R))
end
