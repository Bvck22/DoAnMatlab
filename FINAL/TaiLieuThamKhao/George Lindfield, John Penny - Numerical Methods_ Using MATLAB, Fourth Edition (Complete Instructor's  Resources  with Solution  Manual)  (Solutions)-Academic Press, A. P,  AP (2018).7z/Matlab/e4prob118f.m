function [x1,x2] = e4prob118f(a,b,c)
% a, b and c are the coefficients of the quadratic
% a*x^2+b*x+c = 0. Output x1 and x2 are the roots of the equation.
% 
% Solution of Problem 1.18
%
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

if a~=0
    d = b*b-4*a*c;
    x1 = (-b+sqrt(d))/(2*a); 
    x2 = (-b-sqrt(d))/(2*a);
else
    disp('Warning - only one root'); 
    x1 = -c/b; 
    x2 = x1;
end