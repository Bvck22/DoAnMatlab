% e4prob914
% Solution of Problem 9.14
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB 4e' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

r = 10; 
x0 = [5 5];
fprintf('       r         x1(1)      x1(2)\n')
fprintf('%12.6f %10.4f %10.4f\n',r, x0(1), x0(2))
while r>0.0001
    fm = @(x) x(1).^4+100*x(2).^2+x(1)-r*log(-6+4*x(1)+x(2))...
         +1/r*(x(1)+x(2)-3).^2-r*log(x(1))-r*log(x(2));
    x1 = fminsearch(fm,x0);
    r = r/5;
    fprintf('%12.6f %10.4f %10.4f\n',r, x1(1), x1(2))
    x0 = x1;
end

mn = x0(1).^4+100*x0(2).^2+x0(1);
fprintf('\nmin(f) = %6.4f at x = [%6.4f %6.4f]\n',mn,x0(1),x0(2))

figure(1)
x = 0:0.1:4; y = 0:0.1:6.5;
[X Y] = meshgrid(x,y);
Z = X.^4+100*Y.^2+X;
contour(X,Y,Z,40)
hold on
plot(2.6276,0.3677,'+r')
x1 = 0:0.02:1.14;
y1 = 6-4*x1.^3; y10 = 6.5-4*x1.^3;
x2 = 0:0.1:3;
y2 = 3-x2;
plot(x1,y1,'r',x2,y2,'k')
title('Contour plot of f(x) = x_1^4 +100x_2^2 +x_1')
xlabel('x_1 value')
ylabel('x_2 value')
hold off
