% e4prob504
% Solution of Problem 5.4
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
f = @(t,y) [y(2); (y(2)+8*t.^3.*y(1).^3)./t];
[x,y] = ode23(f,[1 4],[0.5 -0.5]);

fprintf('ode23, x(4) = %6.4f \n', y(end,1))
figure(1), plot(x,y(:,1),'o',x,1./(1+x.^2),'-')
xlabel('x')
ylabel('f(x)')
legend('ode23','exact')

[x,y] = ode45(f,[1 4],[0.5 -0.5]);
fprintf('ode45, x(4) = %6.4f \n', y(end,1))
figure(2), plot(x,y(:,1),'o',x,1./(1+x.^2),'-')
xlabel('x')
ylabel('f(x)')
legend('ode45','exact')

exact = 1/(1+x(end)^2);

fprintf('exact, x(4) = %8.6f \n', exact)