% e4prob311
% Solution of Problem 3.11
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

f = @(x) [2*x(1)-sin((x(1)+x(2))/2); 2*x(2)-cos((x(1)-x(2))/2)];
[sol,iter] = broyden([10,-10]',f,2,1e-4);
fprintf('Using Broyden method, x = [%7.4f %7.4f] after %2.0f iterations \n',sol(1), sol(2), iter)

figure(1)
fimplicit(@(x,y) 2*x-sin((x+y)/2), [0.0 0.5 0.2 0.7]), hold on
fimplicit(@(x,y) 2*y-cos((x-y)/2), [0.0 0.5 0.2 0.7]), hold off
grid
xlabel('x'), ylabel('y')
title('Implicit plot of given functions')
legend('2x-sin((x+y)/2)=0','2y-cos((x-y)/2)=0')