% e4prob122
% Solution of Problem 1.22
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
a = 11;
b = 6;
t = -20:0.1:20;

figure(1)
% Cycloid
x = a*(t-sin(t));
y = a*(1-cos(t));
subplot(3,1,1)
plot(x,y)
xlabel('x-axis')
ylabel('y-axis')
title('Cycloid')

% witch of agnesi
x1 = 2*a*t;
y1 = 2*a./(1+t.^2);
subplot(3,1,2)
plot(x1,y1)
xlabel('x-axis')
ylabel('y-axis')
title('witch of agnesi')

% Complex structure
x2 = a*cos(t)-b*cos(a/b*t);
y2 = a*sin(t)-b*sin(a/b*t);
subplot(3,1,3)
plot(x2,y2)
xlabel('x-axis')
ylabel('y-axis')
title('Complex structure')

