% e4prob915
% Solution of Problem 9.15
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

r = 10; 
x0 = [5 5];
fprintf('       r         x1(1)      x1(2)\n')
fprintf('%12.6f %10.4f %10.4f\n',r, x0(1), x0(2))
while r>0.0001
    fm = @(x) x(1).^4+100*x(2).^2+x(1)+1/r*min(0,(-6+4*x(1).^3+x(2))).^2 ... 
         +1/r*(x(1)+x(2)-3).^2+1/r*min(0,x(1)).^2+1/r*min(0,x(2)).^2;
    x1 = fminsearch(fm,x0);
    r = r/5;
    fprintf('%12.6f %10.4f %10.4f\n',r, x1(1), x1(2))
    x0 = x1;       
end

mn = x0(1).^4+100*x0(2).^2+x0(1);
fprintf('\nmin(f) = %6.4f at x = [%6.4f %6.4f]\n',mn,x0(1),x0(2))

