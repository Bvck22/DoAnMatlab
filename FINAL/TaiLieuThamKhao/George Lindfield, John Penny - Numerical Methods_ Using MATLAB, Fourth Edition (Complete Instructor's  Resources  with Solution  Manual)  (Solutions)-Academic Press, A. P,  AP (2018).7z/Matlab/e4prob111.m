% e4prob111
% Solution of Problem 1.11
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

[x,y] = meshgrid(1:0.1:3,1:0.1:3);
z = 2*x.*y./(x.^2+y.^2);

figure(1), mesh(x,y,z)
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')
title('mesh graph')

figure(2), surf(x,y,z)
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')
title('surf graph')

figure(3), surfl(x,y,z)
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')
title('surfl graph')

figure(4), contour(x,y,z,30)
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')
title('contour graph')

