% e4prob422
% Solution of Problem 4.22
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f = @(x,y) 1./(1-x.*y);

int0 = gauss2v(f,0,1,0,1,16);
fprintf('Using Gauss: I = %8.6f\n',int0)
fprintf('      Exact: I = %8.6f\n',pi^2/6)

[xx,yy] = meshgrid(0:0.02:1,0:0.02:1);
z = f(xx,yy);
figure(1), surf(xx,yy,z)
xlabel('x')
ylabel('y')
zlabel('f(x,y)')
axis([0 1 0 1 0 30])