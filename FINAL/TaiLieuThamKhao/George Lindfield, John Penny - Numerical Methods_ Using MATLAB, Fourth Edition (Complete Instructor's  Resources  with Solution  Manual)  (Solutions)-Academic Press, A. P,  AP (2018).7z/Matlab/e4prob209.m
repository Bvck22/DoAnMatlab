% e4prob209
% Solution of Problem 2.9
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

for n = [20 50]
    C = zeros(n,n);
    E = zeros(n,n);
    for m = 1:n
        for j = 1:n
            if m==j
                C(m,j) = m*(n-m+1);
            elseif j>m
                C(m,j) = C(m,j-1)-m;
            else
                C(m,j) = C(j,m);
            end
        end
    end
    E = C/(n+1);
    lambda = eig(E);
    k = n:-1:1;
    exact = 1./(2-2*cos(k*pi/(n+1))).';
    err = norm(lambda-exact);
    fprintf('n = %3.0f: norm(approx-exact) = %12.6e\n',n,err)
end
