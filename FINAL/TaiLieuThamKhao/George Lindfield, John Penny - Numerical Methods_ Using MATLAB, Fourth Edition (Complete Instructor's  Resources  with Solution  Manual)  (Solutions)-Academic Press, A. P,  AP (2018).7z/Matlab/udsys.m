function [x1,x2,x3,x4,nv1,nv2,nv3,nv4] = udsys(A,b)
%
% Required for Problem 2.20.
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

newA = A.'*A;
newb = A.'*b;
x1 = inv(newA)*newb;
nv1 = norm(A*x1-b);

x2 = A\b;
nv2 = norm(A*x2-b);

x3 = newA\newb;
nv3 = norm(A*x3-b);

x4 = pinv(A)*b;
nv4 = norm(A*x4-b);

