% e4prob211
% Solution of Problem 2.11
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [8 -1 -5;-4 4 -2;18 -5 -7];

[vr lam] = eig(A);
disp('Right eigenvector')
disp(vr)
disp('Corresponding eigenvalues')
disp(diag(lam.'))

[vl lam1] = eig(A.');
disp('Left eigenvector')
disp(vl)
disp('Corresponding eigenvalues')
disp(diag(lam1.'))
