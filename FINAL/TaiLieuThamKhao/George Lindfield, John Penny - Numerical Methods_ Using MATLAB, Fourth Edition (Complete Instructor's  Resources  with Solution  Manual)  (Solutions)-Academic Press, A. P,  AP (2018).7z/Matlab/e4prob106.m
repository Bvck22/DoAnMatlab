% e4prob106
% Solution of Problem 1.6
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
A = rand(4)
b = rand(4,1)
x = A\b
b1 = A*x
disp('norm of difference of A*x and b')
norm(A*x-b)