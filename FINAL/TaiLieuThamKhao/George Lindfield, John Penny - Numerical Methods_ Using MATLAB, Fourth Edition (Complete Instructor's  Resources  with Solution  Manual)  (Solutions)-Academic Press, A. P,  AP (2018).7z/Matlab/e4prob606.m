% e4prob606
% Solution of Problem 6.6
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
K = 1;
hx = 0.05; nx = 20; 
ht = 0.01; nt = 50; 
init = zeros(1,nx+1);
init(1,nx+1) = 10;
lowb = 0; 
hib = 10;
u = heat(nx,hx,nt,ht,init,lowb,hib,K);

x = 0:0.05:1; t = 0:0.01:0.5;
figure(1)
surfl(x,t,u)
%axis([1 21 1 51 0 20])
view([124 -24])
xlabel('Location x')
ylabel('Time')
zlabel('Temperature')

figure(2)
plot(0:0.05:1,u([2 4 8 16 32],:))
axis([0 1 0 10])
xlabel('Location x')
ylabel('Temperature')
grid
legend('time = 0.02s','time = 0.04s','time = 0.08s','time = 0.16s','time = 0.32s')

