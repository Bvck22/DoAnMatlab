% e4prob605
% Solution of Problem 6.5
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
L = 2; 
h = L/20;
A = zeros(19,19);
A = diag(-2*ones(19,1))+diag(ones(18,1),1)+diag(ones(18,1),-1);
% Solve evp
beta = eig(A);
lam = -beta/h^2;
lam = sort(lam);
% lowest eigenvalue
lambda = lam(1);
% Exact lowest eigenvalue
lambda_exact = (pi/L)^2;

fprintf('Lowest eigenvalue (approx) = %8.6f \n',lambda) 
fprintf('Lowest eigenvalue  (exact) = %8.6f \n',lambda_exact) 

