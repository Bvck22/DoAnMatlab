% e4prob503
% Solution of Problem 5.3
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
f = @(t,y) -0.05*y;

[tvals, yvals] = abm(f,[0 50],50,2);
fprintf('Adams-Bashford-Moulton h = 2, t(50) = %6.4f \n', yvals(end))
figure(1), plot(tvals,yvals,'o',tvals,50*exp(-0.05*tvals))
xlabel('t')
ylabel('f(t)')
legend('Adams-Bashford-Moulton h = 2','exact')

[tvals, yvals] = fhamming(f,[0 50],50,2);
fprintf('Hamming h = 2, t(50) = %6.4f \n', yvals(end))
fprintf('Exact, t(50) = %8.6f \n', 50*exp(-0.05*50))
figure(2), plot(tvals,yvals,'o',tvals,50*exp(-0.05*tvals))
xlabel('t')
ylabel('f(t)')
legend('Hamming h = 2','exact')