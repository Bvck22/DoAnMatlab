% e4prob429
% Solution of Problem 4.29
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

%see Concise Encyclopaedia of Mathematics, page 581

clear all
close all

f = @(x) -log(x).^3./exp(x);
val = quadgk(f,0,Inf);
gam = -psi(1);
S3 = gam^3+0.5*gam*pi^2+2*zeta(3);
fprintf('S(3) using quadgk function = %8.7f \n',val)
fprintf('S(3) from formula          = %8.7f \n',S3)
