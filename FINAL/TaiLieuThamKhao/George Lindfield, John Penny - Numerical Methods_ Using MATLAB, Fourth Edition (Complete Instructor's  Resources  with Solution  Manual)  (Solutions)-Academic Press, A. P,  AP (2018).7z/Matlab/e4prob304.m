% e4prob304
% Solution of Problem 3.4
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

c = [5 10];
xint = [1.3 1.4];

for c = [5 10];
    xint = [1.3 1.4];
    for k = 1:2    
        f = @(x) tan(x)-c;
        df = @(x) sec(x).^2;
        [root1, iter1] = fnewton(f,df,xint(k),1e-4);
        fprintf('Using Newton method, c = %7.4f, x = %7.4f after %2.0f iterations \n',c, root1,iter1)
    end
end

figure(1)
xp = 1:0.02:2;
plot(xp,tan(xp)-5,xp,tan(xp)-10)
xlabel('x')
ylabel('f(x)')
axis([1 2 -20 20])
legend('c = 5','c = 10')
grid