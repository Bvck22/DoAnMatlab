% e4prob218
% Solution of Problem 2.18
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

cs = 0;
for n = 5:5:50
    cs = cs+1;
    A = diag(2*ones(1,n))+diag(-1*ones(1,n-1),1) + diag(-1*ones(n-1,1),-1);
    cd(cs) = cond(A);
end

C = log(cd.')
Z = [ones(cs,1), log(5:5:50).']
r = pinv(Z)*C;
q = r(2);
p = exp(r(1));
fprintf('Using the pinv function: c = %5.4fn^%5.4f\n',p,q)

r = Z\C;
q = r(2);
p = exp(r(1));
fprintf('Using the back-slash operator: c = %5.4fn^%5.4f\n',p,q)

plot(5:5:50,cd,'o',1:50,p*[1:50].^q,'-')
xlabel('Sixe of matrix, n')
ylabel('Condition number')

    
