function y = e4prob128fb(x)
% Evaluates the function y = (1+exp(x))/(cos(x)+sin(x))

% Solution of Problem 1.28
%
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

y = (1+exp(x))./(cos(x)+sin(x));