% e4prob314
% Solution of Problem 3.14
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

sol = bairstow([-1  -1  1  -2  2],5,1e-4);
for k = 1:5
    fprintf('real = %7.4f    imag = %7.4f \n', sol(k,1), sol(k,2))
end

x = -2:0.01:2;
y = x.^5-x.^4-x.^3+x.^2-2*x+2;
plot(x,y)
axis([-2 2 -10 10])
grid
xlabel('x')
ylabel('f(x)')