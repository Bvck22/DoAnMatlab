% e4prob513
% Solution of Problem 5.13
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

close all
clear all
c = 30;
r = 0.01;
f = @(t,y) [-c*y(2); -r*y(1)*y(2)];

[t,y] = ode45(f,[0 0.6],[2000 700]');
plot(t,y)
xlabel('Time')
ylabel('Force size')
legend('Government', 'Guerillas')
axis([0 0.6 0 2200])
fprintf('Governemnt force at t = 0.6 = %3.0f\n', y(end,1))
fprintf('  Guerilla force at t = 0.6 = %3.0f\n', y(end,2))