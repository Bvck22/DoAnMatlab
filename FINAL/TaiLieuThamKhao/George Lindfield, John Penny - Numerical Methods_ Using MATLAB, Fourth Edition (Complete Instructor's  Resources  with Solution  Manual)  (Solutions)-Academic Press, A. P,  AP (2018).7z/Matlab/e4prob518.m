% e4prob518
% Solution of Problem 5.18
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018
clear all
close all

C = 1.5; Q0 = 2.8; t0 = 1;

R = 10; 
figure(1)
[t,P10] = ode45(@(t,P)(Q0/C)*sin(pi*t/t0)-P/(R*C),[t0,10],5);
plot(t,P10)
xlabel('Time')
ylabel('Pressure P')
axis([0 10 1.5 5.5])
grid
hold on
R = 40;
[t,P40] = ode45(@(t,P)(Q0/C)*sin(pi*t/t0)-P/(R*C),[t0,10],5);
plot(t,P40)
legend('R = 10','R = 40')
hold off
