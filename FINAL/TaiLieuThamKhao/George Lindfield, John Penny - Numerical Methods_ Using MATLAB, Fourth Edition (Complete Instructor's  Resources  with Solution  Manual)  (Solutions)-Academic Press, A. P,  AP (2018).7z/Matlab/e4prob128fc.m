function z = e4prob128fc(x,y)
% Evaluates the function z = cos(x^2+y^2)

% Solution of Problem 1.28
%
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

z = cos(x.^2+y.^2);