% e4prob517
% Solution of Problem 5.17
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

%Solution of Daiy world problem
clear all
close all

span = 10;

[t,x] = ode45(@daisyf,[0 span],[0.2, 0.3]);

y = ones(size(x(:,1)))-x(:,1)-x(:,2);

figure(1), plot(t,x(:,1),'k',t,x(:,2),'r',t,y,'b')
xlabel('Time')
ylabel('Black and white daisy areas')
title('Daisy world')
legend('Black', 'White', 'Barren')

%-------------------------------------------------------
function daisyrhs = daisyf(t,x)
daisyrhs = zeros(2,1);
gamma = 0.3;
Tb = 295;
Tw = 285;
betab = 1-0.003265*(295.5-Tb);
betaw = 1-0.003265*(295.5-Tw);
barbit = 1-x(1)-x(2);
daisyrhs(1) = x(1).*(barbit.*betab-gamma);
daisyrhs(2) = x(2).*(barbit.*betaw-gamma);
end