function f = e4prob904f(x)

% This MATLAB function is to accompany 'Numerical Methods using MATLAB e4' 
% by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

f = 100*(x(1).^2-x(2)).^2+(1-x(1)).^2;
end

