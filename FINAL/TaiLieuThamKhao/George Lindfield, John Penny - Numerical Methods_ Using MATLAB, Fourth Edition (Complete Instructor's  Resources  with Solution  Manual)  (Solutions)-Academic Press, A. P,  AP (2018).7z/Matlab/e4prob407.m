% e4prob407
% Solution of Problem 4.7
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

for r = 0:2
    f = @(x) 1./((1+x.^2).*(1+r^2*x.^2).*(1+r^4*x.^2));
    int = galag(f,8);
    v = pi*(r^2+r+1)/(2*(r^2+1)*(r+1)^2);
    fprintf('r = %1.0f: estimate = %6.4f, exact = %6.4f\n',r,int, v)
end