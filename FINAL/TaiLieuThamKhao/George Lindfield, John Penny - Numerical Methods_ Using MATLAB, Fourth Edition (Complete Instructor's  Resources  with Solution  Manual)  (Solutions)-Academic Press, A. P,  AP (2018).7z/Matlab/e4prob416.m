% e4prob416
% Solution of Problem 4.16
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f = @(x) (exp(-2*x)-exp(-x))./x;
int0 = galag(f,8);
fprintf('Using Gauss-Laguerre: I = %15.7e\n',int0)
fprintf('               Exact: I = %15.7e\n',-log(2))