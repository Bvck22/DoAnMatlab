% e4prob135
% Solution of Problem 1.35
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
theta = -2*pi:0.1:2*pi;
r = cos(theta).*sin(theta);
figure(1)
polarscatter(theta,r)
title('Polar plot of r = cos(\theta)sin(\theta)') 
figure(2)
polarscatter(theta,r,200,'green')
title('Polar plot of r = cos(\theta)sin(\theta) with enlarged green points') 