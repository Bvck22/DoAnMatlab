% e4prob408
% Solution of Problem 4.8
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f = @(x) log(gamma(x));
for a = 1:2
    val = simp1(f,a,a+1,16);
    ex = a*log(a)-a+log(sqrt(2*pi));
    fprintf('a = %1.0f: estimate = %8.5f\n',a,val)
    fprintf('a = %1.0f: exact    = %8.5f\n\n',a,ex)
end