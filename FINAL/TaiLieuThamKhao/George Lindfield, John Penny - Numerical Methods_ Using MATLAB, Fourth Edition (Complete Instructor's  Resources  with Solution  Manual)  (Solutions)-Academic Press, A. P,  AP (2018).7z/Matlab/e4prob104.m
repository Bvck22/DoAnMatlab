% e4prob104
% Solution of Problem 1.4
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
A = [2 1 5;2 2 3;1 3 3]
b = [5 7 6].'

sol_1 = inv(A)*b
sol_2 = A\b
sol_3 = b.'/A.'

e1 = norm(A*sol_1-b)
e2 = norm(A*sol_2-b)
e3 = norm(A*sol_3.'-b)