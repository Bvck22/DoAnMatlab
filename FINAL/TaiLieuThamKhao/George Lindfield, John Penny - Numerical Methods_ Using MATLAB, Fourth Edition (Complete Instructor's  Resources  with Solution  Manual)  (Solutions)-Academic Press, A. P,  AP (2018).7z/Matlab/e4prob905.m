% e4prob905
% Solution of Problem 9.5
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

fprintf('Using trial vector [%4.2f %4.2f%4.2f %4.2f %4.2f]\n', 1, 2, 0, 2, 3)
res = mincg('e4prob905f','e4prob905df','ftau905',[1 2 0 2 3]',.005);

for k = 1:5
    fprintf('x(%1.0f) = %8.4f \n',k,res(k))
end
fprintf('   z = %8.4f \n',e4prob905f(res))
fprintf('\n')

v = 5*rand(1,5);
fprintf('Using trial vector [%7.4f %7.4f %7.4f %7.4f %7.4f]\n', v)
res = mincg('e4prob905f','e4prob905df','ftau905',5*rand(1,5)',.005);

for k = 1:5
    fprintf('x(%1.0f) = %8.4f \n',k,res(k))
end
fprintf('   z = %8.4f \n',e4prob905f(res))
fprintf('\n')

