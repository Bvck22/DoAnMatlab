% e4prob221
% Solution of Problem 2.21
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

p = 1/sqrt(3); 
q = 1/sqrt(6); 
r = 1/sqrt(2);
B = [p q -r; p -2*q 0; p q r];
BB = B*B.';
disp('B*B_transpose')
disp(BB)

co = cos(pi/3); 
si = sin(pi/3);
C = [co si; -si co];
CC = C*C.';
disp('C*C_transpose')
disp(CC)

fprintf('norm of (B*B''-I) = %11.4e\n', norm(BB-eye(3)))
fprintf('norm of (C*C''-I) = %11.4e\n', norm(CC-eye(2)))