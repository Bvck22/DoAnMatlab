% e4prob220
% Solution of Problem 2.20
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [1 -2 -5 3;3 4 2 -7];
b = [-10 20].';

[x1 x2 x3 x4 n1 n2 n3 n4] = udsys(A,b);

fprintf('x = inv(A.''*A)*(A.''*b)\n')
fprintf('x = [%6.4f  %6.4f   %6.4f  %6.4f]''\n',x1(1),x1(2),x1(3),x1(4))
fprintf('norm(x) = %12.4e\n',norm(x1))
fprintf('norm(Ax-b) = %12.4e\n', n1)
b1 = A*x1;
fprintf('b = Ax: b = [%8.4f %8.4f]''\n\n', b1(1), b1(2))

fprintf('x = A backslash b\n')
fprintf('x = [%6.4f  %6.4f   %6.4f  %6.4f]''\n',x2(1),x2(2),x2(3),x2(4))
fprintf('norm(x) = %12.4e\n',norm(x2))
fprintf('norm(Ax-b) = %12.4e\n', n2)
b2 = A*x2;
fprintf('b = Ax: b = [%8.4f %8.4f]''\n\n', b2(1), b2(2))

fprintf('x = (A.''*A) backslash (A.''*b)\n')
fprintf('x = [%6.4f  %6.4f   %6.4f  %6.4f]''\n',x3(1),x3(2),x3(3),x3(4))
fprintf('norm(x) = %12.4e\n',norm(x3))
fprintf('norm(Ax-b) = %12.4e\n', n3)
b3 = A*x3;
fprintf('b = Ax: b = [%8.4f %8.4f]''\n\n', b3(1), b3(2))

fprintf('x = pinv(A)*b\n')
fprintf('x = [%6.4f  %6.4f   %6.4f  %6.4f]''\n',x4(1),x4(2),x4(3),x4(4))
fprintf('norm(x) = %12.4e\n',norm(x4))
fprintf('norm(Ax-b) = %12.4e\n', n4)
b4 = A*x4;
fprintf('b = Ax: b = [%8.4f %8.4f]''\n', b4(1), b4(2))


    
