% e4prob714
% Solution of Problem 7.14
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

fprintf('The value of a complete elliptic integral of the first \n')
fprintf('kind is normally written as K(alpha)\n\n')
a = [ 0 5 10 15 20 25];
I = [1.57080 1.57379 1.58284 1.59814 1.62003 1.64900];
alpha1 = interp1(I,a,1.58);
K1 = interp1(a,I,2);

fprintf('Using interp1: alpha = 2 degrees, K(2) = %6.4f \n', K1)
fprintf('Using interp1: K = 1.58, alpha = %6.4f degrees\n\n', alpha1)

alpha2 = aitken(I,a,1.58);
K2 = aitken(a,I,2);

fprintf('Using aitken: alpha = 2 degrees, K(2) = %6.4f \n', K2)
fprintf('Using aitken: K = 1.58, alpha = %6.4f degrees\n\n', alpha2)
fprintf('Exact: alpha = 2 degrees, K(2) = 1.5713\n')
fprintf('Exact: K = 1.58, alpha = 8.71406 degrees\n')

figure(1)
plot(a,I,'ok',2,1.5713,'r*')
xlabel('\alpha, degrees')
ylabel('Value of Integral K(\alpha)')
title('I = K(\alpha)')
axis([0 25 1.56 1.66])
grid

figure(2)
plot(I,a,'ok',1.58,8.71406,'r*')
ylabel('\alpha, degrees')
xlabel('Value of Integral K(\alpha)')
title('\alpha = f(I)')
axis([1.57 1.65 0 30])
grid

