% e4prob214
% Solution of Problem 2.14
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

for n = [5 50]
    A = zeros(n,n);
    for m = 1:n
        A(m,:) = n:-1:1;
    end
    for m = 2:n
        for k = 1:m-1
            A(m,k) = n-m+1;
        end
    end
    lambda = eig(A);
    lambda = sort(lambda);
    
  	for m = 1:n
        lambdaf(m) = 1/(2*(1-cos((2*m-1)*pi/(2*n+1))));
    end
  	lambdaf = sort(lambdaf);
    error1 = abs(lambda(1)-lambdaf(1));
  	errorn = abs(lambda(n)-lambdaf(n));
    fprintf('Size of matrix = %2.0f x %2.0f\n',n,n)
  	fprintf('lambda  comp(1) = %12.8f lambda  comp(%2.0f) = %13.8f\n', lambda(1),n,lambda(n))
  	fprintf('lambda exact(1) = %12.8f lambda exact(%2.0f) = %13.8f\n', lambdaf(1),n,lambdaf(n))
    fprintf('lambda error(1) = %12.3e lambda error(%2.0f) = %13.3e\n\n', error1,n, errorn)
end
    