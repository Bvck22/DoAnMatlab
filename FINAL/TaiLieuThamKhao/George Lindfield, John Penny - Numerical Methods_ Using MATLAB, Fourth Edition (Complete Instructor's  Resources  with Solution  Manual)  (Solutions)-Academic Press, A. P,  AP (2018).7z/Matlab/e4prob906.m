% e4prob906
% Solution of Problem 9.6
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [5 4 1 1;4 5 1 1;1 1 4 2;1 1 2 4];
b = [1 2 3 4]';
[n n] = size(A);
x = solvercg(A,b,n,0.0001);

for k = 1:4
    fprintf('x(%1.0f) = %7.4f \n',k,x(k))
end

fprintf('Error = %10.4e\n',norm(b-A*x))