function y = e4prob131f(n)
% e4prob131
% Solution of Problem 1.31
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

% Factorial function implemented recurcively
if n<0
disp('Use only positive values for n')
return
end
if n==0
y = 1;
return
end
% e4prob131f(n) = n*facr(n-1);
y = n*e4prob131f(n-1);
% y = e4prob131f(n);
end
