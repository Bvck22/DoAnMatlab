% e4prob112
% Solution of Problem 1.12
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

d = 1;
x0 = 2;
while abs(d)>0.0005
    x1 = 1+1/x0;
    d = x1-x0;
    x0 = x1;
end
res = x0^2-x0-1;
disp(['Solution is ' num2str(x0)])
disp(['x0^2-x0-1 equals ' num2str(res)])