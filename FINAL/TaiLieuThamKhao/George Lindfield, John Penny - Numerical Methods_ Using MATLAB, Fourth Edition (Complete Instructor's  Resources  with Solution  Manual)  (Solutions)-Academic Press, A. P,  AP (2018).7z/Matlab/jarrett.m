function v = jarrett(f,x1,x2,tol)
% v = jarrett(f,x1,x2,tol)
% Based on Jarrett's description of the Illinois algorithm to 
% determine a root of the function f using two initial values x1 and x2.
% The iteration stops when the change in the value of the root < tol.
%
% Required for Problem 3.16
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfiled and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

gamma = 0.5; d = 1;
while abs(d)>tol
    f2 = feval(f,x2);
    f1 = feval(f,x1);
    df = (f2-f1)/(x2-x1); 
    x3 = x2-f2/df; 
    d = x2-x3;
    if f1*f2>0
        x2 = x1; 
        f2 = gamma*f1;
    end
    x2 = x3;
    v = x2;
end