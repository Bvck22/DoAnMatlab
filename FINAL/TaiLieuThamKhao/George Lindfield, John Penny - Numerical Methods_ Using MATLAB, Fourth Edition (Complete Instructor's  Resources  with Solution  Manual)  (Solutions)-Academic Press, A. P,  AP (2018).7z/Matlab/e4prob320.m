% e4prob320
% Solution of Problem 3.20
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

p = 1:5;
q = [0.3 -0.5 1 -1 2];
n = length(p);
x = -3:0.01:3;
hold on 
for c = 1:n
    f = p(c)^3/q(c)^2;
    s = roots([1 0 -p(c) -q(c)]);
    fprintf('p^3/q^2 = %6.4f, roots = [ %6.4f %6.4f %6.4f] \n', f, s(1),s(2),s(3))
    figure(1), plot(x,x.^3-p(c)*x-q(c)*ones(size(x)))
end
hold off
axis([-3 3 -10 10])
legend('f = 11.11','f = 32','f = 27','f = 64','f = 31.25')
xlabel('x')
ylabel('f(x)')
grid