% e4prob110
% Solution of Problem 1.10
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

x = 0:0.02:4;
y1 = 3*sin(pi*x);
y2 = exp(-0.2*x);

%This statement allows two graphs with same axes
plot(x,y1,x,y2)
xlabel('x-axis')
ylabel('sin and exp values')
title('Graphs')
grid
legend('sine function','exponential function')
disp('Enter text at a point of intersection')
gtext('Point of intersection')