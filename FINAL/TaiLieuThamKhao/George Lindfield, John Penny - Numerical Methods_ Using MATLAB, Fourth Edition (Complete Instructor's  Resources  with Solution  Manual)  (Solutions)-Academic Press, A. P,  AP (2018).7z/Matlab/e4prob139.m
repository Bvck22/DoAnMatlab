% e4prob139
% Solution of Problem 1.39
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

% See also Problem 4.35.

clear all
close all
tol = 0.000005;
s = 0; r = 0;
term = 2*tol;
while term > tol
    term = 1/((2*r+1)*factorial(r));
    s = s+term;
    r = r+1;
end
s = s/exp(1);
s_exact =  0.538079506912768;
fprintf('Sum  of  series = %10.8f\n',s)
fprintf('Exact summation = %16.14f\n',s_exact)


