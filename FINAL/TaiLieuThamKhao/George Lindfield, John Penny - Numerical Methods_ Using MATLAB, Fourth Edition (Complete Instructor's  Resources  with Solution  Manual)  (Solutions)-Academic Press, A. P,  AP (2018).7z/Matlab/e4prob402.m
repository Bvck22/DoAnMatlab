% e4prob402
% Solution of Problem 4.2
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

for x = 1:3
    res = diffgen(@(x) cos(x.^6),1,x,0.001);
    fprintf('x =%2.0f, first derivative = %11.6f\n',x,res)
end
fprintf('\n')
for x = 1:3
    fprintf('x =%2.0f, exact first derivative = %11.6f\n',x,-6*x^5*sin(x^6))
end