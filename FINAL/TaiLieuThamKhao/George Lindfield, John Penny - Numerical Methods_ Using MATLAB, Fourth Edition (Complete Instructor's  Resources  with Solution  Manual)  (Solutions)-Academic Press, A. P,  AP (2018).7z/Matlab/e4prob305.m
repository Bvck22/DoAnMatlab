% e4prob305
% Solution of Problem 3.5
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

f = @(x) x.^5-5*x.^4+10*x.^3-10*x.^2+5*x-1;
df = @(x) 5*x.^4-20*x.^3+30*x.^2-20*x+5;

[root1 iter1] = schroder(f,df,5,2,5e-7);
[root2 iter2] = fnewton(f,df,2,5e-7);
fprintf('Using Schroder method, x = %7.4f after %2.0f iterations \n',root1,iter1)
fprintf('Using   Newton method, x = %7.4f after %2.0f iterations \n',root2,iter2)

sol_rts = roots([1 -5 10 -10 5 -1]);
disp(' ')
for k = 1:5
    disp(['using roots, x = ' num2str(sol_rts(k))])
end

figure(1)
xp = 0:0.005:2;
plot(xp,f(xp))
xlabel('x')
ylabel('f(x)')
axis([0 2 -1 1])
grid




