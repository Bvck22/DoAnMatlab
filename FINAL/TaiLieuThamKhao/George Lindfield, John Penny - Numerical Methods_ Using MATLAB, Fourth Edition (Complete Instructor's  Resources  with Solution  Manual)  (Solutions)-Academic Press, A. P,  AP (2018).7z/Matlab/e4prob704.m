% e4prob704
% Solution of Problem 7.4
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

x = -1:0.2:1;
y = sin(pi*x/2).^2;
linear_interpolation = interp1(x,y,0.85,'linear')
spline_fit = interp1(x,y,0.85,'spline')
cubic_interpolation = interp1(x,y,0.85,'pchip')
aitken_interpolation = aitken(x,y,0.85)