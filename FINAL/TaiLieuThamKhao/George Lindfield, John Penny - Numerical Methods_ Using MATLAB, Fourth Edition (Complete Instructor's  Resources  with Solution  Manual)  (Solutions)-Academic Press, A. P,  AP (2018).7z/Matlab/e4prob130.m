% e4prob130
% Solution of Problem 1.30
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

g = (1+sqrt(5))/2;

sFs = @(x) (g.^x-g.^-x)/sqrt(5);
cFs = @(x) (g.^x+g.^-x)/sqrt(5);

cqsF = @(x,n) (g.^x-cos(n*pi*x).*g.^-x)/sqrt(5)+ ...
              i*(sin(n*pi*x).*g.^-x)/sqrt(5);
          
x = -5:0.02:5;
figure(1), plot(x,sFs(x),x,cFs(x))
xlabel('x')
ylabel('sFs(x) and cFs(x)')
legend('sFs(x)','cFs(x)')
grid
figure(2), plot3(x,real(cqsF(x,5)),imag(cqsF(x,5)))
xlabel('x')
ylabel('real(cqsF(x,5)')
zlabel('imag(cqsF(x,5)')
grid