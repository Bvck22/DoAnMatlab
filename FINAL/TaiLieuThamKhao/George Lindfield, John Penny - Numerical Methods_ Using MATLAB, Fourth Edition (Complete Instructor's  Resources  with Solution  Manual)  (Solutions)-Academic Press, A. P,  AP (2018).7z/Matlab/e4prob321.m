% e4prob321
% Solution of Problem 3.21
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

y = roots([1 0 6 -60 36]).';

for k = 1:4
    if abs(imag(y(k))) < 1e-16
        x = 6./y(k);
        z = 10-y(k)-x;
        fprintf('Using roots, [x y z] = [%6.4f %6.4f %6.4f] \n', x,y(k),z)
    end
end
fprintf('Note that the quartic equation has only 2 real roots.\n\n')

fprintf('Broydon soln of 3 equns using two different sets of trial values.\n')
f = @(p) [p(1)+p(2)+p(3)-10; p(1)/p(2)-p(2)/p(3); p(1)*p(2)-6];
p1 = [3 2 5]';
[s1,it] = broyden(p1,f,3,0.0005);
p2 = [9.3 0.64 0.045]';
[s2,it] = broyden(p2,f,3,0.0005);

fprintf('Using Broyden, [x y z] = [%6.4f %6.4f %6.4f] \n',s1(1), s1(2), s1(3))
fprintf('Using Broyden, [x y z] = [%6.4f %6.4f %6.4f] \n',s2(1), s2(2), s2(3))

yp = -1:0.05:4;
plot(yp, yp.^4+6*yp.^2-60*yp+36)
axis([-1 4 -60 60])
xlabel('y')
ylabel('f(y)')
title('y^4+ 6y^2- 60y + 36 = 0')
grid