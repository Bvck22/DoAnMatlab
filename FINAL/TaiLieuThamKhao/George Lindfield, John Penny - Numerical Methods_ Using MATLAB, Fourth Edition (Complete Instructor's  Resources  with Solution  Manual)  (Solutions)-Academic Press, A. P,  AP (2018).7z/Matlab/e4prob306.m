% e4prob306
% Solution of Problem 3.6
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

d = 1;
x0 = 1;
it = 0;
while abs(d)>0.005
    it = it+1;
    x1 = exp(x0/10);
    % Note that x1 = 10*log(x0); is non convergent
    d = x0-x1;
    x0 = x1;
end
fprintf('Using iteration,  x = %7.4f after %2.0f iterations \n',x0,it)

func = @(x) x.^10-exp(x);
dfunc = @(x) 10*x.^9;
[res, it] = fnewton(func,dfunc,1,5e-7);
fprintf('Using Newton method, x = %7.4f after %2.0f iterations \n',res,it)

figure(1)
xp = -1.5:0.01:1.5;
plot(xp,func(xp))
xlabel('x')
ylabel('f(x)')
title('Plot of f(x) = x^{10}- e^x')
axis([-1.5 1.5 -4 4])
grid