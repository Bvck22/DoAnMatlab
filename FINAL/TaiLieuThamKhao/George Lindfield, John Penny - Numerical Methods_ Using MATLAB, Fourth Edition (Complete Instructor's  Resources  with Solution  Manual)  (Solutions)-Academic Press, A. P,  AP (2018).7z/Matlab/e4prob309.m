% e4prob309
% Solution of Problem 3.9
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
f1 = @(x) 1-x+x.^2/4-x.^3/36;
options = optimset('TolFun',1e-4);
four_terms = fzero(f1,1,options);
fprintf('Using four terms, x = %6.4f \n',four_terms)

f2 = @(x) 1-x+x.^2/4-x.^3/36+x.^4/576;
five_terms = fzero(f2,1,options);
fprintf('Using five terms, x = %6.4f \n',five_terms)

f3 = @(x) 1-x+x.^2/4-x.^3/36+x.^4/576-x.^5/(factorial(5)^2);
six_terms = fzero(f3,1,options);
fprintf('Using  six terms, x = %6.4f \n',six_terms)

xp = 1:0.001:2;
plot(xp,f1(xp),xp,f2(xp),xp,f3(xp))
xlabel('x')
ylabel('f(x)')
grid
axis([1 2 -0.1 0.1])
legend('four terms','five terms','six terms')

