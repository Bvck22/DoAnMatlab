% e4prob325
% Solution of Problem 3.25
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018
clear all
close all

A =  0.157; B = -0.940; C = -0.900;
a = -4*A;
b = -B;
c = 3*A+C;
d = 1+B;

coeff = [a b c d]
si = roots(coeff); si = si'
theta_radian = asin(si)
theta_degree = theta_radian*180/pi

% Check solution
error = A*sin(3*theta_radian)+B*cos(theta_radian).^2+C*sin(theta_radian)+1
