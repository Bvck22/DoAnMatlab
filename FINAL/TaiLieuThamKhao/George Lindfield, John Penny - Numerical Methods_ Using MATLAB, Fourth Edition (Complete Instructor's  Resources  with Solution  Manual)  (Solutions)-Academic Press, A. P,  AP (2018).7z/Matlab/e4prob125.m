% e4prob125
% Solution of Problem 1.25
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
D = [1 -1;3 2];

A = D*(D*inv(D))
B = D.*D
C = [D, ones(2);eye(2), zeros(2)]
E = D'*ones(2)*eye(2)
