% e4prob404
% Solution of Problem 4.4
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

for x = [3.1,3.01,3.001 3];
    res0 = diffgen(@(x) cos(x.^6),1,x,0.001);
    exact = -6*sin(x.^6).*x.^5;
    fprintf('x =%5.3f, approx first derivative = %11.6f\n',x,res0)
    fprintf('x =%5.3f, exact  first derivative = %11.6f\n',x,exact)
    fprintf('\n')
end