% e4prob113
% Solution of Problem 1.13
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
A = randn(4,5);

% Using the sum function
sumcol = sum(A,1)

% Using a for-end loop
s = zeros(1,5);
for j = 1:5
    for i = 1:4
        s(j) = s(j)+A(i,j);
    end
end
loop_sum = s