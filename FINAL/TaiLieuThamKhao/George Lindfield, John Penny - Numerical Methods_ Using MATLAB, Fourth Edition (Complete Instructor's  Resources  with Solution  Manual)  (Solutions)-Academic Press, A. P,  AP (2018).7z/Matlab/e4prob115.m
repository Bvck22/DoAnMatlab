% e4prob115
% Solution of Problem 1.15
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x = input('Enter value of x (-1 < x < 1) ');
tol = input('Enter tolerance ');
s = x; 
i = 2; 
term = x;
while abs(term)>tol
    term = -term*x; 
    s = s+term/i; i=i+1;
end
disp(['Sum of series = ' num2str(s)])
exact = log(1+x);
disp(['Exact   value = ' num2str(exact)])