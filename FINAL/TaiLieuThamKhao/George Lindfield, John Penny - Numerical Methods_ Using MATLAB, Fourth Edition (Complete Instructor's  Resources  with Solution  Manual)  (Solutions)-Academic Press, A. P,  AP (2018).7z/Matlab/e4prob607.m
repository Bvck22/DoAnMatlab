% e4prob607
% Solution of Problem 6.7
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
hx = 0.05; ht = 0.05;
nx = 20;  nt = 90;
c = 1;

x = 0:hx:1;
t = 0:ht:4.5;
init = sin(pi*x)+2*sin(2*pi*x);
initslope = zeros(1,nx+1);
hib = zeros(nt+1,1);   
lowb = hib;

u = fwave(nx,hx,nt,ht,init,initslope,lowb,hib,c);

figure(1)
surfl(x,t,u)
axis([0 1 0 4.5 -10 10])
view([-30 38])
xlabel('Position along string') 
ylabel('time')
zlabel('transverse displacement')
title('Finite difference approximation')

figure(2)
[x,t] = meshgrid(0:hx:1,0:ht:4.5);
z = sin(pi*x).*cos(pi*t)+2*sin(2*pi*x).*cos(2*pi*t);
surfl(x,t,z)
axis([0 1 0 4.5 -10 10])
view([-30 38])
xlabel('Position along string') 
ylabel('time')
zlabel('transverse displacement')
title('Exact solution')

p = 9;
figure(3)
plot(x,u(p,:),'o',x,z(p,:))
title('Wave amplitude at t = 0.40 s')
xlabel('Location x')
ylabel('Amplitude')
grid

q = 7;
figure(4)
plot(t,u(:,q),'o',t,z(:,q))
grid
title('Wave amplitude at x = 0.30')
xlabel('Time s')
ylabel('Amplitude')

max_error = max(max(u-z))