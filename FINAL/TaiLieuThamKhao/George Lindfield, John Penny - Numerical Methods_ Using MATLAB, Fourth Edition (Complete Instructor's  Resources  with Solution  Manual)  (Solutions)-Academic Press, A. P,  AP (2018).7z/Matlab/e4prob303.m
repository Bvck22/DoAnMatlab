% e4prob303
% Solution of Problem 3.3
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

f = @(x) abs(x.^3)+x-6;
df = @(x) 3*x.*abs(x)+1;
[root1, iter1] = fnewton(f,df,1,1e-4);
[root2, iter2] = fnewton(f,df,-1,1e-4);
fprintf('Using Newton method, x = %7.4f after %2.0f iterations \n',root1,iter1)
fprintf('Using Newton method, x = %7.4f after %2.0f iterations \n',root2,iter2)

figure(1)
xp = -3:0.02:3;
plot(xp,f(xp))
plot(xp,f(xp))
xlabel('x')
ylabel('f(x)')
grid