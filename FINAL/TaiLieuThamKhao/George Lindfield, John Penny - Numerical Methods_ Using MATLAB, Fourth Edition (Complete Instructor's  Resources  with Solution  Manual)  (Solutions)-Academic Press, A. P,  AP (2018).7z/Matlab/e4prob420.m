% e4prob420
% Solution of Problem 4.20
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

close all
clear all
f1 = @(x,y) x.^10.*y.^10;
q1 = gauss2v(f1,-1,1,-pi,pi,16);
fprintf('Part (a): estimate = %10.5f\n',q1)

f2 = @(x,z) (1+x+(2-x).*z).^(-3).*(2-x);
q2 = gauss2v(f2,0,2,0,1,16);
fprintf('Part (b): estimate = %10.5f\n',q2)