% e4prob425
% Solution of Problem 4.25
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

fa = @(x) -log(x)./(1+x.^2);
vala = quad(fa,0,1);
fprintf('Value of integral A = %8.7f\n',vala)

fb = @(x) atan(x)./x;
valb = quad(fb,0,1);
fprintf('Value of integral B = %8.7f\n',valb)

fc = @(x) x.*exp(-x)./(1+exp(-2*x));
valc = galag(fc,8);
fprintf('Value of integral C = %8.7f\n\n',valc)

fprintf('Value of abs(A-B) = %8.4e\n',abs(vala-valb))
fprintf('Value of abs(B-C) = %8.4e\n',abs(valb-valc))
fprintf('Value of abs(C-A) = %8.4e\n',abs(valc-vala))

xp = 0:0.01:1;
figure(1)
plot(xp,fa(xp))
xlabel('x')
ylabel('log(x)/(1+x^2)')

figure(2)
plot(xp,fb(xp))
xlabel('x')
ylabel('atan(x)/x')