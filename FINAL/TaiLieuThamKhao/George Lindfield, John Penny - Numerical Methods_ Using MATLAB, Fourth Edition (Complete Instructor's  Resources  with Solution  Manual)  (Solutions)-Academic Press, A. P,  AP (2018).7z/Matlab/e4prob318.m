% e4prob318
% Solution of Problem 3.18
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

x0 = 0.7;
n = 1;
for c = [2.8 3.25 3.5 3.9]
    xset = [ ];
    for k = 1:100
        x1 = c*x0*(1-x0);
        xset = [xset  x1];
        x0 = x1;
    end
    x1 = 0.5+sqrt(0.25-1/c);
    x2 = 0.5-sqrt(0.25-1/c);
    disp(['c = ' num2str(c) '. Roots of quadratic = ' num2str(x1) ' and ' num2str(x2)])
   
    figure(n), plot(1:100,xset,'ko-')
    xlabel('Iterations')
    ylabel('x')
    title(['Plot of x against iteration number. c =' num2str(c)])
    n = n+1;
end