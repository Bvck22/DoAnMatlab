% e4prob424
% Solution of Problem 4.24
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

p = 3;
q = 4;
r = 2;

f = @(x) (x.^p-x.^q).*x.^r./log(x);
val = quad(f,0,1);
exa = log((p+r+1)/(q+r+1));
fprintf('Estimated value of integral = %9.8f\n',val)
fprintf('    Exact value of integral = %9.8f\n',exa)