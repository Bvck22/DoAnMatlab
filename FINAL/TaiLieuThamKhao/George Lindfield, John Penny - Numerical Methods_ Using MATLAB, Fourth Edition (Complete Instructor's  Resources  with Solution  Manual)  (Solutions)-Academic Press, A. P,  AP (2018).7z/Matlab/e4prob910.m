% e4prob910
% Solution of Problem 9.10
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
% Part A
func = @(x) (x(1)-1).^2+4*(x(2)+3).^2;

[f0,x0] = asaq(func,[0 0]',100,0.9,-10,10,100);
for n = 2:10
    [fa,xa] = asaq(func,[0 0]',100,0.9,-10,10,100);
     if fa<f0
         f0 = fa;  x0 = xa;
     end
end
fprintf('Easy function: Best estimate of min(f) = %6.4f at x = [%6.4f %6.4f]\n\n',f0,x0(1),x0(2))

[X,Y] = meshgrid(-3:0.1:3,-5:0.1:3);
Z = (X-1).^2+4*(Y+3).^2;
figure(1)
surf(X,Y,Z)
xlabel('x'), ylabel('y'), zlabel('f(x,y)')
title('function z = (x-1)^2+4(y+3)^2')
grid

% Part B
func = @(x) 0.5*(x(1).^4-16*x(1).^2+5*x(1)) +...
      0.5*(x(2).^4-16*x(2).^2+5*x(2))+10*cos(4*(x(1)+2.9035)) ...
              +10*cos(4*(x(2)+2.9035));
          
[f0,x0] = asaq(func,[0 0]',100,0.9,-10,10,100);         
for n = 2:20
    [fa,xa] = asaq(func,[0 0]',100,0.9,-10,10,100);
    if fa<f0
        f0 = fa;
        x0 = xa;
    end
end

fprintf('Difficult function: Best estimate of min(f) = %6.4f at x = [%6.4f %6.4f]\n',f0,x0(1),x0(2))

[X Y] = meshgrid(-5:0.1:5,-5:0.1:5);
Z = 0.5*(X.^4-16*X.^2+5*X)+0.5*(Y.^4-16*Y.^2+5*Y)+ ...
        10*cos(4*(X+2.9035))+10*cos(4*(Y+2.9035));
    
figure(2)
surf(X,Y,Z)
xlabel('x')
ylabel('y')
zlabel('f(x,y)')
title('z = 0.5(x^4-16x^2+5x)+0.5(y^4-16y^2+5y)+10cos(4(x+2.9))+10cos(4(y+2.9))')

figure(3)
contour(X,Y,Z,50)
xlabel('x')
ylabel('y')
title('z = 0.5(x^4-16x^2+5x)+0.5(y^4-16y^2+5y)+10cos(4(x+2.9))+10cos(4(y+2.9))')

