% e43prob516
% Solution of Problem 5.16
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

% Solution of planetary growth.
% The coagulation equation three size model
% Let x(1), x(2) and x(3) represent the 
% number of planetesimals of the three sizes

clear all
close all

global x0
%Initially 
x0 = [200,25,1];
tspan = [0,2];

[t,x] = ode45(@planetrhs, tspan, x0);

fprintf('\nnumber of smallest planetesimals = %3.0f',x(end,1))
fprintf('\nnumber of intermediate planetesimals =%3.0f',x(end,2))
fprintf('\nlargest planetesimals =%3.0f\n',x(end,3))

figure(1), plot(t,x)
xlabel('Time')
ylabel('Numbers of planetesimals')
legend('smallest planetesimals', 'intermediate planetesimals', 'largest planetesimals')
grid

%---------------------------------------------------
function prhs = planetrhs(t,x)
%global x0
% NB global is used if initial values x0 
% are used to calculate impact probabilities
% rather than x the variable values
for i = 1:3
    for j = 1:3
        A(i,j) = x(i).*x(j)./(x(i)+x(j))/1000;
    end
end
prhs = zeros(3,1);
prhs(1) = -x(1).*(A(1,2).*x(2)+A(1,3).*x(3));
prhs(2) = 0.5*A(1,1)*x(1).*x(1)-x(2).*(A(2,2).*x(2)+A(2,3).*x(3));
prhs(3) = 0.5*A(1,2)*x(1).*x(2);
end