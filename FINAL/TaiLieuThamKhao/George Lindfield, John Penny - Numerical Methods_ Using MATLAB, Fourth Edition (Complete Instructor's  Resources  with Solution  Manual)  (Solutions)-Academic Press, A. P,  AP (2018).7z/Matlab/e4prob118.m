% e4prob118
% Solution of Problem 1.18
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

a = 3; b = 4; c = 2;
[rt1,rt2] = e4prob118f(a,b,c);
disp(['Case 1: ' num2str(a) '  ' num2str(b) '  ' num2str(c) '  ' num2str(rt1) '  ' num2str(rt2)])

a = 3; b = -6; c = 2;
[rt1,rt2] = e4prob118f(a,b,c);
disp(['Case 2: ' num2str(a) '  ' num2str(b) '  ' num2str(c) '  ' num2str(rt1) '  ' num2str(rt2)])

a = 0; b = -6; c = 2;
[rt1,rt2] = e4prob118f(a,b,c);
disp(['Case 3: ' num2str(a) '  ' num2str(b) '  ' num2str(c) '  ' num2str(rt1) '  ' num2str(rt2)])

a = 0; b = 6; c = 2;
[rt1,rt2] = e4prob118f(a,b,c);
disp(['Case 4: ' num2str(a) '  ' num2str(b) '  ' num2str(c) '  ' num2str(rt1) '  ' num2str(rt2)])

a = 2; b = -6; c = 0;
[rt1,rt2] = e4prob118f(a,b,c);
disp(['Case 5: ' num2str(a) '  ' num2str(b) '  ' num2str(c) '  ' num2str(rt1) '  ' num2str(rt2)])
