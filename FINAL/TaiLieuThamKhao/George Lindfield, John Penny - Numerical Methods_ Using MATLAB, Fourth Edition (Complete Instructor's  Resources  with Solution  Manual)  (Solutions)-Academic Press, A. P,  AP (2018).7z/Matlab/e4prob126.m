% e4prob126
% Solution of Problem 1.26
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
P1 = [zeros(2)   eye(2);    eye(2) zeros(2)]
P2 = [zeros(2) i*eye(2); -i*eye(2) zeros(2)] 
P3 = [eye(2) zeros(2); zeros(2) -eye(2)]

Q1 = [zeros(4)  P1; -P1  zeros(4)]	
Q2 = [zeros(4)  P2; -P2  zeros(4)]	
Q3 = [zeros(4)  P3; -P3  zeros(4)]