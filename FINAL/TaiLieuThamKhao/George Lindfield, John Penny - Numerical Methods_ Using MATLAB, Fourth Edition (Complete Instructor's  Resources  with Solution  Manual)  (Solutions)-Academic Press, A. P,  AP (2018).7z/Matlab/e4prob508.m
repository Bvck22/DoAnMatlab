% e4prob508
% Solution of Problem 5.8
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
s = 10;
r = 1;
b = 8;
x0 = -7.69;
y0 = -15.61;
z0 = 90.39;
f = @(t,x) [s*(x(2)-x(1));
           r*x(1)-x(2)-x(1).*x(3);
           x(1).*x(2)-b*x(3)/3];

acc = 0.00005;
options = odeset('RelTol', acc);
[t,x] = ode23(f,[0 8],[x0 y0 z0]', options);
figure(1), plot(t,x)
grid
axis([0 8 -20 100])
xlabel('t')
ylabel('Response')
legend('x','y','z')
figure(2), plot(x(:,1),x(:,2),'ko')
text(x(1,1)+0.5,x(1,2),'t = 0')
grid
axis([-10 5 -20 20]) 
xlabel('x')
ylabel('y')