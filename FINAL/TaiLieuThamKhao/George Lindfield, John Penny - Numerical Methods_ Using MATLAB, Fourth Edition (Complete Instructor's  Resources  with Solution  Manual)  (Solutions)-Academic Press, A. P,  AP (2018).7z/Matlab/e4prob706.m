% e4prob706
% Solution of Problem 7.6
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x = 0:0.25:3;
y = [6.3806 7.1338 9.1662 11.5545 15.6414 22.7371 32.0696 ...
         47.0756 73.1596 111.4684 175.9895 278.5550 446.4441];
xx = 0:.025:3; 

% Case (a)
Xd = [exp(x); exp(2*x); y]; 
[s_sqd R_sqd be] = mregg2(Xd,1);
fprintf('constant : %8.4f\n',be(1))
fprintf('exp(x)   : %8.4f\n',be(2))
fprintf('exp(2x)  : %8.4f\n',be(3))

ye = be(1)+be(2)*exp(xx)+be(3)*exp(2*xx);

figure(1)
plot(x,y,'ko',xx,ye,'r')
xlabel('x'), ylabel('y')
axis([0 3 -100 500])
grid
title('Fitting exponentials')

% Case (b)
Xd = [1./(1+x); 1./(1+x).^2; y];
[s_sqd R_sqd be] = mregg2(Xd,1);
fprintf('\nconstant   : %10.4f\n',be(1))
fprintf('1/(1+x)    : %10.4f\n',be(2))
fprintf('1/(1+x)^2  : %10.4f\n',be(3))

yr = be(1)+be(2)./(1+xx)+be(3)./(1+xx).^2;

figure(2)
plot(x,y,'ko',xx,yr,'r')
xlabel('x'), ylabel('y')
axis([0 3 -100 500])
grid

title('Fitting reciprocals')

% Case (c)
p = polyfit(x,y,3);
fprintf('\nUsing polyfit\n')
fprintf('Constant : %10.4f\n',p(4))
fprintf('Coeff   x: %10.4f\n',p(3))
fprintf('Coeff x^2: %10.4f\n',p(2))
fprintf('Coeff x^3: %10.4f\n',p(1))

yy = polyval(p,xx);

Xd = [x; x.^2; x.^3; y];
[s_sqd R_sqd bp] = mregg2(Xd,1);
fprintf('\nUsing mregg2\n')
fprintf('Constant : %10.4f\n',bp(1))
fprintf('Coeff   x: %10.4f\n',bp(2))
fprintf('Coeff x^2: %10.4f\n',bp(3))
fprintf('Coeff x^3: %10.4f\n',bp(4))

yp = bp(1)+bp(2)*xx+bp(3)*xx.^2+bp(4)*xx.^3;

figure(3)
plot(x,y,'ko',xx,yy,'b',xx,yp,'r--')
xlabel('x'), ylabel('y')
axis([0 3 -100 500])
grid
title('Polynomial fit')
