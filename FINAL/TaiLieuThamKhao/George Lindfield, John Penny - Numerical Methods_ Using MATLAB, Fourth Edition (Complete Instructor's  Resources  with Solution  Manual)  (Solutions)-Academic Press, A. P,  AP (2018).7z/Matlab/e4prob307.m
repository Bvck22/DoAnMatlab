% e4prob307
% Solution of Problem 3.7
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

M = 4.527594e-3;
e = 0.96727464;
func = @(x) x-e*sin(x)-M;
dfunc = @(x) 1-e*cos(x);

[E, iter] = fnewton(func,dfunc,1,0.00005);
fprintf('Using Newton method, E = %7.4f after %2.0f iterations \n',E,iter)

Ep = -1:0.001:1;
plot(Ep,func(Ep))
xlabel('E')
ylabel('f(E)')
title('Plot of f(x) = x-e sin(x)-M')
axis([-1 1 -0.1 0.1])
grid
