% e4prob507
% Solution of Problem 5.7
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
k1 = 2;
k2 = 10;
c = 0.001;
d = 0.002;
s1 = 1;
s2 = 1;
f = @(t,y) [k1*y(1)-c*y(1).*y(2)-s1*y(1);
           (-k2*y(2)+d*y(1).*y(2))-s2*y(2)];
       
[t,y] = ode45(f,[1 6],[5000 100]);
plot(t,y)
xlabel('Time t')
ylabel('Populations')
legend('Population P', 'Population Q')
fprintf('At t = 6, Pop P = %9.3f \n',y(end,1))
fprintf('At t = 6, Pop Q = %9.3f \n',y(end,2))