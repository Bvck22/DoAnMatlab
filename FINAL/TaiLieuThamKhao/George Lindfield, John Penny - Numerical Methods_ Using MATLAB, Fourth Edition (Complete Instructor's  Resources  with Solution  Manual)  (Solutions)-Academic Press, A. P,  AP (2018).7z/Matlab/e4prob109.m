% e4prob109
% Solution of Problem 1.9
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

x = -2:0.1:2;

y1 = @(x) exp(-x.^2).*cos(20*x);

%This statement allows two graphs with same axes
plot(x,y1(x),'ro-')
%Note use of hold to keep graph
hold on
fplot(y1,[-2,2])
xlabel('x-axis')
ylabel('y1')
grid
title('Problem 1.9 - graph comparing plot and fplot')
legend('plot', 'fplot')