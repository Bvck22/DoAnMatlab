% e4prob413
% Solution of Problem 4.13
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

func = @(x) sin(x);
 for k = [0 4 100]
     int0 = filon(func,1,k,0,pi,64);
     exactval = 2./(1-k.*k);
     fprintf('k = %1.0f: estimate = %12.4e\n',k,int0)
     fprintf('k = %1.0f: exact    = %12.4e\n',k,exactval)
     fprintf('\n')
 end
 
xp = 0:0.001:pi;
plot(xp,sin(xp),xp,sin(xp).*cos(4*xp),xp,sin(xp).*cos(100*xp))
xlabel('x')
ylabel('f(x)')
axis([0 pi -1.5 1.5])
legend('k = 0', 'k = 4', 'k = 100')
 