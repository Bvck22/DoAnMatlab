% e4prob434
% Solution of Problem 4.34
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
alpha = 1.556362e-4; g = 9.81;
x0 = 0.287986;
x = x0:0.2:5.2;

beta = 11.2988350; 
kx = exp(-beta+alpha*x);
k0 =  exp(-beta);
ei0 = real(-expint(-2*k0/alpha));
ei = real(-expint(-2*kx./alpha));
f = 2*g./(alpha*exp(2*kx/alpha));
v_sqd = f.*(ei-ei0);
v1 = sqrt(v_sqd);

beta = 3.25;
kx = exp(-beta+alpha*x);
k0 =  exp(-beta);
ei0 = real(-expint(-2*k0/alpha));
ei = real(-expint(-2*kx./alpha));
f = 2*g./(alpha*exp(2*kx/alpha));
v_sqd = f.*(ei-ei0);
v2 = sqrt(v_sqd);

v0 = sqrt(2*g*x);
plot(x,v1,'ob',x,v2,'+k',x,v0,'r')
xlabel('x'), ylabel('Velocity')
axis([0 5.5 2 12])
legend('\beta = 11.30','\beta = 3.25','v = \surd(2gx)')
