% e4prob415
% Solution of Problem 4.15
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f = @(x) exp(-x)./(x+100);
int1 = galag(f,8);
fprintf('Using Gauss-Laguerre: I = %15.7e\n',int1)
fprintf('               Exact: I = %15.7e\n',103/10402)