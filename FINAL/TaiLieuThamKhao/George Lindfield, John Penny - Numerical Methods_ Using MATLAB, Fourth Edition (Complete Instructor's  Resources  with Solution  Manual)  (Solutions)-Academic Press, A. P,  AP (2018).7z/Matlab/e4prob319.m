% e4prob319
% Solution of Problem 3.19
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

close all
clear all

func = @(x) x.^1.4-sqrt(x)+1./x-100;
disp('Prob 3.2')
disp('Select f(x) = 0 on graph')
figure(1)
plotapp(func,20,0.01,30);

func = @(x) abs(x.^3)+x-6;
disp('Prob 3.3, low')
disp('Select f(x) = 0 on graph')
figure(2)
plotapp(func,-3,0.001,-1);

disp('Prob 3.3, high')
disp('Select f(x) = 0 on graph')
figure(3)
plotapp(func,1,0.001,2);

e = 0.96727464;
M = 4.527594e-3;
func = @(E) E-e*sin(E)-M;
disp('Prob 3.7')
disp('Select f(x) = 0 on graph')
figure(4)
plotapp(func,0,0.0001,0.25);