% e4prob430
% Solution of Problem 4.30
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
m = 50;
n = 100;
f = @(x,y) (1-cos(m*x).*cos(n*y))./(2-cos(x)-cos(y));

R = dblquad(f,0.0001,pi,0.0001,pi); 
R = R/pi^2;
R1 = simp2v(f,0.0001,pi,0.0001,pi,64);
R1 = R1/pi^2;
gamma = -psi(1);
R2 = (gamma+3*log(2)/2+log(50^2+100^2)/2)/pi;
fprintf('Value of integral using dblquad = %6.5f\n',R)
fprintf('Value of integral using  simp2v = %6.5f\n',R1)
fprintf('Value of integral from formula  = %6.5f\n',R2)