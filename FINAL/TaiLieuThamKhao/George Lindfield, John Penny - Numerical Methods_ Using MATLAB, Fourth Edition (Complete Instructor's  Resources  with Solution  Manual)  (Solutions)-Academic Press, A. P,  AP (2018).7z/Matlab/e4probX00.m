 % e4probX00
% Solution of all Problems of Chapter 10 from 10.01 to 10.31
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB 4e' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
disp('Collected answers for chapter 10')

problem = input('Enter problem number, e.g. 10.07  ');
echo off
switch problem
    case 10.01
        echo on
        syms x a b c
     	collect((x-1/a-1/b)*(x-1/b-1/c)*(x-1/c-1/a))
      	echo off
  	case 10.02
      	echo on
       	syms x
      	y = x^4+4*x^3-17*x^2+27*x-19; z = x^2+12*x-13;
        horner(z*y)
     	echo off
	case 10.03
     	echo on
     	syms x y
        % For Part (i)
      	expand(tan(4*x))
        % For Part (ii)
    	expand(cos(x+y))
        % For Part (iii)
      	expand(cos(3*x))
        % For Part  (iv)
      	expand(cos(6*x))
      	echo off
    case 10.04
     	echo on
    	syms x y z
     	expand(cos(x+y+z))
        echo off
	case 10.05
      	echo on
      	syms x
        % For Part (i)
       	taylor(asin(x),'Order',9)
        % For Part (ii)
     	taylor(acos(x),'Order',8)
        % For Part (iii)
     	taylor(atan(x),'Order',8)
    	echo off
 	case 10.06
      	echo on
     	syms x
       	taylor(log(cos(x)),'Order',13)
       	echo off
	case 10.07
      	echo on
       	syms r n
      	solution = symsum((r+3)/(r*(r+1)*(r+2))*(1/3)^r,1,n)
     	echo off
	case 10.08    
     	echo on
    	syms k
       	symsum(k^10,1,100)
       	echo off
 	case 10.09   
       	echo on
     	syms k
     	symsum(k^-4,1,inf)
      	echo off
   	case 10.10
       	echo on
    	syms a b c
        a = [1 a a^2;1 b b^2;1 c c^2]; 
       	p = simplify(inv(a))
       	echo off
  	case 10.11
      	echo on
      	syms a1 a2 a3 a4 lam
       	a = [a1 a2 a3 a4;1 0 0 0;0 1 0 0;0 0 1 0];
      	ev = a-lam*eye(4) 
       	det(ev)
       	echo off
 	case 10.12
       	echo on
       	syms a1
       	trans = [cos(a1) sin(a1);-sin(a1) cos(a1)];
      	[solution] = simplify(trans^2)
      	[solution] = simplify(trans^4)
     	echo off
   	case 10.13
      	echo on
      	syms x h g
        eqn = x^3+3*h*x+g == 0
       	[r sigma] = subexpr(solve(eqn,x,'maxdegree',3))
        echo off
 	case 10.14
      	echo on
       	syms x
       	solve(x^3-9*x+28==0)
      	echo off
   	case 10.15
     	echo on
     	syms z p
      	p = solve(z^6==4*sqrt(2)+i*4*sqrt(2));
       	res = double(p)
        r = abs(res); theta = angle(res);
        figure(1)
        plot(real(res),imag(res),'*r')
        xlabel('RPO(root)')
        ylabel('IPO(root)')
        figure(2)
        polarplot(theta,r,'*r')
       	echo off
	case 10.16
    	echo on
        syms x
      	f = log((1-x)*(1+x^3)/(1+x^2)); 
       	p = diff(f)
       	p = collect(p)
        pretty(p)
       	echo off
	case 10.17
      	echo on
        syms x y
        % For Part (i)
      	f = log(x^2+y^2);
      	d2x = diff(f,x,2)
      	d2y = diff(f,y,2)
      	r1 = collect(d2x+d2y)
        % For Part (ii)
      	f1 = exp(-2*y)*cos(2*x);
        ddx = diff(f1,x,2)
        ddy = diff(f1,y,2)
       	r2 = collect(ddx+ddy)
       	echo off
  	case 10.18
      	echo on
       	syms x y
       	z = x^3*sin(y);
       	dxy1 = diff(diff(z,'y'),'x')
       	dyx2 = diff(diff(z,'x'),'y')
       	dxy3 = diff(diff(z,'x',4),'y',6)
      	dxy4 = diff(diff(z,'y',6),'x',4)
       	echo off
 	case 10.19
       	echo on
       	syms a f c g x
        % For Part (i)
      	p = int(1/((a+f*x)*(c+g*x)))
        pd0 = diff(p)
        pd1 = collect(pd0)
     	pd2 = simplify(pd0)
        % For Part (ii)
        q = int((1-x^2)/(1+x^2))
        qd0 = diff(q)
        qd1 = collect(qd0)
        qd2 = simplify(qd0)
        echo off
	case 10.20
        echo on
       	syms a x
        % For Part (i)
      	int(1/(1+cos(x)+sin(x)))
        % For Part (ii)
        int(1/(a^4+x^4))
      	echo off
  	case 10.21 
       	echo on
     	syms x
    	int(x^3/(exp(x)-1),0,inf)
      	echo off
  	case 10.22 
      	echo on
    	syms x
        % For Part (i)
      	int(1/(1+x^6),0,inf)
        % For Part (ii)
      	int(1/(1+x^10),0,inf)
       	echo off
  	case 10.23
       	echo on
       	syms x
        d = int(exp(-x*x),0,1);
        exact = vpa(d,10)
      	t = taylor(exp(-x*x),x,0,'Order',7)
      	p = int(t,0,1); vpa(p,10)
        error = vpa((p-exact),10)
        
       	t = taylor(exp(-x*x),x,0,'Order',15)
      	p = int(t,0,1); vpa(p,10)
        error = vpa((p-exact),10)  
     	echo off
	case 10.24
     	echo on
       	syms x
      	int(sin(x^2)/x,0,inf)
      	echo off
   	case 10.25
       	echo on
       	syms x
        d = int(log(1+cos(x)),0,1);
        exact = vpa(d,10)
        %exact = 0.6076250333;
      	t = taylor(log(1+cos(x)))
       	p = int(t,0,1)
        error = vpa((p-exact),10)
      	echo off
	case 10.26
       	echo on
       	syms x y
       	f = 1/(1-x*y)
    	int(int(f,x,0,1),y,0,1)
      	echo off
  	case 10.27
       	echo on
       	syms p q a b c A
      	[solution,s] = ...
        	subexpr(dsolve('D2y+(b*p+a*q)*Dy+a*b*(p*q-1)*y = c*A ' ...
            	, 'y(0)=0', 'Dy(0)=0','t'),'s')
        
    	result = subs(solution,{p,q,a,b,c,A},{1,2,2,1,1,20})
        s_value = subs(s,{p,q,a,b,c},{1,2,2,1,1})
        
      	echo off
	case 10.28
      	echo on
      	syms x t
    	sol = dsolve('2*Dx+4*Dy=cos(t),4*Dx-3*Dy=sin(t)','t')
       	disp('To see the specific elements of the solution use')
       	simplify(sol.x)
       	simplify(sol.y)
      	echo off
  	case 10.29
       	echo on
        syms x y(t)
       	solution = dsolve('(1-x^2)*D2y-2*x*Dy+2*y=0','x')
      	echo off
  	case 10.30
       	echo on
       	syms t Y s V c
       	% For Part (i)
       	laplace(cos(2*t))
       	p = solve(s^2*Y+2*s+2*Y==s/(s^2+4),Y);
        ilaplace(p)
        
      	% For Part (ii)
        laplace(t)
      	p = solve(s*Y-2*Y==1/s^2,Y);
    	ilaplace(p)
        
      	% For Part (iii)
       	laplace(exp(-2*t))
       	p = solve(s^2*Y+3*s-3*(s*Y+3)+Y==1/(s+2),Y);
       	ilaplace(p)
        
        % For Part (iv)
     	p = solve((s*Y-V)+Y/c==0,Y);
     	ilaplace(p)
       	echo off
	case 10.31
        echo on
      	syms n p Y z
        % For Part (i)
      	p = solve(Y==-2*(Y/z+4),Y)
       	iztrans(p)
       	% For Part (ii)
       	ztrans(n)
        p = solve(Y+(Y/z+10)==z/(z-1)^2,Y);
       	iztrans(p)
      	% For Part (iii)
     	ztrans(3*heaviside(n))
       	p = solve(Y-2*(Y/z+1)==3*z/(z-1),Y);
      	iztrans(p)
        % For Part (iv)
      	ztrans(3*4^n)
      	p = solve(Y-3*(Y/z-3)+2*(Y/z^2+5-3/z)==3*z/(z-4),Y);
      	iztrans(p)
        echo off
    case 10.32
        %echo on
        syms k      
        for tms = 2:10
            t = 12*symsum((-1)^k*factorial(6*k)*(13591409+545140134*k)/(factorial(3*k)*factorial(k)^3*(640320)^(3*k+3/2)),0,tms-1);
            pi_est = vpa((1/t),200);
            pi_ext = vpa(pi,200);
            err = pi_est-pi_ext;
            e(tms) = abs(err);
        end
        figure(3)
        plot(2:10,abs(log10(e(2:10))),'o-')
        xlabel('Number of terms in summation')
        ylabel('Log10(error) = number of DP achieved')
        grid
        %echo off
    otherwise
        disp('Problem not in list')
end
        


