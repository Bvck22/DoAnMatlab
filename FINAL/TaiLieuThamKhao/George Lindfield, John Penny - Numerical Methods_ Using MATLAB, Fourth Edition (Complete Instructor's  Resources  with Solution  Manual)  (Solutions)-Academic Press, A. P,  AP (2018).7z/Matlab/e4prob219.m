% e4prob219
% Solution of Problem 2.19
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A1 = [0.2 0.3 0;0.3 0.2 0.3;0 0.3 0.2];
eigA1 = eig(A1)

IA1m = inv(eye(3)-A1);
for k = [4 8 16]
    IA1a = invapprox(A1,k);
    fprintf('k = %2.0f: norm(IA1m-IA1a) = %8.4f\n',k,norm(IA1m-IA1a))
end

A2 = [1.0 0.3 0;0.3 1.0 0.3;0 0.3 1.0];
eigA2 = eig(A2)
IA2m = inv(eye(3)-A2);
for k = [4 8 16]
    IA2a = invapprox(A2,k);
end
     


   