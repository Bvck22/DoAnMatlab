% e4prob137
% Solution of Problem 1.37
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
x = 0:0.1:10;
y = fex(x);
plot(x,y)
title('y = x^2sin(x^2)')
xlabel('x value'), ylabel('y(x)')
grid

display('r = (xmax-xmin)/(xmax+xmin)')
r = functiontest(y)

%------------------------------
function [r] = functiontest(x)
%function for min and max 1.37
xmax = max(x);
xmin = min(x);
r = (xmax-xmin)/(xmax+xmin);
end

function [y] = fex(x)
%problem 1.37 function here
y = x.^2 .*sin(x.^2);
end

