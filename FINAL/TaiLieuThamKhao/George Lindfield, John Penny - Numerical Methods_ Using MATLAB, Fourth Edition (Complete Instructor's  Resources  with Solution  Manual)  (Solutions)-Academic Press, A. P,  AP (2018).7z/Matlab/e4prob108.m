% e4prob108
% Solution of Problem 1.8
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x = -4:0.02:4;
y1 = cos(x);
y2 = cos(x.^3);

%This statement allows two graphs with same axes
figure(1), plot(x,y1,x,y2)
xlabel('x-axis')
ylabel('cos(x) and cos(x^3)')
title('Problem 1.8 - Graphs')
grid
legend('cos(x) function','cos(x^3) function')

x = -4:0.002:4;
y1 = cos(x);
y2 = cos(x.^3);
% This is a much higher resolution plot
figure(2), plot(x,y1,x,y2)
xlabel('x-axis')
ylabel('cos(x) and cos(x^3)')
title('Problem 1.8 - Graphs')
grid
legend('cos(x) function','cos(x^3) function')