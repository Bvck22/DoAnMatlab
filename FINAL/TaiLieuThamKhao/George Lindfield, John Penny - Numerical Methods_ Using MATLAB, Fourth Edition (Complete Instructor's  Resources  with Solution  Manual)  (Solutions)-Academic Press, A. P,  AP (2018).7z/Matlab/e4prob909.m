% e4prob909
% Solution of Problem 9.9
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
f = @(x) exp(-x).*cos(3*x);

x0 = fminsearch(f,0);  f0 = f(x0);
[f1,x1] = golden(f,[0,4],0.000001);

fprintf('From fminsearch, x = %6.4f, f = %6.4f\n',x0,f0)
fprintf('From golden,     x = %6.4f, f = %6.4f\n',x1,f1) 
 
fplot(f,[0,4])
xlabel('x'), ylabel('f(x)')
title('f(x) = exp(-x)*cos(3*x)')
axis([0 4 -0.5 1])
grid