function res = sumfac2(n)
% res is the sum of the series 1+2^2/2!+3^2/3!+ ... to n terms. 

% Solution of Problem 1.24
%
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

term = 1;
sum = term;
for k = 1:n-1
    term = term*(k+1)/k^2;
    sum = sum+term;
end
res = sum;