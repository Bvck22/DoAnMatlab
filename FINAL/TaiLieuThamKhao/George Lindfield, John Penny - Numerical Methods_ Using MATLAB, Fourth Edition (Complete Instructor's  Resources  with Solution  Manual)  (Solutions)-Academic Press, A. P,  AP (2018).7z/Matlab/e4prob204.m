% e4prob204
% Solution of Problem 2.4
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [2 3 6;2 3 -4;6 11 4];
[n,n] = size(A);
x = zeros(n,n);
lambda = eig(A);
for j = 1:n
    disp(['Lambda = ' num2str(lambda(j))])
    disp('RREF')
    P = rref(A-lambda(j)*eye(n));
    disp(P)
    x(3,j) = 1;
    x(2,j) = -P(2,3)*x(3,j);
    x(1,j) = -P(1,2)*x(2,j)-P(1,3)*x(3,j);
end

disp('eigenvectors from RREF') 
disp(x)

[v,l] = eig(A);
for k = 1:3
    v(:,k) = v(:,k)/v(3,k);
end
disp('eigenvectors from evp')
disp(v)