% e4prob911
% Solution of Problem 9.11
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
f = @(x) (2*x(1)-sin((x(1)+x(2))/2)).^2+(2*x(2)-cos((x(1)-x(2))/2)).^2;

pdf = @(x) [2*(2*x(1)-sin((x(1)+x(2))/2))*(2-0.5*cos((x(1)+x(2))/2))+2*(2*x(2)-cos((x(1)-x(2))/2))*0.5*sin((x(1)-x(2))/2);
      2*(2*x(1)-sin((x(1)+x(2))/2))*0.5*(-cos((x(1)+x(2))/2))+2*(2*x(2)-cos((x(1)-x(2))/2))*(2-0.5*sin((x(1)-x(2))/2))];
    
sol = fminsearch( f,[10,-10]);
r = minscg(f,pdf,[10 -10]',.00005);
fprintf('Using fminsearch, min(f) = %11.4e at x = [%6.4f %6.4f]\n',f(sol),sol)
fprintf('Using minscg,     min(f) = %11.4e at x = [%6.4f %6.4f]\n\n',f(r),r.')

g = @(x) abs(2*x(1)-sin((x(1)+x(2))/2))+abs(2*x(2)-cos((x(1)-x(2))/2));
sol1 = fminsearch( g,[10,-10]);
fprintf('Using fminsearch, abs function, min(f) = %11.4e at x = [%6.4f %6.4f]\n',f(sol1),sol1)

[X Y] = meshgrid(-5:0.1:5,-5:0.1:5);
Z = (2*X-sin((X+Y)/2)).^2+(2*Y-cos((X-Y)/2)).^2;

figure(1)
surf(X,Y,Z)
xlabel('x')
ylabel('y')
zlabel('z = f(x,y)')
title('z = (2*x-sin((x+y)/2))^2+(2*y-cos((x-y)/2))^2')
  
figure(2)
contour(X,Y,Z,50)
grid
xlabel('x')
ylabel('y')
zlabel('z = f(x,y)')
title('z = (2*x-sin((x+y)/2))^2+(2*y-cos((x-y)/2))^2')

[X Y] = meshgrid(-5:0.1:5,-5:0.1:5);
Z = abs(2*X-sin((X+Y)/2))+abs(2*Y-cos((X-Y)/2));

figure(3)
surf(X,Y,Z)
xlabel('x')
ylabel('y')
zlabel('z = f(x,y)')
title('z = abs(2*x-sin((x+y)/2))+abs(2*y-cos((x-y)/2))')
  
figure(4)
contour(X,Y,Z,30)
grid
xlabel('x')
ylabel('y')
zlabel('z = f(x,y)')
title('z = abs(2*x-sin((x+y)/2))+abs(2*y-cos((x-y)/2))')
