% e4prob510
% Solution of Problem 5.10
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
K = 10000;
r = 0.1;
f  =@(t,y) r*y*(1-y/K);

[t,y] = ode23(f,[0 200],100);
plot(t,y)
xlabel('Time')
ylabel('Population')
fprintf('At t = 200, Population = %6.0f \n',y(end))
