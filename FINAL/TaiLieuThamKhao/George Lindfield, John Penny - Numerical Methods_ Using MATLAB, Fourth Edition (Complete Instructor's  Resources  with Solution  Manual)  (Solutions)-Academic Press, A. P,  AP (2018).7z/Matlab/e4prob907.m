% e4prob907
% Solution of Problem 9.7
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
[x,y] = meshgrid(-2:0.05:2,-2:0.05:2);
z = (1./((x-1).^2+2)+1./((y-1).^2+2));
figure(1), surf(x,y,z)
xlabel('x'), ylabel('y'), title('Function to be maximized')
zlabel('f(x,y)')
figure(2), contour(x,y,z,30)
hold on
plot(1,1,'+k')
hold off
grid
xlabel('x'), ylabel('y'), title('Function to be maximized (Maximum indicated by +)')

f = @(x)  -(1./((x(1)-1).^2+2)+1./((x(2)-1).^2+2));

[f0,x0] = diffevo(f, 2, [-2 -2]', [2 2]', 0.85, 0.5, 20, 200);
fe(1) = f0;
for k = 2:30
    [fa,xa] = diffevo(f, 2, [-2 -2]', [2 2]', 0.85, 0.5, 20, 200);
    fe(k) = fa;
    if fa>f0
        f0 = fa; 
        x0 = xa;
    end
end

fprintf('Best estimate of min(-f) = %6.4f at x = [%6.4f %6.4f]\n',f0,[x0])
fprintf('Best estimate of max(f)  = %7.4f at x = [%6.4f %6.4f]\n',-f0,[x0])
