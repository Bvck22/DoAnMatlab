% e4prob901
% Solution of Problem 9.1
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

A = [1 1 1 -1 0;1 2 4 0 -1];
b = [4; 5];
c = [5 7 10 0 0];
[xsol,indices,object] = barnes(A,b,c,0.00005);

x0 = zeros(length(c),1);
for k = 1:length(xsol)
    x0(indices(k)) = xsol(k);
end

for k = 1:length(c)
    fprintf('x(%1.0f)   = %8.4f \n',k,x0(k))
end
fprintf('\nmax(z) = %8.4f \n\n', object)

