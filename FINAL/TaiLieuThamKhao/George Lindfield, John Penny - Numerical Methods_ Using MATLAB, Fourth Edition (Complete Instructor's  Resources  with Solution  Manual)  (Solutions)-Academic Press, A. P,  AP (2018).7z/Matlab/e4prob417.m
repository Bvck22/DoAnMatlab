% e4prob417
% Solution of Problem 4.17
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f = @(x) exp(-x.^2).*cos(x);
int0 = gaherm(f,16);
fprintf('Using Gauss-Hermite: I = %12.10f\n',int0)
fprintf('              Exact: I = %12.10f\n',sqrt(pi)*exp(-1/4))