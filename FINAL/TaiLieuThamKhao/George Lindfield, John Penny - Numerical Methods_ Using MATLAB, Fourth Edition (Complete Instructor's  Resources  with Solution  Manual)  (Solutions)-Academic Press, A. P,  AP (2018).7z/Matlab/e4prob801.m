% e4prob801
% Solution of Problem 8.01
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

close all
clear all

y = [2 -0.404 0.2346 2.6687 -1.4142 -1.0973 0.8478 -2.37 0 ...
 2.37 -0.8478 1.0973 1.4142 -2.6687 -0.2346 0.404 -2 ...
 1.8182 1.7654 -1.2545 1.4142 -0.3169 -2.8478 0.9558 ...
 0 -0.9558 2.8478 0.3169 -1.4142 1.2545 -1.7654 -1.8182];

n = 32; 
dt = 0.1; 
T = n*dt;
df = 1/T;
fprintf('Frequency increment = %6.4f Hz \n\n',df)
f = 0:df:(n-1)*df;  
Y = fft(y);
disp('  index   frequency       real(DFT)   imag(DFT)')
for k = 1:n
    fprintf('%6.0f %11.4f %12.1f %12.1f \n',k-1, f(k), real(Y(k)), imag(Y(k)))
end
