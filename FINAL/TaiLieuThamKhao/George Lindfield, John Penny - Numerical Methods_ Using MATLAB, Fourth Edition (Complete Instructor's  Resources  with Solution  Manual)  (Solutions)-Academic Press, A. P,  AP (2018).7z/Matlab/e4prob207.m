% e4prob207
% Solution of Problem 2.7
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

n = 5;
for i = 1:n
    for j = 1:n
        if i==j
            C(i,j) = i*(n-i+1);
        elseif j>i
            C(i,j) = C(i,j-1)-i;
        else
            C(i,j) = C(j,i);
        end
    end
end
b = 1:n;
b = b';
E = C/(n+1);
x1 = E\b;
[L,U,P] = lu(E);
y = L\b;
x2 = U\y;

 fprintf('   using backslash      using lu\n')
 for k = 1:n
     fprintf('%13.4f %17.4f\n',x1(k), x2(k))
 end
    

