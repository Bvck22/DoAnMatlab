% e4prob435
% Solution of Problem 4.35
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

% See also Problem 1.39.

clear all
close all

% Relationship given by Jolly p184, equation (1004)
% Integration of exp(-sin(2*x)).*cos(x) by Filon's method; 

f = @(x) exp(-sin(2*x));

Integ = filon(f,1,1,0,pi/2,32);
fprintf('Filon estimate  = %2.10f\n',Integ)

s = 0;
for i = 1:10
    s = s + 1/((2*i-1)*factorial(i-1));
end

s = s/exp(1);
fprintf('Series estimate = %2.10f\n',s)
next_term = 1/((21)*factorial(10))/exp(1);
fprintf('Next term       = %2.10f\n',next_term)

s_exact =  0.538079506912768;
fprintf('Exact value     = %2.10f\n',s_exact)

    