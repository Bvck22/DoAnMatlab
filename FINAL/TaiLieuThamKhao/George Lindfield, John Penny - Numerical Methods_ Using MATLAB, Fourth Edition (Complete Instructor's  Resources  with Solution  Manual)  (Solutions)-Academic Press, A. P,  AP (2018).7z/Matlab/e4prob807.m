% e4prob807
% Solution of Problem 8.07
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

close all
clear all
T = 8; n = 32; dt = T/n;
t_rng = dt:dt:T;

ds = 2/T; 
s_cal = [0:(n/2-1)]*ds;  s_sal = [0:n/2]*ds; s_pwr = s_sal;
s_max = n/2;

p = [1 1 -1 -1]; 
x1 = [p p p p p p p p];
x2 = [1 -1 -1 p p p p p p p 1];
% x2 = [-1 -1 p p p p p p p 1 1];
figure(1), plot(t_rng,x2,'k-o',t_rng,0.8*x1,'r-*')
axis([0 8 -1.2 1.2])
ylabel('Signal'), xlabel('Time [s]')
legend('Waveform, part a', 'Waveform, part b')
title('Sampled time series')
grid

% Part (a)
wal_x1 = dwht(x1,1);
[CAL1, SAL1, PWR1] = walshps(wal_x1);

figure(2), 
subplot( 2,1,1)
bar(s_cal,CAL1)
axis([0 4 -1.2 1.2])
grid
ylabel('CAL(x_1)'), xlabel('Sequency [z/s]')
title('Part a: CAL spectrum')

subplot( 2,1,2)
bar(s_sal,SAL1)
grid
axis([0 4 0 35])
ylabel('SAL(x_1)'), xlabel('Sequency [z/s]')
title('Part a: SAL spectrum')

figure(3), bar(s_pwr,PWR1)
axis([0 4 0 1200])
grid
ylabel('Power(x_1)'), xlabel('Sequency [z/s]')
title('Part a: Walsh power spectrum')

wal_x2 = dwht(x2,1);
[CAL2, SAL2, PWR2]= walshps(wal_x2);

figure(4), 
subplot(2,1,1)
bar(s_cal,CAL2)
axis([0 4 0 35])
grid
ylabel('CAL(x_2)'), xlabel('Sequency [z/s]')
title('Part b: CAL spectrum')

subplot(2,1,2)
bar(s_sal,SAL2)
axis([0 4 -1.2 1.2])
grid
ylabel('SAL(x_2)'), xlabel('Sequency [z/s]')
title('Part b: SAL spectrum')

figure(5), bar(s_pwr,PWR2)
axis([0 4 0 1200])
grid
ylabel('Power(x_2)'), xlabel('Sequency [z/s]')
title('Part b: Walsh power spectrum')

