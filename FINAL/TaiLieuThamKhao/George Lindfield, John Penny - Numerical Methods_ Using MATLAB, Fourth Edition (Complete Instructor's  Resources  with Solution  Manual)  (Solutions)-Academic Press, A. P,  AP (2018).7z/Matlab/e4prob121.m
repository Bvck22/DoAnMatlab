% e4prob121
% Solution of Problem 1.21
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

z = @(x,y) (1-x.^2).*exp(-(x.^2+y.^2))- ...
             (x.^2+y.^2).*exp(-(x.^2+y.^2))-exp(-(x+1).^2-y.^2);
         
[x,y] = meshgrid(-4:0.1:4,-4:0.1:4);
figure(1)
subplot(3,1,1), mesh(x,y,z(x,y))
xlabel('-x-')
ylabel('-y-')
zlabel('f(x,y)')
title('Mesh plot')
subplot(3,1,2), surf(x,y,z(x,y))
xlabel('-x-')
ylabel('-y-')
zlabel('f(x,y)')
title('Surf plot')
subplot(3,1,3), contour(x,y,z(x,y))
xlabel('-x-')
ylabel('-y-')
title('Contour plot')