% e4prob419
% Solution of Problem 4.19
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

f1 = @(x,z) exp(((sqrt(x/3)-1).*z+1).^3).*(sqrt(x/3)-1);
q1 = simp2v(f1,0,3,0,1,64);
fprintf('Part (a): estimate = %10.5f\n',q1)

f2 = @(x,z) (1+x+(2-x).*z).^(-3).*(2-x);
q2 = simp2v(f2,0,2,0,1,64);
fprintf('Part (b): estimate = %10.5f\n',q2)

figure(1)
[xx,zz] = meshgrid(0:0.1:3,0:.05:1);
surf(xx,zz,f1(xx,zz))
title('f = exp(((sqrt(x/3)-1)z+1)^3)(sqrt(x/3)-1)')
xlabel('x')
ylabel('z')
zlabel('f(x,z)')

figure(2)
[xx,zz] = meshgrid(0:0.05:2,0:.05:1);
surf(xx,zz,f2(xx,zz))
title('f = (1+x+(2-x)z)^{-3}(2-x)')
xlabel('x')
ylabel('z')
zlabel('f(x,z)')
