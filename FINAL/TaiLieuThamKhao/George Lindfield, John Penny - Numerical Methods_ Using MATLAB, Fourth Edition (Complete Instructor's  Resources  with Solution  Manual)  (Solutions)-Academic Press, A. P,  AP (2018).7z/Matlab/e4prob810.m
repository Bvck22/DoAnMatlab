% e4prob810
% Solution of Problem 8.10
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
load sunspot.dat
year = sunspot(:,1);
wolfer = sunspot(:,2);
figure(1)
plot(year,wolfer)
xlabel('Year')
ylabel('Number of Sunspots')
title('Sunspot activity by year')

N = length(wolfer);
Y = fft(wolfer);
power = abs(Y(1:N/2)).^2;
nyquist = 1/2;
freq = (1:N/2)/(N/2)*nyquist;
figure(2), plot(freq,power,'k')
axis([0 0.5 0 2e7])
grid on
ylabel('Power')
xlabel('Frequency (cycles/year)')
title('Periodogram')

period = 1./freq;
figure(3), plot(period,power,'k')
axis([0 40 0 2e7])
grid on
ylabel('Power')
xlabel('Period (years/cycle)')
title('Periodogram')


