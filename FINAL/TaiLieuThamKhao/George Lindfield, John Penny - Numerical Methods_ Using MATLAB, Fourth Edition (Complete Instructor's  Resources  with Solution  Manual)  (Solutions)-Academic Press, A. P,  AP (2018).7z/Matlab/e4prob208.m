% e4prob208
% Solution of Problem 2.8
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

for n = [20 50]
    C = zeros(n,n);
    E = zeros(n,n);
    for m = 1:n
        for j = 1:n
            if m==j
                C(m,j) = m*(n-m+1);
            elseif j>m
                C(m,j) = C(m,j-1)-m;
            else
                C(m,j) = C(j,m);
            end
        end
    end
    E = C/(n+1);
    A = inv(E);
    P = diag(2*ones(n,1))+diag(-ones(n-1,1),-1)+diag(-ones(n-1,1),1);
    nm = norm(A-P);
    fprintf('n = %3.0f, norm(A-P) = %12.5e\n',n,nm)
end
