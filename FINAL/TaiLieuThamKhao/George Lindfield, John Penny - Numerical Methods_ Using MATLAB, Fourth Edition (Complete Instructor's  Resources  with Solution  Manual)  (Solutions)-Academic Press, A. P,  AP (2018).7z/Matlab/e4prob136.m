% e4prob136
% Solution of Problem 1.36
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
x = 2*pi*rand(1,300);
polarhistogram(x,15,'Facecolor','black','FaceAlpha',0.5)
