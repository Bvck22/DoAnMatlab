% e4prob138
% Solution of Problem 1.38
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all
fimplicit(@ (x,y) (x.^2+y.^2-3*x).^2-4*x.^2.*(2-x) ,[0  2  -3  3],'k')
title('Plot of (x^2+y^2- 3*x)^2- 4x^2(2 - x)=0')
xlabel('x'), ylabel('y')