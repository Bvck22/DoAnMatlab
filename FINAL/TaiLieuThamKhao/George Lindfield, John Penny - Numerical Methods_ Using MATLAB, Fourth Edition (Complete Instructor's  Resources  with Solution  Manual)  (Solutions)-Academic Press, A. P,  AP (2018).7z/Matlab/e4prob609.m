% e4prob609
% Solution of Problem 6.9
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

lam = zeros(7,4);
fa = 3;
mode = 1;

Lx = 1.5; Ly = 1.0;
nx = 9; ny = 6; 
hx = Lx/nx;  hy = Ly/ny;
x1 = 0:hx:Lx; y1 = 0:hy:Ly;
G1 = ones(nx+1,ny+1);
G1(4:7,3:5) = fa*ones(4,3);
[A1,om] = ellipgen(nx,hx,ny,hy,G1,mode);
om = sort(om);
disp('Lowest 7 eigenvalues')
figure(1)
surf(x1,y1,-A1)
xlabel('y direction')
ylabel('x direction')
zlabel('Relative deflection')
title('1st Mode. FD Soln based hx = hy =1/6') 
axis([0 1.5 0 1 -1 0])
view(-44,42)
lam(:,1) = om(1:7);

% This completes the requirements of Problem 6.9.
% However, an improved result can be obtained by increasing the
% number of nodes in the FD approximation. THe following code
% halves the spacing between nodes, so that 18, rather than 9 divisons
% are used in x.

nx = 18; 
ny = 12; 
hx = Lx/nx;
hy = Ly/ny;
x2 = 0:hx:Lx; y2 = 0:hy:Ly;
G2 = ones(nx+1,ny+1);
G2(7:13,5:9) = fa*ones(7,5);
[A2,om] = ellipgen(nx,hx,ny,hy,G2,mode);
om = sort(om);
figure(2)
surf(x2,y2,-A2)
xlabel('y direction')
ylabel('x direction')
zlabel('Relative deflection')
title('1st Mode. FD Soln based hx = hy = 1/12')
axis([0 1.5 0 1 -1 0])
view(-44,42)
lam(:,2) = om(1:7);

% Half the spacing between the nodes again, so that 36 divisions, 
% rather than 18 divisons are used in x.

nx = 36; 
ny = 24; 
hx = Lx/nx;
hy = Ly/ny;
x3 = 0:hx:Lx; y3 = 0:hy:Ly;
G3 = ones(nx+1,ny+1);
G3(13:25,9:17) = fa*ones(13,9);
[A3,om] = ellipgen(nx,hx,ny,hy,G3,mode);
om = sort(om);
figure(3)
surf(x3,y3,-A3)
xlabel('y direction')
ylabel('x direction')
zlabel('Relative deflection')
title('1st Mode. FD Soln based hx = hy = 1/24')
axis([0 1.5 0 1 -1 0])
view(-44,42)
lam(:,3) = om(1:7);

% Richardson's extrapolation. 
% This extrapolation technique is identical to 
% Romberg's method for refining integration.

n1 = 1; n2 = 2; n3 = 4;
b1 =  n1^4/((n2^2-n1^2)*(n3^2-n1^2));
b2 = -n2^4/((n2^2-n1^2)*(n3^2-n2^2));
b3 =  n3^4/((n3^2-n1^2)*(n3^2-n2^2));
lam(:,4) = b1*lam(:,1)+b2*lam(:,2)+b3*lam(:,3);

fprintf('      h = 1/6     h = 1/12     h = 1/24  extrapolated\n')
for k = 1:7
    fprintf('%12.4f %12.4f %12.4f %12.4f\n',lam(k,1),lam(k,2),lam(k,3),lam(k,4))
end

L3 = [0:36]/24;
L1 = [0:9]/6;
figure(4)
plot(L1,-A1(4,:),'*-',L3,-A3(13,:),'o-')
legend('h = 1/6','h = 1/24')
axis([0 1.5 -1.1 0])
grid
title('First mode shape for x = 0.5')
xlabel('y axis')
ylabel('Relative deflection')
