% e4prob805
% Solution of Problem 8.05
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

y1 = [0 0.9094 0.4251 -0.6030 -0.6567 0.2247 0.6840 0.1217 ...
     -0.5462 -0.3626 0.3120 0.4655 -0.0575 -0.4373 -0.1537 ...
      0.3137 0.2822 -0.1446 -0.3164 -0.0204 0.2694 0.1439 -0.1702 ...
     -0.2065 0.0536 0.2071 0.0496 -0.1594 -0.1182 0.0853 0.1441 -0.0078];
n = 32; 
T = 0.0625; 
dt = T/n;
df = 1/T;
fprintf('Frequency increment = %4.2f Hz \n',df)
Y1 = fft(y1); 
nt = length(y1); 
f = 0:df:(nt/2-1)*df;
nt0 = nt;

figure(1), 
plot(f,(2/nt)*abs(Y1(1:nt/2)),'-ko')
xlabel('frequency Hz'); 
ylabel('abs(DFT)')
title('32 point DFT')
axis([0 255 0 0.5])
grid

y2 = [y1 zeros(size(y1))]; T = 2*T; % 64 points
y3 = [y2 zeros(size(y2))]; T = 2*T; % 128 pts
y4 = [y3 zeros(size(y3))]; T = 2*T; % 256 pts
y5 = [y4 zeros(size(y4))]; T = 2*T; % 512 pts

df = 1/T;
fprintf('Frequency increment = %4.2f Hz \n',df)
Y5 = fft(y5); 
nt = length(y5); 
f = 0:df:(nt/2-1)*df; 

figure(2)
plot(f,(2/nt0)*abs(Y5(1:nt/2)),'-ko')
xlabel('frequency Hz'); 
ylabel('abs(DFT)')
title('512 point DFT')
axis([0 255 0 0.5])
grid

y6 = [y5 zeros(size(y5))]; T = 2*T; %1024 pts
df = 1/T;
fprintf('Frequency increment = %4.2f Hz \n',df)
Y6 = fft(y6); 
nt = length(y6); 
f= 0:df:(nt/2-1)*df; 

figure(3)
plot(f,(2/nt0)*abs(Y6(1:nt/2)),'-ko')
xlabel('frequency Hz'); 
ylabel('abs(DFT)')
title('1024 point DFT')
axis([0 255 0 0.5])
grid





