% e4prob809
% Solution of Problem 8.09
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

close all
clear all
T = 5.12; n = 64; dt = T/n;
t_rng = dt:dt:T;
dz = 2/T; zmax = (n-1)/T; z_rng = 0:dz:zmax;

% Part (a)
p = [1 1 1 1 -1 -1 -1 -1];
x1 = [p p p p p p p p];
x1 = x1+0.5*ones(size(x1))+0.01*randn(size(x1));

figure(1)
subplot(2,1,1)
plot(t_rng,x1)
xlabel('time'), ylabel('x(t)')
title('Part a: Time series data')
axis([0 5.12 -1 2])
grid

df = 1/T; f_max = df*n/2; f_rng = [0:n/2-1]*df;
fou_x1 = fft(x1);
fou_pwr1 = fou_x1.*conj(fou_x1);
subplot(2,1,2)
bar(f_rng,fou_pwr1(1:n/2))
xlabel('Frequency Hz'), ylabel('Amplitude')
axis([0 f_max 0 1800])
grid, title('Part a: Fourier power spectrum')


z1 = fasthaar(x1);
Cg = waveletmap(t_rng,z1,1,20,2,3);
figure(2),title('Part a: Wavelet map')

fprintf('Relating wavelet levels to frequency, Hz\n\n')
fprintf('Pt a: level %3.0f,%8.0f,%8.0f,%8.0f,%8.0f,%8.0f\n', 0:5)
fprintf('  frequency %8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f [Hz]\n\n', (1/T)*2.^[0:5])


% Part (b)
p = [1 1 1 1 -1 -1 -1 -1]; p1 = [1 1 -1 -1];
x2 = [p p p1 p1 p1 p1 p p p p];
figure(3), 
subplot(2,1,1)
plot(t_rng,x2)
xlabel('time'), ylabel('x(t)')
title('Part b: Time series data')
axis([0 5.12 -1.2 1.2])
grid

fou_x2 = fft(x2);
fou_pwr2 = fou_x2.*conj(fou_x2);
subplot(2,1,2)
bar(f_rng,fou_pwr2(1:n/2))
xlabel('Frequency Hz'), ylabel('Amplitude')
axis([0 f_max 0 1000])
grid, title('Part b: Fourier power spectrum')


z2 = fasthaar(x2);
Cg = waveletmap(t_rng,z2,2,20,4,5);
figure(4),title('Part b: Wavelet map')

fprintf('Pt b: level %3.0f,%8.0f,%8.0f,%8.0f,%8.0f,%8.0f\n', 0:5)
fprintf('  frequency %8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f [Hz]\n\n', (1/T)*2.^[0:5])


% Part (c)
p = [1 1 1 1 1 -1 -1 -1 -1 -1];
x3 = [p p p p p p p p];
T = 5.12*n/80;
dt = T/n;
t_rng = dt:dt:T; 
figure(5)
subplot(2,1,1)
plot(t_rng,x3(1:n))
xlabel('time'), ylabel('x(t)')
title('Part c: Time series data')
axis([0 T -1.2 1.2])
grid

df = 1/T; f_max = df*n/2; f_rng = [0:n/2-1]*df;
fou_x3 = fft(x3(1:64));
fou_pwr3 = fou_x3.*conj(fou_x3);
subplot(2,1,2)
bar(f_rng,fou_pwr3(1:n/2))
xlabel('Frequency Hz'), ylabel('Amplitude')
axis([0 f_max 0 1200])
grid, title('Part c: Fourier power spectrum')


z3 = fasthaar(x3(1:64));
Cg = waveletmap(t_rng,z3,2,20,6,7);
figure(6),title('Part c: Wavelet map')

fprintf('Pt c: level %3.0f,%8.0f,%8.0f,%8.0f,%8.0f,%8.0f\n', 0:5)
fprintf('  frequency %8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f [Hz]\n\n', (1/T)*2.^[0:5])



