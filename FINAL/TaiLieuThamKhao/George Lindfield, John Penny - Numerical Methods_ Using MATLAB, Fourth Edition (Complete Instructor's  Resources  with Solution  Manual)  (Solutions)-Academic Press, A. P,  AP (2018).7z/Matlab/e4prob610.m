% e4prob610
% Solution of Problem 6.10
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all

A = zeros(10,10);
A = diag(-4*ones(1,10))+diag(ones(1,9),1)+diag(ones(1,9),-1);
A(5,6) = 0;  
A(6,5) = 0;
A(8,9) = 0;  
A(9,8) = 0;
A(3,6) = 1;  
A(6,3) = 1;
A(4,7) = 1;  
A(7,4) = 1;
A(5,8) = 1;  
A(8,5) = 1;
A(6,9) = 1;  
A(9,6) = 1;
b = -2*ones(10,1);
solution = A\b;
disp('Node number     phi')
[[1:10]' solution]

s = solution;
ZZ = [0 0 0 0 0 0 0;
      0 s(1) s(2) s(3) s(4) s(5) 0;
      0 0 0 s(6) s(7) s(8) 0;
      0 0 0 s(9) 0 0 0;
      0 0 0 s(10) 0 0 0;
      0 0 0 0 0 0 0]
ZZ = flipud(ZZ);
  
x = 0:6; y = 0:5;
surfl(x,y,ZZ)
axis([0 6 0 5 0 2]) 
zlabel('Phi') 
     
     