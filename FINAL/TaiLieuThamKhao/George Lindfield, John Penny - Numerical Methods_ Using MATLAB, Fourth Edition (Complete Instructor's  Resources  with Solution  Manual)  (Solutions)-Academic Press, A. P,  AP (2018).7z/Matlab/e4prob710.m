% e4prob710
% Solution of Problem 7.10
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x1 = -4:0.2:4; 
y1 = -4:0.2:4;
[x,y] = meshgrid(x1,y1);
z = 0.5*(x.^4-16*x.^2+5*x)+0.5*(y.^4-16*y.^2+5*y);
surf(x,y,z)
xlabel('x')
ylabel('y')
zlabel('z')
x0 = -2.9035;
y0 = -2.9035;
zi_linear = interp2(x1,y1,z,x0,y0,'linear');
zi_cubic  = interp2(x1,y1,z,x0,y0,'cubic');
zi_exact = 0.5*(x0.^4-16*x0.^2+5*x0)+0.5*(y0.^4-16*y0.^2+5*y0);
fprintf('Using linear interpolation: z = %8.4f\n',zi_linear)
fprintf('Using  cubic interpolation: z = %8.4f\n',zi_cubic)
fprintf('               Exact value: z = %8.4f\n',zi_exact)