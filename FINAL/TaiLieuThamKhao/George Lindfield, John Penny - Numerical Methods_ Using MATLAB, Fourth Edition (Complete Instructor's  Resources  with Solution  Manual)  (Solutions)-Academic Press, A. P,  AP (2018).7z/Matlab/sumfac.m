function res = sumfac(n)
% res is the sum of the series 1+2^2/2!+3^2/3!+ ... to n terms. 

% Solution of Problem 1.24
%
% This MATLAB function is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

sum = 0;
for k = 1:n
    sum = sum+k^2/factorial(k);
end
res = sum;
