% e4prob406
% Solution of Problem 4.6
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018

clear all
close all

func = @(x) 0.764./sqrt(log(x));
a = 1;
for b = [10 17 30]
    int = fgauss(func,a,b,16);    
    fprintf('Evaluation for range [%1.0f %2.0f] = %9.6f\n',a,b,int)
end