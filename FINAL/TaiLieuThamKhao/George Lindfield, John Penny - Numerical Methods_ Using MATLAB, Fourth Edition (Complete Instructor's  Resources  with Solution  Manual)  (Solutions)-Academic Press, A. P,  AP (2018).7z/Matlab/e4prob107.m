% e4prob107
% Solution of Problem 1.7
%
% This MATLAB file is to accompany solutions manual for the book
% 'Numerical Methods using MATLAB e4' by GR Lindfield and JET Penny,
% published by Academic Press, an imprint of Elsevier, 2018.

clear all
close all
x = -2:0.1:2;      % Range of x required for plotting
y1 = x.^2.*cos(x); % Generate a vector y1 
y2 = x.^2.*sin(x); % Generate a vector y2 

%This statement allows two graphs with same axes
plot(x,y1,x,y2)
xlabel('x-axis')
ylabel('y1 and y2-axis')
title('Problem 1.7 - Graphs')
grid
legend('x^2cos(x) function','x^2sin(x) function')


